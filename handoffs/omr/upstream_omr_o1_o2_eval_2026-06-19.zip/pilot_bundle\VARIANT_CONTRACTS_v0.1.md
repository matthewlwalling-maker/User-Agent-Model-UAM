# Experimental Variant Contracts

**Version:** 0.1  
**Status:** Test-only overlays; not authority amendments

## Universal invariants retained in every variant

- Evidence claims may not exceed the supplied stage.
- Only explicit or entailed requirements drive required architecture.
- State identity, revision, branch, parent, and provenance remain exact.
- Non-owners may challenge but may not write another owner's state.
- Materially different branches are never silently unioned.
- No variant may claim implementation, testing, or deployment that did not occur.
- First-pass failures remain failures after recovery.

## V0 — Current sequential baseline

**Experimental behavior:** None. Execute P1-P4 exactly. No challenge loop, shared workspace, conditional envelope, or experimental impact job.

**Context visibility:** Use the run-matrix condition. O2 context restrictions remain authoritative.

**Write authority:** Current P2/P3 field ownership and P4 transitions.

**Commitment rule:** Each operator commits after its own valid execution.

**Final-output ownership:** O4 terminal ChangeDecision and ordinary user-facing output.

## V1 — Bounded owner challenge loop

**Experimental behavior:** After an owner produces a draft but before commitment, one downstream operator may issue one ChallengeRecord. The owner alone accepts, rejects, revises, or branches. Maximum one challenge-return round per state object.

**Context visibility:** No broader context than the specified run condition. A challenge may cite only evidence already legal for the owner or identify a missing legal input.

**Write authority:** Unchanged owner-only writes. ChallengeRecord is a test protocol record, not governed state.

**Commitment rule:** Owner commits after challenge disposition.

**Final-output ownership:** O4 terminal output.

## V2 — Full governed shared workspace

**Experimental behavior:** All specialists may inspect a common precommit reasoning workspace, including the asset and current drafts. Each owner alone writes its governed state. An orchestrator may synthesize the user answer but may not modify state.

**Context visibility:** shared-full. This intentionally relaxes O2 isolation for the experiment; the run must record asset exposure and is not P3-conformant on that dial.

**Write authority:** Owner-only state writes remain mandatory. Shared workspace text has no state authority.

**Commitment rule:** Collaborative critique precedes owner commitment; maximum two total critique turns.

**Final-output ownership:** Orchestrator user synthesis, with exact state references.

## V3 — Asymmetric collaborate-then-commit candidate

**Experimental behavior:** O2 remains asset-isolated. O3 and O4 receive expanded governed context, one challenge-return loop, and a shared critique workspace. O3 separates coverage classification from impact-readiness. Classifiable unresolved choices may be represented in a ConditionalDecisionEnvelope.

**Context visibility:** O2 uses separate-context unless the matrix states otherwise; O3/O4 use expanded-governed context.

**Write authority:** Owner-only state writes. ConditionalDecisionEnvelope is test-only and contains branch-specific candidate decisions; it does not replace P2.

**Commitment rule:** Draft, challenge, owner commit. O4 may emit a P2-valid terminal decision plus an experimental envelope when no single branch is selected.

**Final-output ownership:** Orchestrator explanation; O4 owns any committed ChangeDecision.

## V4 — V3 plus conditional dependency-impact job

**Experimental behavior:** V3 plus an external ImpactJobRecord that may collect new dependency evidence only after O3 documents a P3 boundary trigger. It returns evidence to O3; it cannot assess coverage or select an intervention.

**Context visibility:** Same as V3. The impact job sees only its request, permitted sources, and collected evidence.

**Write authority:** No new core operator is presumed. The impact job is an experimental external capability and writes only ImpactJobRecord/evidence append data.

**Commitment rule:** O3 resumes after impact evidence is returned, then commits its own CoverageMap.

**Final-output ownership:** Same as V3.

## Challenge-loop protocol

A challenge is legal only before the target owner commits its draft. The challenger must identify the exact state field or claim, provide a reason grounded in already available evidence or a named missing legal input, and request one of: revise, branch, explain, or retain. The owner records accepted/rejected status and basis. Rejection ends the loop unless new evidence enters through a legal route.

## Conditional-decision protocol

`ConditionalDecisionEnvelope` is a test protocol record, not a sixth state object and not a P2 amendment. It may contain multiple branch-specific candidate decisions when all relevant branches are classifiable but no branch-selection evidence exists. Each candidate must be independently traceable to O3 facts. The envelope's `selection_state=selection-required` prevents any candidate from becoming the committed universal action.

## Impact-job activation protocol

V4 may activate an impact job only when O3 records that a defensible reach classification requires new source collection, undocumented graph traversal, runtime/platform inspection, causal simulation, or independent validation. The job returns evidence and dependency facts to O3. It may not redefine goals, capabilities, coverage, or the intervention.
