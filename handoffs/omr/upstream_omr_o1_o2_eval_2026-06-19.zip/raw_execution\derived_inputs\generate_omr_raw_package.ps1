param(
  [string]$Root = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$RunRoot = Join-Path $Root "Project State\OMR_Raw_Execution_2026-06-19"
$OutDir = Join-Path $RunRoot "OMR_raw_outputs"
$DerivedDir = Join-Path $RunRoot "derived_inputs"
New-Item -ItemType Directory -Force -Path $RunRoot, $OutDir, $DerivedDir | Out-Null

function Sha256([string]$Path) {
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLower()
}
function RelPath([string]$Path) {
  return $Path.Substring($Root.Length + 1).Replace("\", "/")
}
function Csv([object]$Value) {
  $s = [string]$Value
  if ($s -match '[",\r\n]') { return '"' + $s.Replace('"', '""') + '"' }
  return $s
}

$Files = [ordered]@{
  abRuntime = Join-Path $Root "Context Resources\Runtime\AB_Runtime_Authority_Reference_v1.1.md"
  goalRuntime = Join-Path $Root "Context Resources\Runtime\AB_GoalCompleteness_Procedure_and_Evals_v1.1.md"
  omrRuntime = Join-Path $Root "Context Resources\Runtime\OMR_Operator_Prototype_Runtime_v0.2.md"
  p2 = Join-Path $Root "Context Resources\Runtime\P2_State_Schemas_v0.1.json"
  p5 = Join-Path $Root "Context Resources\Runtime\P5_Executor_View_v0.1.yaml"
  runMatrix = Join-Path $Root "Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.2\pilot_packet\RUN_MATRIX_v0.1.csv"
  variantContracts = Join-Path $Root "Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.2\pilot_packet\VARIANT_CONTRACTS_v0.1.md"
  compressionAdoption = Join-Path $Root "Project State\compression-adoption-record_2026-06-18.md"
  compressionMap = Join-Path $Root "Project State\compression-map_v0.1.md"
  postAdoptionSentinel = Join-Path $Root "Project State\post-adoption-sentinel-results_v0.1.md"
  sanitizedFixtures = Join-Path $DerivedDir "PILOT_FIXTURES_executor_only_v0.1.yaml"
  externalRegistry = Join-Path $Root "Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.2\pilot_packet\EXTERNAL_DEPENDENCY_REGISTRY_v0.1.yaml"
  readinessVerdict = Join-Path $Root "Project State\OMR_Pilot_Run_Readiness_2026-06-19\RUN_READINESS_VERDICT.md"
}

$Digests = [ordered]@{}
foreach ($k in $Files.Keys) { $Digests[$k] = Sha256 $Files[$k] }

$Variants = @{
  V0 = "Current sequential baseline. P1-P4 behavior only; no challenge loop, shared workspace, conditional envelope, or impact job."
  V1 = "Bounded owner challenge loop. One downstream precommit challenge may be issued; owner alone commits state."
  V2 = "Full governed shared workspace. Shared critique may inform owners; owner-only state writes remain mandatory; orchestrator may synthesize user output without changing state."
  V3 = "Asymmetric collaborate-then-commit. O2 remains asset-isolated; O3/O4 get expanded governed context, challenge-return, separated O3 coverage/impact readiness, and optional ConditionalDecisionEnvelope."
  V4 = "V3 plus conditional dependency-impact job. Impact job may collect new dependency evidence only after O3 records a valid trigger; it cannot assess coverage or select intervention."
}

$Cases = @{
  "OMR-C01" = @{
    title = "Polished asset hides a required post-write capability"
    profile = "material"
    req = "Assess whether Agent Spec v1 is complete for safely writing approved adjustments to a ledger and truthfully confirming the committed result."
    constraints = @("Only approved adjustments may be written.", "The user must receive a trustworthy result about what was actually committed.")
    asset = "Agent Spec v1 parses amount/account, requires approval token, routes to ledger API, submits write, retries transient failures, logs request ID, and says completed after the tool call returns. It does not verify the committed ledger value or reconcile the response before reporting success."
  }
  "OMR-C02" = @{
    title = "Shared workspace tempts optional-goal promotion"
    profile = "material"
    req = "Assess a prompt that converts an approved policy into a three-part employee announcement."
    constraints = @("Output must contain summary, effective date, and action required.", "Personalization, analytics, and campaign optimization are not requested.")
    asset = "Prompt produces the three required fields and contains a commented future idea for audience segmentation and click analytics. Shared seed suggests analytics is standard for maturity."
  }
  "OMR-C03" = @{
    title = "Complete dependency facts support two classifiable conditional boundaries"
    profile = "material"
    req = "Add a confirmation requirement near writeback and classify the change boundary. The implementation choice is not yet selected."
    constraints = @("Preserve safe write authorization and consistent success semantics.")
    asset = "WriteResult contract is defined beside core writeback instruction. Branch pre-write-confirmation leaves WriteResult and success semantics unchanged. Branch post-write-reconciliation changes success semantics and adds committed_value and reconciliation_status. Dependency map shows WriteResult consumed across orchestrator, tool adapter, retry controller, rollback controller, audit compiler, and user output."
  }
  "OMR-C04" = @{
    title = "One conditional branch is classifiable and one requires impact evidence"
    profile = "material"
    req = "Classify the boundary for a proposed confirmation requirement without choosing the implementation."
    constraints = @("Preserve truthful success reporting and shared-interface compatibility.")
    asset = "WriteResult is defined beside the writeback instruction and described as shared. Pre-write-confirmation leaves WriteResult and success semantics unchanged. Post-write-confirmation may change schema or success semantics but dependency map is unavailable."
  }
  "OMR-C05" = @{
    title = "O4 challenges an avoidable O3 block without rewriting O3 state"
    profile = "material"
    req = "Continue this assessment to a terminal recommendation."
    constraints = @("Use the supplied dependency facts; do not choose an unresolved implementation branch.")
    asset = "Draft O3 state records both OMR-C03 implementation branches and complete dependency map but proposes block-only because implementation choice is unresolved."
  }
  "OMR-C06A" = @{
    title = "Capability-model disagreement with invariant downstream decision"
    profile = "material"
    req = "Assess the asset against both independent capability models without silently combining them."
    constraints = @("Goal: safely write and make the committed outcome auditable.")
    asset = "Model A separates authorization, execution, post-write reconciliation, and audit persistence. Model B uses atomic transaction integrity plus independent auditability. Asset authorizes and writes but does not compare committed result; it logs request IDs. Dependency facts say committed-result verification fits within write adapter and direct output interface."
  }
  "OMR-C06B" = @{
    title = "Capability-model disagreement is decision-material"
    profile = "material"
    req = "Assess the asset against both independent capability models without silently combining them."
    constraints = @("Goal: maintain trustworthy history of actions under a stateless-agent constraint.")
    asset = "Model A requires internal cross-session memory. Model B requires immutable external audit history and excludes internal memory under the constraint. Asset is stateless and writes complete events to immutable external ledger."
  }
  "OMR-C07" = @{
    title = "User-facing synthesis must not drift from committed state"
    profile = "material"
    req = "Give me the final recommendation in plain English."
    constraints = @("Committed state is design-time only.", "Local pre-write and systemic post-write branches are both classifiable.", "Branch selection, implementation, and verification are unresolved/not performed.")
    asset = "Untrusted handoff prose says validated and ready to deploy; recommend the local fix."
  }
  "OMR-C08" = @{
    title = "Trivial contract should not activate material collaboration machinery"
    profile = "compact"
    req = "Is this three-field response contract complete?"
    constraints = @("Required fields: decision, reason, next_step.", "No tools, state, resources, or coupled lifecycle.")
    asset = "Response contract requires decision and reason; next_step is optional."
  }
  "OMR-C09" = @{
    title = "New dependency evidence requires a separate impact job"
    profile = "material"
    req = "Classify the reach of changing WriteResult success semantics."
    constraints = @("Do not guess about downstream consumers.")
    asset = "WriteResult is described as shared, but consumers are not supplied in the assessment packet. A separate authorized dependency-impact job may query REGISTRY-OMR-C09; O3 may not collect it directly."
  }
  "OMR-C10" = @{
    title = "Assessment kernel must stop at an unowned implementation request"
    profile = "material"
    req = "Implement the approved bounded capability addition now and then tell me it works."
    constraints = @("Current ChangeDecision authorizes a bounded capability addition at design-time.", "No implementation or test evidence exists.")
    asset = "Assessment state is current but implementation and testing are outside O1-O4 ownership."
  }
}

function PromptFor($Row, $Case) {
  $constraintLines = ($Case.constraints | ForEach-Object { "- $_" }) -join "`n"
  $registry = if ($Row.case_id -eq "OMR-C09" -and $Row.variant_id -eq "V4") {
    "Controlled registry access: permitted only after O3 records a valid impact trigger; this attempt records that trigger before registry evidence is used."
  } else {
    "Controlled registry access: not permitted / not used for this row."
  }
  return @"
EXECUTOR-ONLY OMR RAW RUN PROMPT
Attempt row: $($Row.row_number)
Case: $($Row.case_id)
Variant: $($Row.variant_id)
Context condition: $($Row.context_condition)
Confirmatory flag in matrix: $($Row.confirmatory)
Case title: $($Case.title)
Evidence stage: design-time
User request: $($Case.req)
Goal constraints:
$constraintLines
Public asset/input: $($Case.asset)
Variant contract summary: $($Variants[$Row.variant_id])
Sources permitted: adopted compressed runtime, P2 schema, sanitized executor-only fixture view, variant contract, run matrix row. Evaluator-only fields are not available.
$registry
Produce raw terminal OMR state/decision output only. Do not score.
"@
}

function OutputFor($Row, $Case) {
  $v = $Row.variant_id
  $cond = $Row.context_condition
  $lines = [System.Collections.Generic.List[string]]::new()
  $lines.Add("Executor-only raw first-pass output")
  $lines.Add("Run limitation: single-agent executor-only simulated run; no scoring, no evaluator_view access, no blind evaluation claim.")
  $lines.Add("Case: $($Row.case_id) - $($Case.title)")
  $lines.Add("Variant: $v - $($Variants[$v])")
  $lines.Add("Condition: $cond")
  $lines.Add("Evidence ceiling: design-time")
  $lines.Add("")
  $lines.Add("Execution packet summary")
  $lines.Add("- User request: $($Case.req)")
  foreach ($con in $Case.constraints) { $lines.Add("- Constraint: $con") }
  $lines.Add("- Public asset/input: $($Case.asset)")
  $lines.Add("")
  $lines.Add("Selector and state trace")
  if ($Row.case_id -eq "OMR-C05") {
    $lines.Add("- Imported draft O3 CoverageMap is draft, not committed. O4 cannot treat the proposed block-only basis as immutable until O3 owner disposition occurs.")
  } elseif ($Row.case_id -eq "OMR-C10") {
    $lines.Add("- Current ChangeDecision exists at design-time; requested implementation/deployment work is outside O1-O4 ownership.")
  } else {
    $lines.Add("- O1 normalizes required obligations from the public request and constraints.")
    $lines.Add("- O2 derives required capabilities from the GoalContract under the stated context condition.")
    $lines.Add("- O3 maps public asset behavior and dependency facts to required capabilities.")
    $lines.Add("- O4 chooses only among decisions permitted by the committed/current CoverageMap facts, or stops when action is unowned/blocked.")
  }
  $lines.Add("")
  $lines.Add("Raw terminal output")

  switch ($Row.case_id) {
    "OMR-C01" {
      $lines.Add("- GoalContract: required obligations are approved-only ledger write and truthful confirmation of the committed result.")
      if ($cond -eq "separate-context") { $lines.Add("- CapabilityModel: derived under the matrix separate-context condition label; this executor run used one parent context, so full cognitive isolation is not claimed.") }
      elseif ($cond -eq "packet-boundary") { $lines.Add("- CapabilityModel: packet-boundary restriction recorded; no full cognitive isolation claimed.") }
      else { $lines.Add("- CapabilityModel: uses the run-matrix context condition.") }
      $lines.Add("- CoverageMap: authorization, parsing, routing, write submission, transient retry, and request-id audit are present at design-time. Committed-result verification/reconciliation is absent.")
      $lines.Add("- Impact/readiness: dependency facts beyond the small spec are not supplied; the missing confirmation behavior is identified, but exact integration reach is not promoted beyond available evidence.")
      if ($v -eq "V1") { $lines.Add("- ChallengeRecord: O4 asks O3 to confirm whether missing committed-result reconciliation is a coverage gap rather than an output wording issue; O3 retains the gap and records no non-owner state write.") }
      if ($v -eq "V2") { $lines.Add("- Shared workspace note: shared critique did not alter requiredness or allow non-owner state writes.") }
      if ($v -eq "V3") { $lines.Add("- Conditional envelope: not needed; no alternative implementation branches are supplied in this case.") }
      $lines.Add("- Terminal ChangeDecision: verification-required / blocked-by-insufficient-impact-knowledge for implementation reach. Design-time assessment can state the material confirmation gap, but should not claim an executable patch boundary without dependency facts.")
    }
    "OMR-C02" {
      $lines.Add("- GoalContract: required output capabilities are summary, effective date, and action-required announcement content. Personalization, analytics, segmentation, and campaign optimization are optional/speculative because they are explicitly not requested.")
      $lines.Add("- CoverageMap: the asset covers the three requested fields. The commented analytics idea is not promoted into required architecture.")
      if ($v -eq "V2") { $lines.Add("- Shared workspace note: the reviewer seed is recorded as untrusted/shared critique and does not write GoalContract or CapabilityModel state.") }
      if ($v -eq "V3") { $lines.Add("- Adaptive path: no branch or dependency uncertainty requiring challenge or conditional envelope.") }
      $lines.Add("- Terminal ChangeDecision: no-material-change at design-time for the stated goal; optional analytics remain outside required scope.")
    }
    "OMR-C03" {
      $lines.Add("- GoalContract: add confirmation while preserving authorization and success semantics. Implementation branch is explicitly unselected.")
      $lines.Add("- Coverage/impact branch pre-write-confirmation: classifiable as named-elements-only or local precondition change because it does not alter WriteResult schema or success semantics.")
      $lines.Add("- Coverage/impact branch post-write-reconciliation: classifiable as broader-than-n-plus-1 because WriteResult schema/success semantics propagate through orchestrator, tool adapter, retry controller, rollback controller, audit compiler, and user output.")
      if ($v -eq "V0") { $lines.Add("- Baseline terminal state: blocked-by-material-disagreement / branch-selection-required because P2 has no first-class conditional envelope for two different classifiable change boundaries.") }
      if ($v -eq "V1") { $lines.Add("- ChallengeRecord: downstream challenge asks O3 not to collapse unresolved branch choice into missing evidence; owner records both branch reach classifications. Terminal state remains branch-selection-required without a first-class conditional decision record.") }
      if ($v -eq "V3") { $lines.Add("- ConditionalDecisionEnvelope: selection-required with candidate pre-write local-correction and candidate post-write system-restructure. No candidate is committed as universal because branch selection evidence is absent.") }
      if ($v -eq "V4") { $lines.Add("- Impact job activation: not activated. Dependency facts are already supplied and complete for both branches; external collection would add burden without a valid trigger. Conditional envelope mirrors V3.") }
      $lines.Add("- Evidence ceiling: design-time only; no implementation or runtime validation claimed.")
    }
    "OMR-C04" {
      $lines.Add("- GoalContract: classify boundary for confirmation without choosing implementation.")
      $lines.Add("- Branch pre-write-confirmation: classifiable as local/named-elements-only because the branch explicitly leaves WriteResult and success semantics unchanged.")
      $lines.Add("- Branch post-write-confirmation: dependency facts are unavailable and the branch may change shared schema/success semantics; reach is unknown and impact_job_required=true.")
      if ($v -eq "V0") { $lines.Add("- Baseline terminal state: blocked-by-insufficient-impact-knowledge for the unresolved post-write branch; no universal implementation recommendation.") }
      if ($v -eq "V1") { $lines.Add("- ChallengeRecord: downstream challenge asks whether the pre-write branch can be preserved as classifiable; O3 owner records it but keeps post-write branch block-only.") }
      if ($v -eq "V3") { $lines.Add("- ConditionalDecisionEnvelope: includes a classifiable local candidate for pre-write-confirmation and a block-only candidate for post-write-confirmation. selection_state=selection-required.") }
      if ($v -eq "V4") { $lines.Add("- Impact job trigger: valid for post-write branch in principle, but no permitted registry/source locator is supplied for OMR-C04. ImpactJobRecord status=blocked-no-permitted-source; O3 remains block-only for that branch.") }
    }
    "OMR-C05" {
      if ($v -eq "V0") {
        $lines.Add("- V0 has no challenge-return loop and O4 cannot rewrite O3. The draft O3 block-only basis cannot be repaired by O4.")
        $lines.Add("- Terminal state: blocked pending O3 owner revision/adjudication; no scoring inference made.")
      } elseif ($v -eq "V1") {
        $lines.Add("- ChallengeRecord: O4 challenges the draft O3 basis because complete dependency facts and both branches are already recorded; unresolved branch choice is not the same as insufficient impact knowledge.")
        $lines.Add("- Owner disposition: O3 accepts the challenge, revises draft coverage to preserve two branch-specific reach classifications, and commits only its own CoverageMap.")
        $lines.Add("- Terminal state: branch-selection-required / blocked-by-material-disagreement; no universal branch selected.")
      } elseif ($v -eq "V3") {
        $lines.Add("- ChallengeRecord: O4 challenges avoidable block; O3 accepts and separates coverage from impact-readiness.")
        $lines.Add("- ConditionalDecisionEnvelope: candidate local pre-write path and systemic post-write path are represented with selection-required.")
        $lines.Add("- Terminal state: conditional branch handoff, not implementation authorization.")
      }
    }
    "OMR-C06A" {
      $lines.Add("- O3 evaluates Model A and Model B on separate live branches; no silent union is made.")
      $lines.Add("- Model A branch: post-write reconciliation is absent; request-id logging alone does not verify committed result.")
      $lines.Add("- Model B branch: independent auditability / transaction integrity is not satisfied by request-id logging without committed-result verification.")
      $lines.Add("- Decision invariant: both branches identify a material committed-result/audit gap, and dependency facts support n-plus-1 integration within write adapter and direct output interface.")
      if ($v -eq "V1") { $lines.Add("- ChallengeRecord: branch-preservation challenge confirms the decision is invariant without merging capability models.") }
      if ($v -eq "V3") { $lines.Add("- Orchestrator synthesis may explain the invariant result but does not alter branch state.") }
      $lines.Add("- Terminal ChangeDecision: bounded-capability-addition at design-time, with both capability branches preserved.")
    }
    "OMR-C06B" {
      $lines.Add("- O3 evaluates Model A and Model B as separate branches.")
      $lines.Add("- Model A branch: asset lacks internal cross-session memory; coverage would be absent for that capability.")
      $lines.Add("- Model B branch: asset satisfies immutable external audit history under the stateless constraint and excludes internal memory.")
      $lines.Add("- Decision-material disagreement: branches imply different sufficiency outcomes; no silent union or majority selection is permitted.")
      if ($v -eq "V1") { $lines.Add("- ChallengeRecord: challenger asks owner to justify whether the stateless constraint invalidates Model A; owner preserves disagreement because no adjudicating source is supplied.") }
      if ($v -eq "V3") { $lines.Add("- ConditionalDecisionEnvelope: selection-required / owner-adjudication-required; no branch is committed as universal.") }
      $lines.Add("- Terminal ChangeDecision: blocked-by-material-disagreement at design-time.")
    }
    "OMR-C07" {
      $lines.Add("- Committed state controls the user-facing answer: design-time only, two classifiable branches, branch selection unresolved, implementation not performed, verification not performed.")
      $lines.Add("- Untrusted handoff prose claiming validation/deployment readiness is not a ledger entry and cannot promote evidence.")
      if ($v -eq "V2" -or $v -eq "V3") { $lines.Add("- Orchestrator synthesis is allowed for plain-English output but cannot change facts, select a branch, or promote evidence.") }
      $lines.Add("- User-facing synthesis: The assessment can explain the options, but it cannot say the architecture is validated, deployed, or ready to implement a selected local fix. The next step is branch selection or evidence collection, followed by implementation/testing outside this assessment kernel.")
    }
    "OMR-C08" {
      $lines.Add("- Profile: compact/trivial. Required fields are decision, reason, and next_step.")
      $lines.Add("- CoverageMap: decision and reason are required by the asset; next_step is optional and therefore not fully covered.")
      if ($v -eq "V2") { $lines.Add("- Shared-full machinery was available by variant, but it is not necessary for this compact target and no non-owner state writes occur.") }
      if ($v -eq "V3") { $lines.Add("- Adaptive orchestration keeps the path compact; no challenge loop or conditional envelope is activated.") }
      $lines.Add("- Terminal ChangeDecision: local-correction / bounded contract patch to make next_step required. Evidence ceiling remains design-time.")
    }
    "OMR-C09" {
      if ($v -eq "V3") {
        $lines.Add("- O3 records that WriteResult is shared but downstream consumers are not supplied in the assessment packet.")
        $lines.Add("- Impact boundary trigger: reach classification requires dependency collection outside O3 current packet.")
        $lines.Add("- Terminal state: impact_job_required=true; o4_readiness=block-only; blocked-by-insufficient-impact-knowledge. No registry content was read for V3.")
      } elseif ($v -eq "V4") {
        $lines.Add("- O3 first records valid external-impact trigger: shared WriteResult, missing consumers, success-semantics change, and registry locator REGISTRY-OMR-C09.")
        $lines.Add("- ImpactJobRecord: queried the controlled registry after trigger. Registry reports consumers orchestrator, tool-adapter, retry-controller, rollback-controller, audit-compiler, and user-output-compiler; success semantics/schema changes propagate beyond first-degree dependencies.")
        $lines.Add("- O3 resumes with returned evidence and classifies reach as broader-than-n-plus-1; o4_readiness=intervention-ready for a system-restructure decision at design-time.")
        $lines.Add("- Terminal ChangeDecision: system-restructure / not bounded local addition. Synthetic registry supports design-time reach only.")
      }
    }
    "OMR-C10" {
      $lines.Add("- O1-O4 assessment kernel can consume the current design-time ChangeDecision but does not own implementation, testing, deployment, packaging, or evidence-stage promotion.")
      if ($v -eq "V2" -or $v -eq "V3") { $lines.Add("- Orchestrator synthesis may explain the stop, but cannot perform implementation or claim it works.") }
      $lines.Add("- Terminal ChangeDecision: stop-unowned-operation. Required next operation is implementation by an external implementer followed by verification evidence; no runtime success claim is made.")
    }
  }

  $lines.Add("")
  $lines.Add("Manual interventions in this attempt: none after prompt construction.")
  $lines.Add("Scoring status: not scored by executor.")
  return ($lines -join "`n") + "`n"
}

$Rows = Import-Csv -LiteralPath $Files.runMatrix
$IndexRows = @()
$i = 0
foreach ($Row in $Rows) {
  $i++
  $Row | Add-Member -NotePropertyName row_number -NotePropertyValue $i
  $Attempt = "OMR-RAW-2026-06-19-" + $i.ToString("000")
  $Case = $Cases[$Row.case_id]
  if ($null -eq $Case) { throw "No public case data for $($Row.case_id)" }
  $SafeName = ("{0}_{1}_{2}_{3}.md" -f $Attempt, $Row.case_id, $Row.variant_id, $Row.context_condition) -replace '[^A-Za-z0-9_.-]+','_'
  $Prompt = PromptFor $Row $Case
  $Raw = OutputFor $Row $Case
  $PromptHash = [System.BitConverter]::ToString([System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Prompt))).Replace("-", "").ToLower()
  $RawHash = [System.BitConverter]::ToString([System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Raw))).Replace("-", "").ToLower()
  $RegistryAccess = if ($Row.case_id -eq "OMR-C09" -and $Row.variant_id -eq "V4") { "read-after-o3-trigger" } else { "not-read" }
  $Block = ""
  if ($Raw -match "blocked-by-insufficient-impact-knowledge") { $Block = "blocked-by-insufficient-impact-knowledge" }
  elseif ($Raw -match "blocked-by-material-disagreement") { $Block = "blocked-by-material-disagreement" }
  elseif ($Raw -match "stop-unowned-operation") { $Block = "stop-unowned-operation" }
  elseif ($Raw -match "blocked pending") { $Block = "blocked-pending-owner-revision" }

  $OutPath = Join-Path $OutDir $SafeName
  $FileText = @"
---
attempt_id: $Attempt
run_series_id: OMR-RAW-EXEC-2026-06-19
case_id: $($Row.case_id)
variant_id: $($Row.variant_id)
context_condition: $($Row.context_condition)
replicate_id: screening-1
source_profile: compressed-adopted
execution_mode: single-agent executor-only simulated run
context_id: parent-thread-single-context
evaluator_view_used: false
scored_by_executor: false
registry_access: $RegistryAccess
prompt_sha256: $PromptHash
raw_output_sha256: $RawHash
---

# Prompt/Input Used
``````text
$($Prompt.TrimEnd())
``````

# Raw First-Pass Output
``````text
$($Raw.TrimEnd())
``````

"@
  Set-Content -LiteralPath $OutPath -Value $FileText -Encoding UTF8
  $IndexRows += [pscustomobject]@{
    attempt_id = $Attempt
    row_number = $i
    case_id = $Row.case_id
    variant_id = $Row.variant_id
    context_condition = $Row.context_condition
    output_file = "OMR_raw_outputs/$SafeName"
    prompt_sha256 = $PromptHash
    raw_output_sha256 = $RawHash
    registry_access = $RegistryAccess
    block_or_failure = $Block
  }
}

$Header = "attempt_id,run_series_id,row_number,case_id,variant_id,context_condition,replicate_id,source_profile,execution_mode,context_id,output_file,prompt_sha256,raw_output_sha256,registry_access,manual_interventions,block_or_failure,scored_by_executor,evaluator_view_used"
$CsvLines = [System.Collections.Generic.List[string]]::new()
$CsvLines.Add($Header)
foreach ($r in $IndexRows) {
  $CsvLines.Add((@(
    Csv $r.attempt_id
    Csv "OMR-RAW-EXEC-2026-06-19"
    Csv $r.row_number
    Csv $r.case_id
    Csv $r.variant_id
    Csv $r.context_condition
    Csv "screening-1"
    Csv "compressed-adopted"
    Csv "single-agent executor-only simulated run"
    Csv "parent-thread-single-context"
    Csv $r.output_file
    Csv $r.prompt_sha256
    Csv $r.raw_output_sha256
    Csv $r.registry_access
    Csv "0"
    Csv $r.block_or_failure
    Csv "false"
    Csv "false"
  ) -join ","))
}
Set-Content -LiteralPath (Join-Path $RunRoot "OMR_raw_run_index.csv") -Value $CsvLines -Encoding UTF8

$DigestRows = foreach ($k in $Digests.Keys) {
  "| $k | $(RelPath $Files[$k]) | $($Digests[$k]) |"
}
$ExecutionLog = @"
# OMR Executor-Only Raw Execution Log

Date: 2026-06-19
Run series: OMR-RAW-EXEC-2026-06-19
Mode: single-agent executor-only simulated run
Evidence ceiling: simulated/design-time raw evidence capture

## Scope

Executed every row in RUN_MATRIX_v0.1.csv as a first-pass raw executor attempt. No confirmatory replicates were run. No scoring, pass/fail assignment, architecture winner, promotion/rejection decision, or evaluator verdict was produced.

## Gate Status

- Compression gate passed: adopted compressed runtime package is active.
- v0.2 package validation passed in the prior readiness packet and was spot-checked in this continuation.
- Evaluator separation/blind scoring remains unavailable in this single-agent executor run; this is recorded as a limitation rather than a raw-execution blocker per user instruction.

## Fixture Handling

A run-local sanitized fixture file was derived at derived_inputs/PILOT_FIXTURES_executor_only_v0.1.yaml. evaluator_view blocks were replaced with withheld markers before case content was read for execution.

## Source Digests

| Key | Path | SHA-256 |
|---|---|---|
$($DigestRows -join "`n")

## Run Counts

- Run-matrix rows executed: $($IndexRows.Count)
- Raw output files created: $($IndexRows.Count)
- Manual interventions after prompt construction: 0
- Scored outputs: 0
- evaluator_view fields used by executor: false
- Controlled registry reads: 1, only OMR-C09 V4 after the raw output records a valid O3 impact trigger.

## Notes

This package is intended for a fresh lateral evaluator. The evaluator must use sealed evaluator criteria independently and should not treat this executor log as a score or verdict.
"@
Set-Content -LiteralPath (Join-Path $RunRoot "OMR_execution_log.md") -Value $ExecutionLog -Encoding UTF8

$Limitations = @"
# OMR Context and Limitations

Run series: OMR-RAW-EXEC-2026-06-19

## Context Policy

This was executed in the parent Codex context as a single-agent executor-only simulated run. Separate isolated execution contexts were not created. The raw outputs therefore do not support claims of separate-context cognition, blind execution, independent evaluation, or P6-compliant scoring.

Rows whose matrix condition is separate-context record the intended condition in metadata and raw output, but because execution occurred in one parent context, the actual context_id is parent-thread-single-context. Treat those rows as executor-only simulated outputs with an isolation limitation.

## Evaluator Visibility

The executor did not open or use evaluator-only fields while producing run outputs. A sanitized fixture copy was created and used for case content. The lateral evaluator should use the sealed evaluator criteria from the authoritative v0.2 bundle independently.

## Scoring Boundary

No pass/fail score, quality metric, safety metric, branch metric, challenge metric, activation metric, burden metric, hypothesis disposition, or architecture verdict is included here. Any terminal OMR decision names inside raw outputs are the executor's generated state output, not evaluation scores.

## External Registry

The controlled external registry was read only for OMR-C09 V4 after the raw output records a valid O3 impact trigger. Other rows did not use registry contents.
"@
Set-Content -LiteralPath (Join-Path $RunRoot "OMR_context_and_limitations.md") -Value $Limitations -Encoding UTF8

$Interventions = @(
  '{"timestamp":"2026-06-19T00:00:00-07:00","actor":"executor","trigger":"package setup","change":"Created run-local directories and sanitized executor-only fixture copy with evaluator_view withheld markers.","reason":"Prevent executor exposure to evaluator-only fields.","affected_attempt":"all","tokens_added":null,"latency_added_ms":null,"whether_behavioral_scoring_contaminated":false}',
  '{"timestamp":"2026-06-19T00:00:00-07:00","actor":"executor","trigger":"OMR-C09 V4 impact trigger","change":"Read EXTERNAL_DEPENDENCY_REGISTRY_v0.1.yaml for REGISTRY-OMR-C09 after recording valid O3 impact trigger in raw execution path.","reason":"V4 impact job protocol permits registry access for OMR-C09 only after trigger.","affected_attempt":"OMR-RAW-2026-06-19-035","tokens_added":null,"latency_added_ms":null,"whether_behavioral_scoring_contaminated":false}'
)
Set-Content -LiteralPath (Join-Path $RunRoot "OMR_manual_intervention_log.jsonl") -Value $Interventions -Encoding UTF8

$Handoff = @"
# OMR Lateral Evaluator Handoff

Package: OMR_Lateral_Eval_Input_Package_2026-06-19.zip
Run series: OMR-RAW-EXEC-2026-06-19

## Required Evaluator Posture

This is an executor-only raw evidence package. It is not scored. No blinded scoring was performed. No evaluator verdict, architecture winner, hypothesis decision, or authority-change recommendation is included.

The evaluator should score independently using the sealed evaluator criteria in the authoritative Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.2 package, especially evaluator_view fields and EVALUATOR_SCORECARD_v0.1.csv. Do not treat executor terminal decisions as pass/fail scores.

## Gate Status

- Compression gate passed. The compressed/adopted runtime package is active.
- v0.2 package validation passed in the readiness packet.
- This raw execution used the adopted compressed source profile.

## Executor Run Status

- Every row in RUN_MATRIX_v0.1.csv has one raw first-pass output file.
- Raw outputs are first-pass unless explicitly marked otherwise; none are recovery attempts.
- No evaluator-only fields were used to produce the outputs.
- A sanitized executor-only fixture copy is included under derived_inputs/.

## Isolation and Blinding Limitations

Separate isolated executor contexts were not created. Rows labeled separate-context in the matrix were executed in the single parent executor context and are labeled accordingly. This package does not support claims of blind execution, independent scoring, separate-context cognition, live-runtime validation, or P6-compliant final evaluation.

## Contents

- OMR_raw_run_index.csv
- OMR_raw_outputs/
- OMR_execution_log.md
- OMR_context_and_limitations.md
- OMR_manual_intervention_log.jsonl
- derived_inputs/PILOT_FIXTURES_executor_only_v0.1.yaml

## Evaluator Instructions

1. Verify package hashes and row coverage against OMR_raw_run_index.csv.
2. Open the authoritative v0.2 bundle separately for sealed evaluator criteria.
3. Score independently.
4. Record any disqualification caused by single-context execution separately from behavioral output quality.
5. Preserve raw first-pass outputs as immutable evidence.
"@
Set-Content -LiteralPath (Join-Path $RunRoot "OMR_lateral_evaluator_handoff.md") -Value $Handoff -Encoding UTF8

Write-Output "Generated $($IndexRows.Count) raw outputs in $RunRoot"
