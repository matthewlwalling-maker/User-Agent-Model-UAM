# Bundle Manifest

**Bundle:** Operator Model Refinement Pilot Handoff Bundle v0.2
**Status:** Compression-gated execution package
**Primary use:** Extract ZIP into the downstream agent/project folder. Run only after compression adoption gate passes.

## Changes from v0.1

- Added `pilot_packet/COMPRESSION_RUN_GATE_v0.2.md`.
- Updated handoff, prompt, README, and package manifest for compressed-source sequencing.
- Preserved fixtures, run matrix, scorecard, thresholds, variant contracts, overlay schemas, and external dependency registry unchanged.

## Files

| File | SHA-256 | Bytes |
|---|---|---:|
| `Operator_Model_Refinement_Downstream_Handoff_v0.2.md` | `2d853a020724b42f13f3a11a5a6ba27017ba34de6678b1aaf67a86a823e63c50` | 8721 |
| `Operator_Model_Refinement_Downstream_Prompt_v0.2.md` | `135f79748e9d0ff858e29f5181adcceee1da33cb94806347271333a0449e1740` | 3966 |
| `Operator_Model_Refinement_Source_Attachments_v0.2.md` | `6b9f5dac4c5b63e25e67652b1894732c8fcba0a9fb65b4410e5f58d12e5b4da7` | 747 |
| `governing_sources/00_Agent_Builder_Deployment_Manifest_and_Authority_Map_v1.0.md` | `7c20eb6dfe31ddf8b8dfc31095e95b2e7a861e6ecf6c9e64c02570a669eeb4e2` | 7711 |
| `governing_sources/01_Agent_Builder_Core_Router_v1.0.md` | `5b082bb21fa10337c17e6c46d9aff1a080db372476602408c37884417abad95a` | 6554 |
| `governing_sources/02_Agent_Builder_Component_Registry_v1.0.md` | `d927d4e0034ca27f4685b9a7a4c0d73c9bcb0c6f0c32b7c3afa392cc7cd26b23` | 8508 |
| `governing_sources/03_Agent_Builder_Assessment_Contract_v1.0.md` | `f409a4b242059e71cc2fa906da97da0de15e2137d56b5c2af2a56bb446a9a2f5` | 5717 |
| `governing_sources/05_Agent_Builder_AB1-AB9_Registry_v3.0.md` | `60c864d7a292f75ca2b83faafea17bcb9261a4f2d65565f516ecc7f843a1ebb8` | 10134 |
| `governing_sources/07_Agent_Builder_Deployment_Quickstart_v1.0.md` | `102556cadc68086b3aff5575ac82ef65118611223a7fb232e58c851668799259` | 5340 |
| `governing_sources/08_Agent_Builder_Deployment_Validation_Record_v1.0.md` | `e5c72b04e512608ef87693c6fa9456c497831971eac5245dcc0024bc69e822ed` | 7608 |
| `governing_sources/Minimum_Composition_Spike_Architect_Agent_Builder_Experiment_v0.1.md` | `e09c6b4b748e690d6162fa8a799a0042decc84065078520300a12f7c559dfa61` | 68670 |
| `governing_sources/Operator Model Refinement.pdf` | `b5c3e5cc93a41db970cd11fa8e840f7bda9be555c16edb6b46b4dc3462d19af8` | 66419 |
| `governing_sources/P1_Prototype_Authority_and_Scope_v0.1.md` | `c824cd72c8d9ca819234b1cb06950fcadaa2b1d62b828c9a6638bb6eb1ee8e5d` | 8696 |
| `governing_sources/P2_State_Schemas_v0.1.json` | `05d19c0e372070caa87ef30e3d57466d2bfbb5631b372c894f9dedab8c6f14e3` | 82258 |
| `governing_sources/P3_Operator_Runtime_Contracts_v0.1.md` | `014f2e97db00accf862aa75bda6e93a2d826571f277469540b5d4e81c4f48596` | 17214 |
| `governing_sources/P4_Selector_and_State_Transition_Protocol_v0.1.md` | `2a87cdd11260a3b6209138f00e7f9a60fcb0f0f396540833e3d80c1444d7291d` | 9639 |
| `governing_sources/P5_Executor_View_v0.1.yaml` | `ad689ece75ffb6d4da72a41e23e7cf1e354292b9b5f69460aabf99c36c3a8c66` | 8153 |
| `governing_sources/P6_AB_Run_and_Evidence_Capture_Protocol_v0.1.md` | `af1baf27c6389bdd0544a2304dfef5c119a40945ec80e2066bda5a32ae7d4e67` | 11960 |
| `governing_sources/P7_Prototype_Build_Validation_Record_v0.1.md` | `22b13a98a9d4ebf0d599dc3bc06f859551d66cbdc080cea0342a3863d52af18a` | 6293 |
| `governing_sources/PACKAGE_CHECKSUMS.md` | `befa1a8ce5edad128bf969e22dc31964cc59bce082bd27ddbc62fb2378691b5a` | 1014 |
| `pilot_packet/COMPRESSION_RUN_GATE_v0.2.md` | `e7e1314f63e34c5e510cd374d328eb0ab831de9d68a0a328f23f6211e99ce860` | 5961 |
| `pilot_packet/DECISION_THRESHOLDS_v0.1.md` | `2bc3c169d3a9b1527be1d9fbb24c089e70ffb7ebabb414c877bc9e4df867a0ab` | 3162 |
| `pilot_packet/EVALUATOR_SCORECARD_v0.1.csv` | `2189dcb79f06531bb31e9a89e2dc630fc96874d68b7273dd6242571032a21a36` | 814 |
| `pilot_packet/EXPERIMENTAL_OVERLAY_SCHEMAS_v0.1.json` | `8a67fcf8600cc1a65e8c0bbd0c7d3390fc16d903f3d41582dfad2ac97d9036df` | 6818 |
| `pilot_packet/EXTERNAL_DEPENDENCY_REGISTRY_v0.1.yaml` | `3772ee62e87114eb99a0dfddf39134ed58441588254f2d9498b87f1e489aaa1c` | 1060 |
| `pilot_packet/PACKAGE_MANIFEST.md` | `90388286a08ce853cc3b815e697d0ea1d34cfca255751dc87ae1c88f4ac942f2` | 3976 |
| `pilot_packet/PILOT_FIXTURES_v0.1.yaml` | `7a36def5fbdc2041c2942075cc274cdaea5a88b6d31e3c7f6fe95208df338b69` | 20673 |
| `pilot_packet/README.md` | `4cf1ae6b2664a0db3a0c70ac368ca1988e225cae7c2c0a569b3277754be4114a` | 7443 |
| `pilot_packet/RUN_MATRIX_v0.1.csv` | `ddc110f0e7b79600b618de0d513a182d1d59f31c750fe1eff5e7c9a62cca70fe` | 1650 |
| `pilot_packet/VARIANT_CONTRACTS_v0.1.md` | `f0c32e61194fce949d824af3ae74af4d39a2ca42639722a452bb3a13ea782f4e` | 5498 |
