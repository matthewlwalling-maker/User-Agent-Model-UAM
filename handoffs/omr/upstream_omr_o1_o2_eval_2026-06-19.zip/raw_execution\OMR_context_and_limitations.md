﻿# OMR Context and Limitations

Run series: OMR-RAW-EXEC-2026-06-19

## Context Policy

This was executed in the parent Codex context as a single-agent executor-only simulated run. Separate isolated execution contexts were not created. The raw outputs therefore do not support claims of separate-context cognition, blind execution, independent evaluation, or P6-compliant scoring.

Rows whose matrix condition is separate-context record the intended condition in metadata and raw output, but because execution occurred in one parent context, the actual context_id is parent-thread-single-context. Treat those rows as executor-only simulated outputs with an isolation limitation.

## Evaluator Visibility

The executor did not open or use evaluator-only fields while producing run outputs. A sanitized fixture copy was created and used for case content. The lateral evaluator should use the sealed evaluator criteria from the authoritative v0.2 bundle independently.

## Scoring Boundary

No pass/fail score, quality metric, safety metric, branch metric, challenge metric, activation metric, burden metric, hypothesis disposition, or architecture verdict is included here. Any terminal OMR decision names inside raw outputs are the executor's generated state output, not evaluation scores.

## External Registry

The controlled external registry was read only for OMR-C09 V4 after the raw output records a valid O3 impact trigger. Other rows did not use registry contents.
