# Manifest - Upstream OMR O1/O2 Eval Handoff

Date: 2026-06-19
Package folder: `Project State/Handoffs/upstream_omr_o1_o2_eval_2026-06-19/`
Package zip: `Project State/Handoffs/upstream_omr_o1_o2_eval_2026-06-19.zip`
Completeness: self-contained for upstream O1/O2 evaluation.

## Handoff Resources

Provide one file to the upstream agent:

`Project State/Handoffs/upstream_omr_o1_o2_eval_2026-06-19.zip`

No supplemental workspace paths are required for upstream O1/O2 evaluation if this zip is attached. The zip includes the raw evidence, source authorities, compression evidence, pilot controls, readiness records, prompt, and manifest.

## Included Resource Categories

### Prompt And Instructions

- `README.md`
- `HANDOFF_PROMPT.md`
- `MANIFEST.md`

### Raw Execution Evidence

- `raw_execution/OMR_Lateral_Eval_Input_Package_2026-06-19.zip`
- `raw_execution/OMR_raw_run_index.csv`
- `raw_execution/OMR_raw_outputs/`
- `raw_execution/OMR_execution_log.md`
- `raw_execution/OMR_context_and_limitations.md`
- `raw_execution/OMR_manual_intervention_log.jsonl`
- `raw_execution/OMR_lateral_evaluator_handoff.md`
- `raw_execution/derived_inputs/`

### Adopted Compressed Runtime Source Surface

- `source_authority/AB_Runtime_Authority_Reference_v1.1.md`
- `source_authority/AB_GoalCompleteness_Procedure_and_Evals_v1.1.md`
- `source_authority/OMR_Operator_Prototype_Runtime_v0.2.md`
- `source_authority/P2_State_Schemas_v0.1.json`
- `source_authority/P5_Executor_View_v0.1.yaml`
- `source_authority/AGENTS_current.md`

### Compression And Adoption Evidence

- `compression_evidence/compression-adoption-record_2026-06-18.md`
- `compression_evidence/post-adoption-sentinel-results_v0.1.md`
- `compression_evidence/source-checksums_pre-and-post-compression.md`
- `compression_evidence/compression-map_v0.1.md`
- `compression_evidence/compression-run-record_2026-06-18.md`

### Pilot Controls

- `pilot_bundle/Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.2.zip`
- `pilot_bundle/BUNDLE_MANIFEST.md`
- `pilot_bundle/RUN_MATRIX_v0.1.csv`
- `pilot_bundle/VARIANT_CONTRACTS_v0.1.md`
- `pilot_bundle/EVALUATOR_SCORECARD_v0.1.csv`
- `pilot_bundle/PILOT_FIXTURES_v0.1.yaml`
- `pilot_bundle/COMPRESSION_RUN_GATE_v0.2.md`

### Readiness Context

- `readiness/RUN_READINESS_VERDICT.md`
- `readiness/VALIDATION_INDEX.md`

## Known Limitations

- Raw execution was single-agent executor-only and simulated/design-time.
- Separate isolated executor contexts were not created.
- No blinded scoring or independent evaluator verdict has been performed.
- This package supports upstream O1/O2 review, not final OMR scoring.

## Hashes

See `SHA256SUMS.txt`.
