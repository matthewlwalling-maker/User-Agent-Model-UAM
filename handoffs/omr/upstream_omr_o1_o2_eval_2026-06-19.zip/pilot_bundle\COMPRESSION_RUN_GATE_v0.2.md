# Compression Gate and Source-Freeze Addendum — OMR Pilot Package v0.2

**Package:** Operator Model Refinement Pilot  
**Addendum version:** 0.2  
**Status:** Required pre-run gate  
**Authority effect:** Operational sequencing only. This addendum does not change fixtures, scoring thresholds, P1-P7 authority, P2 schemas, P3 contracts, P4 transitions, or AB1-AB9 rules.

## 1. Decision

The OMR pilot should not be run until the file-compression candidate has passed the post-compression sentinel retest and received an adoption decision of `ADOPT`.

The pilot package is therefore updated from:

`ready to run against current uncompressed sources`

to:

`hold for validated compressed-source package, then run with compressed source freeze`.

## 2. Why this addendum exists

Compression changes the artifact surface that the agent will read. Even if the compression target is semantic equivalence, merged or shortened files can change behavior by removing examples, authority cues, ordering cues, or redundancy that models rely on.

The pre-compression sentinel baseline was green, but it was an unblinded simulated screening. It creates a behavioral fingerprint for compression comparison; it does not establish live-runtime or P6-compliant comparative validity.

## 3. Required upstream artifacts before running OMR pilot

Do not start Stage S until all of the following are present:

1. `File_Compression_Handoff_Packet_v0.1.zip` was executed or explicitly superseded.
2. A compressed candidate package exists in the project folder.
3. A compression map exists showing how each original authority owner maps into the compressed candidate.
4. Pre- and post-compression SHA-256 hashes exist.
5. Post-compression retest S01-S10 was run unchanged.
6. The mixed AB/O smoke case was run.
7. The compression decision is `ADOPT`.

If the compression decision is `PATCH_THEN_RETEST`, stop and wait for a patched compression candidate and a new retest. If the decision is `DO_NOT_ADOPT`, either run the pilot explicitly against the uncompressed source package or abandon the pilot until a new compression attempt is validated. Do not mix uncompressed and compressed results inside one run series.

## 4. Source profile for OMR pilot after compression

When compression is validated, freeze the OMR run with:

```text
source_profile = compressed-adopted
source_package_ref = <compressed package path or ZIP name>
compression_adoption_record = <compression-run-record file>
compression_map_ref = <compression-map file>
post_compression_sentinel_record = <post-compression retest file>
```

The compressed package is the source surface actually supplied to executors. The compression map is used only to resolve original authority ownership and to explain equivalence. Do not silently read original uncompressed sources to rescue a compressed-source run unless the run is explicitly labeled `uncompressed-control` or `debug-not-scored`.

## 5. What changed in v0.2

Changed:

- downstream handoff now requires a successful compression gate before pilot execution;
- downstream prompt references the v0.2 ZIP package directly;
- package README now states that fixture execution is held until compressed-source adoption;
- run-freeze expectations include compressed-source digest and compression map;
- a post-compression sentinel/smoke-case dependency is now a hard precondition.

Unchanged:

- `PILOT_FIXTURES_v0.1.yaml`;
- `RUN_MATRIX_v0.1.csv`;
- `EVALUATOR_SCORECARD_v0.1.csv`;
- `DECISION_THRESHOLDS_v0.1.md`;
- `VARIANT_CONTRACTS_v0.1.md`;
- experimental overlay schemas and external dependency registry;
- governing P1-P7 and AB1-AB9 source files bundled for reference.

## 6. Compression-sensitive pilot protections

The OMR pilot conductor must verify that the validated compressed package preserves the following sentinel behaviors before any pilot run:

| Rule | Required preservation |
|---|---|
| Material capability-before-asset order | independent capability model remains before asset mapping |
| Evidence ceiling | design-time/spec evidence cannot become runtime/production validation |
| No-material-change | remains a valid success state |
| Illegal flag/action rejection | `+open-architecture` with `.assess-only` rejects before execution |
| O2-before-O3 | coverage cannot begin without a current CapabilityModel |
| Semantic reach | second-degree propagation is not treated as local merely because the text edit is nearby |
| Block-only impact handling | missing dependency facts produce impact job / block-only, not invented reach |
| Branch handling | no silent union; invariant versus decision-material disagreement preserved |
| Trivial burden gate | compact path remains available for low-coupling targets |
| AB/O separation | AB1-AB9 lifecycle routing remains distinct from O1-O4 operator-state sequencing |

## 7. Run invalidation rule

A pilot run is invalid if:

- the compressed package was not adopted;
- the compressed-source digest differs from the freeze record;
- the compression map cannot resolve original authority ownership;
- executors receive a mix of compressed and uncompressed sources without stratification;
- a post-compression sentinel critical behavior regressed;
- the run claims compressed-source validation but did not preserve raw compression retest evidence.

## 8. Adoption fork

After compression:

- `ADOPT` → run OMR Pilot v0.2 against the compressed-adopted source profile.
- `PATCH_THEN_RETEST` → do not run OMR pilot; repair compression and rerun S01-S10 plus smoke.
- `DO_NOT_ADOPT` → either run OMR Pilot v0.1/v0.2 against original uncompressed sources with `source_profile=uncompressed-control`, or defer pilot until compression is solved.

## 9. Evidence ceiling

A successful post-compression sentinel retest supports only compression behavioral equivalence at simulated/design-time screening. It does not support live-runtime, production-observed, blinded, or P6-compliant comparative claims.
