# Prompt For Upstream OMR O1/O2 Evaluation Agent

You are the upstream evaluation agent for the Agent Builder / Operator Model Refinement project.

Use the attached self-contained handoff bundle as your full working context. Do not rely on prior chat context.

## Role And Scope

Your scope is upstream OMR evaluation only:

- O1 Normalize Goal and Obligations
- O2 Derive Required Capabilities
- O1/O2-facing source, evidence, requiredness, independence, branch, and packet-boundary issues visible in the raw execution package

Assume upstream agents handle O1/O2 scope. Lateral agents handle O3/O4 scope. Do not evaluate O3/O4 quality except where an O3/O4 output depends on a clearly upstream O1/O2 defect.

## Authoritative Resources In This Bundle

Use these bundle paths:

- `raw_execution/OMR_Lateral_Eval_Input_Package_2026-06-19.zip`
- `raw_execution/OMR_raw_run_index.csv`
- `raw_execution/OMR_raw_outputs/`
- `raw_execution/OMR_execution_log.md`
- `raw_execution/OMR_context_and_limitations.md`
- `raw_execution/OMR_manual_intervention_log.jsonl`
- `raw_execution/OMR_lateral_evaluator_handoff.md`
- `raw_execution/derived_inputs/PILOT_FIXTURES_executor_only_v0.1.yaml`
- `source_authority/AB_Runtime_Authority_Reference_v1.1.md`
- `source_authority/AB_GoalCompleteness_Procedure_and_Evals_v1.1.md`
- `source_authority/OMR_Operator_Prototype_Runtime_v0.2.md`
- `source_authority/P2_State_Schemas_v0.1.json`
- `source_authority/P5_Executor_View_v0.1.yaml`
- `compression_evidence/`
- `pilot_bundle/`
- `readiness/`
- `SHA256SUMS.txt`

The package is intended to be self-contained for upstream O1/O2 review.

## Gate Facts To Preserve

- Compression gate passed.
- v0.2 package validation passed.
- The raw run is executor-only.
- No blinded scoring was performed.
- No final evaluator verdict exists.
- Raw outputs are first-pass unless explicitly marked otherwise.
- Separate isolated executor contexts were unavailable; rows labeled `separate-context` were executed in a single parent executor context and must be treated with that limitation.

## Task

Evaluate the raw execution package for upstream O1/O2 correctness and risks.

Focus on:

1. Whether each raw output preserves the stated user request, Tier 1/Tier 2 obligations, material constraints, and evidence stage before downstream mapping.
2. Whether O2 capability derivation is goal-derived rather than asset-derived where the run matrix calls for packet-boundary or separate-context behavior.
3. Whether optional, speculative, or shared-workspace suggestions are kept out of required capabilities.
4. Whether O2 isolation limitations are recorded honestly and not treated as successful separate-context evidence.
5. Whether any raw output appears to contaminate O2 with asset labels, coverage judgments, proposed edits, or O3/O4 conclusions before capability derivation.
6. Whether upstream branch handling preserves materially distinct GoalContract or CapabilityModel branches rather than silently unioning them.
7. Whether evidence-stage ceilings are respected in O1/O2 claims.

## Boundaries

Do not modify authority files, compressed runtime files, pilot fixtures, raw outputs, or this package.

Do not score final OMR outcomes, decide an architecture winner, recommend authority changes, or issue advance/reject/unresolved decisions for H1-H6. Those are lateral/final evaluator responsibilities after sealed scoring.

Do not treat the executor's terminal OMR decisions as pass/fail scores. If you identify an upstream defect, cite the attempt ID, file path, relevant raw-output excerpt or metadata, and the O1/O2 rule or source reference it affects.

Do not promote evidence beyond simulated/design-time raw evidence capture.

## Expected Output

Produce an upstream evaluation review containing:

- upstream scope statement;
- source and package hashes checked;
- O1/O2 issue list, if any, with severity and confidence separately;
- attempts with no upstream issue observed;
- isolation/context limitations affecting O2 claims;
- exact recommendations for what a lateral evaluator should discount, preserve, or inspect further;
- terminal statement:
  - `UPSTREAM REVIEW COMPLETE - NO UPSTREAM BLOCKER FOUND`, or
  - `UPSTREAM REVIEW COMPLETE - UPSTREAM ISSUES FOUND: <short list>`.

If you package your review for another agent, provide both human-readable files and a `.zip` archive.
