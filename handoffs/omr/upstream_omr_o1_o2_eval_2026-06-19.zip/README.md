# Upstream OMR O1/O2 Evaluation Handoff

Date: 2026-06-19
Bundle purpose: self-contained upstream-agent review package for O1/O2-scope evaluation of the executor-only OMR raw run.
Evidence ceiling: simulated/design-time raw evidence capture.

## Status

This package is self-contained for upstream O1/O2 review. It includes the raw executor outputs, source authority surface, compression/adoption evidence, pilot controls, readiness context, manifest, and copy of the upstream prompt.

The upstream agent should not modify authority files, compressed runtime files, pilot fixtures, raw outputs, or this package. The task is review/evaluation only.

## Scope

Upstream review covers:

- O1 Normalize Goal and Obligations
- O2 Derive Required Capabilities
- O1/O2 evidence ceilings, requiredness, branch handling, source/provenance, packet-boundary, and isolation limitations

Upstream review does not cover:

- final OMR scoring
- O3/O4 quality except where caused by an upstream defect
- architecture winner selection
- H1-H6 disposition
- authority-change recommendation

## Contents

- `HANDOFF_PROMPT.md` - copy-paste-ready prompt for the upstream agent.
- `MANIFEST.md` - package inventory and handoff resource statement.
- `raw_execution/` - raw executor package and extracted raw run files.
- `source_authority/` - adopted compressed runtime source surface plus current root instructions.
- `compression_evidence/` - adoption, sentinel, map, run record, and checksum evidence.
- `pilot_bundle/` - authoritative v0.2 pilot zip and key pilot controls.
- `readiness/` - prior readiness verdict and validation index.
- `SHA256SUMS.txt` - generated file hashes for package contents.

## Terminal Instruction

The upstream agent should end with one of:

- `UPSTREAM REVIEW COMPLETE - NO UPSTREAM BLOCKER FOUND`
- `UPSTREAM REVIEW COMPLETE - UPSTREAM ISSUES FOUND: <short list>`
