---
name: version-comparison
description: Compare versions, proposals, components, or model outputs against one frozen objective and capability model. Use for delta reviews, blind comparisons, donor-component selection, winner analysis, or synthesis. Do not use when the comparison criteria are not yet defined or when implementation is requested.
---

# Version Comparison

## Authority and references

Read:

- `../_shared/references/common-governance-contract.md`
- `../_shared/references/canonical/03_Agent_Builder_Assessment_Contract_v1.0.md`
- `../_shared/references/canonical/05_Agent_Builder_AB1-AB9_Registry_v3.0.md`

## Inputs

Require two or more exact candidate revisions plus a frozen objective, material constraints, capability model or decision criteria, evidence stage, and authorized action.

If the criteria are missing and can be derived without inspecting candidates, state and freeze them first. If the criteria materially depend on unresolved user intent, stop with the smallest missing decision.

## Procedure

1. Freeze the comparison basis before scoring.
2. Compare behavioral support for each required capability, not prose polish.
3. Identify regressions, gains, duplicated behavior, and newly introduced risks.
4. Keep confidence and evidence stage explicit.
5. Rank candidates only where the frozen basis supports a ranking.
6. Identify donor components from non-winning candidates when they improve the selected target without importing their weaknesses.
7. Preserve ties, branch-specific winners, or unresolved tradeoffs when one universal winner is not defensible.
8. Recommend a synthesis only when component compatibility and structural reach are established.

## Output

- frozen comparison basis;
- capability-by-capability comparison;
- meaningful gains and regressions;
- ranked result or explicit non-ranking;
- donor-component recommendations;
- synthesis recommendation where warranted;
- evidence limitations and next action.

## Boundaries

- Do not change criteria after seeing an inconvenient result.
- Do not silently union incompatible candidates.
- Do not modify artifacts; hand authorized edits to `artifact-change`.
