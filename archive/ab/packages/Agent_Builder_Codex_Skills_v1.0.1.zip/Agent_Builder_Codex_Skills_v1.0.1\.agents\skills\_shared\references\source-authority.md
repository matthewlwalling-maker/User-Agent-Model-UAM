# Source Authority and Deployment Boundary

## Deployed authority

Resolve conflicts by domain using the canonical deployment bundle:

1. `00` — package scope, authority, supersession, release status.
2. `01` — Prompt Macro recognition, parsing, defaults, dispatch.
3. `02` — legal tokens, compatibility, actions, evidence stages, N+1/N+2 boundaries.
4. `03` — shared assessment contract, evidence ceilings, fix placement, stop rules.
5. `04` — Goal-Completeness and Open-Architecture procedure.
6. `05` — AB1–AB9 roles, modes, handoffs, default routes.
7. `06` — E1–E12 adversarial validation and scoring.
8. `07` — operator quickstart.
9. `08` — release status and gate conditions.

All files are under `references/canonical/` relative to this shared directory.

## Experimental material

The O1–O4 minimum-composition prototype is retained under `/future/experimental-operator-prototype/`. It is design-time experimental evidence only. It does not replace or override the deployed AB1–AB9 framework, and no deployed Skill may silently require its typed state objects.

## Evidence ceiling

The source framework is Yellow: deployable with named limitations at design-time and simulated evidence. Do not claim live-runtime or production-observed validation without new evidence from the active environment.
