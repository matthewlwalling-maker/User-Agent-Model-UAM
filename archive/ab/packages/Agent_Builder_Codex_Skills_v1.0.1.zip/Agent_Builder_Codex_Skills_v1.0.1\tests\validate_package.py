#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / '.agents' / 'skills'
EXPECTED = {
    'architecture-assessment', 'artifact-change', 'adversarial-evaluation',
    'version-comparison', 'failure-triage', 'deployment-readiness',
    'handoff-package', 'prompt-macro-router'
}
errors = []
found = set()
for p in SKILLS.glob('*/SKILL.md'):
    name = p.parent.name
    found.add(name)
    text = p.read_text(encoding='utf-8')
    if not text.startswith('---\n'):
        errors.append(f'{name}: missing YAML front matter')
    m_name = re.search(r'^name:\s*(\S+)\s*$', text, re.M)
    m_desc = re.search(r'^description:\s*(.+)$', text, re.M)
    if not m_name or m_name.group(1) != name:
        errors.append(f'{name}: front-matter name mismatch')
    if not m_desc or len(m_desc.group(1).strip()) < 40:
        errors.append(f'{name}: description missing or too short')
    if not (p.parent / 'agents' / 'openai.yaml').is_file():
        errors.append(f'{name}: missing agents/openai.yaml')
if found != EXPECTED:
    errors.append(f'skill set mismatch: found={sorted(found)}')

for n in range(9):
    prefix = f'{n:02d}_' if n else '00_'
# Exact canonical inventory.
required_canonical = [
'00_Agent_Builder_Deployment_Manifest_and_Authority_Map_v1.0.md',
'01_Agent_Builder_Core_Router_v1.0.md',
'02_Agent_Builder_Component_Registry_v1.0.md',
'03_Agent_Builder_Assessment_Contract_v1.0.md',
'04_Goal-Completeness_and_Open-Architecture_Procedure_v1.0.md',
'05_Agent_Builder_AB1-AB9_Registry_v3.0.md',
'06_Goal-Completeness_E1-E12_Adversarial_Eval_Suite_v1.0.md',
'07_Agent_Builder_Deployment_Quickstart_v1.0.md',
'08_Agent_Builder_Deployment_Validation_Record_v1.0.md']
canon = SKILLS / '_shared' / 'references' / 'canonical'
for name in required_canonical:
    if not (canon / name).is_file():
        errors.append('missing canonical source: ' + name)

router_yaml = (SKILLS / 'prompt-macro-router' / 'agents' / 'openai.yaml').read_text(encoding='utf-8')
if 'allow_implicit_invocation: false' not in router_yaml:
    errors.append('router must disable implicit invocation')

if errors:
    print('\n'.join('FAIL: ' + e for e in errors))
    sys.exit(1)
print(f'PASS: {len(EXPECTED)} skill folders and canonical references validated')
