---
name: deployment-readiness
description: Gate deployment or release readiness for a prompt framework, Codex Skill, agent system, resource package, or repository change. Use to issue Green, Yellow, Red, or Blocked from implementation, test, integration, resource, and risk evidence. Do not use to create missing implementation or invent evidence.
---

# Deployment Readiness

## Authority and references

Read:

- `../_shared/references/common-governance-contract.md`
- `../_shared/references/source-authority.md`
- `../_shared/references/canonical/05_Agent_Builder_AB1-AB9_Registry_v3.0.md`
- `../_shared/references/canonical/08_Agent_Builder_Deployment_Validation_Record_v1.0.md`

## Inputs

Require: target architecture and revision, implementation record, test results, resource inventory, integration evidence, residual risks, required claim stage, and non-negotiable gates.

## Procedure

1. Verify exact target and source revisions.
2. Confirm implementation matches the committed architecture.
3. Confirm required regressions and non-negotiable tests ran at the required evidence stage.
4. Check resource completeness, authority, freshness, compatibility, integration, and unresolved risks.
5. Treat absent evidence as unverified, not positive.
6. Issue exactly one decision:
   - Green: all required gates verified at the required stage;
   - Yellow: deployable with named limitations and bounded residual risk;
   - Red: material gate failed;
   - Blocked: required evidence or dependency is unavailable.
7. State exact conditions to advance and the next responsible operation.

## Output

Use `../_shared/assets/readiness-record-template.md` and include:

- decision first;
- gate evidence stage;
- verified gates;
- failed/unverified gates;
- named limitations and residual risks;
- exact advancement conditions;
- next operation.

## Boundaries

- Never issue Green from design-time plausibility alone when post-implementation or runtime evidence is required.
- Do not fix the artifact during the gate.
- A previous readiness label never overrides newer contradictory evidence.
