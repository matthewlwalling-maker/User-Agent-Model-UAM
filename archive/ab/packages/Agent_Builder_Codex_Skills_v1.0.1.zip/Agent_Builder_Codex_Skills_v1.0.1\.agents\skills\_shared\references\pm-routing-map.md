# Prompt Macro to Codex Skill Routing Map

| Host | Natural-language name | Skill | Profile |
|---|---|---|---|
| AB1 | Iteration, Component Analysis, Patch & Rewrite | `artifact-change` | patch / augment / rewrite / implement |
| AB2 | Evaluation Design & Runtime Harness | `adversarial-evaluation` | adversarial / regression / verification / blind |
| AB3 | Version, Baseline & Component Comparison | `version-comparison` | delta / blind / independent / component |
| AB4 | Architecture, Boundary, Resource Placement & Compression Review | `architecture-assessment` | holistic / component / goal-completeness / independent |
| AB5 | Deployment, Resource & Integration Readiness Gate | `deployment-readiness` | readiness gate |
| AB6 | Failure Triage, Fix Placement & Regression Verification | `failure-triage` | procedural or behavioral failure diagnosis |
| AB7 | Runtime Behavior, Usability & Interface Calibration | `failure-triage` | runtime-calibration profile; evidence required |
| AB8 | Handoff, Migration & State Preservation Pack | `handoff-package` | state-preserving handoff |
| AB9 | Prompt Packaging, Compression & Execution Packet Builder | `handoff-package` | compact portable package |

One Prompt Macro selects one primary operational owner. Handoffs are recommendations for a separately authorized invocation, not automatic chains.
