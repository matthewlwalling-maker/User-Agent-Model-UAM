# Readiness Record

- Decision: Green / Yellow / Red / Blocked
- Gate evidence stage:
- Target revision:

## Verified gates

## Unverified or failed gates

## Named limitations and residual risks

## Exact conditions to advance

## Next responsible operation
