# Installation and First Use

## Repo-scoped installation

Copy the package contents into the root of the target repository so these paths exist:

- `AGENTS.md`
- `.agents/skills/<skill-name>/SKILL.md`
- `.agents/skills/_shared/...`

Launch Codex from that repository or a descendant directory. Codex scans `.agents/skills` from the current working directory to the repository root.

## Validate the package

```powershell
python .\.agents\skills\_shared\scripts\validate_pm_invocation.py --json "AB4.goal-completeness.assess this architecture.design-time.recommend"
python .\tests\validate_package.py
python -m unittest discover -s .\tests -p "test_*.py"
```

## First smoke tests

```text
$architecture-assessment Assess whether this bounded formatter is complete.
AB4.goal-completeness.assess whether this workflow is complete.design-time.recommend
$prompt-macro-router AB4.goal-completeness.add missing pieces.augment
```

The third input must fail because an explicit action lacks its mandatory evidence stage.

## User-level installation

After repo-scoped validation, the seven Skill directories can be copied to `$HOME/.agents/skills`. The root Prompt Macro compatibility rule still needs an applicable `AGENTS.md` or equivalent governing instruction. User-level rollout is not part of the v1 readiness claim.
