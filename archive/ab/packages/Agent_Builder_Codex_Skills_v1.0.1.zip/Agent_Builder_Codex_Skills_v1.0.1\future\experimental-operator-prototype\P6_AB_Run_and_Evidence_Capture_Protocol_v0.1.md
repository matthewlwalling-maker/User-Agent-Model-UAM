# P6 — A/B Run and Evidence-Capture Protocol

**Version:** 0.1  
**Systems:** unchanged legacy Goal-Completeness control and P1–P4 operator prototype  
**Scoring owner:** separate blinded evaluator, not the builder or run executor

## 1. Run roles

- **Fixture custodian:** freezes P5, withholds evaluator-only traps, selects holdouts.
- **Run executor:** executes both systems, captures raw evidence, performs no scoring.
- **Independent evaluator:** first-pass blind scoring, then architecture/failure diagnosis.
- **Builder:** may answer implementation questions but may not alter a frozen run series after seeing outputs.

A single technical agent may execute both systems only if it does not score them, uses isolated run contexts, retains raw prompts/outputs, and logs every manual intervention.

## 2. Source and implementation freeze

Before a run series, record:

- SHA-256 of P1–P7 and governing sources;
- exact operator prompts/contracts and schema version;
- exact legacy source versions, unchanged;
- model/provider/version, decoding parameters, tool access, and context policy;
- fixture pack digest and visibility filter;
- timestamp and run-series ID.

A material change starts a new series. Results from different series are not pooled without explicit stratification.

## 3. Equivalent inputs and evidence

For each fixture:

1. Both systems receive the same public user request, constraints, asset version/content, dependency facts, and evidence entries.
2. Evidence stage and requested claim are identical.
3. Hidden traps, expected outputs, and scoring rules are withheld from both systems.
4. The operator path receives no AB1–AB9 routing or invocation schema.
5. The legacy path receives the canonical Assessment Contract, Procedure, E1–E12 behavior, and Registry semantics required by the fixture; it is not weakened, compressed, or rewritten.
6. If a fixture starts from state, the legacy control receives an equivalent frozen textual handoff containing the same substantive goal/capability/evidence facts, while the operator receives typed state. Differences in state format are part of the architecture under test and must be measured.

## 4. Equivalent independence conditions

### Condition PB — packet-boundary

**Operator:** O2 receives only the committed GoalContract plus permitted goal/constraint ledger entries. The same broader model context may previously have seen the asset. The run is labeled `packet-boundary`, never full cognitive independence.

**Legacy:** in the same broader-context condition, the evaluator is instructed to execute the unchanged Material procedure and produce/freeze Block A/B from the goal/constraints before mapping. The exact immediate capability-derivation packet is recorded. Prior asset exposure is logged. No claim of full cognitive independence is permitted.

### Condition SC — separate-context

**Operator:** O2 runs in a fresh context that has never received the asset. After CapabilityModel commitment, a separate O3 context or continuation receives the asset and exact state packet.

**Legacy:** a fresh context receives the same goal/constraint evidence and the unchanged legacy procedure, produces and seals Blocks A/B, then receives the asset for Blocks C–E. The context had no prior asset exposure before the seal.

### Comparability rule

Any advantage attributed to context isolation counts only when both systems were run under the same condition. PB and SC results are reported separately. Do not attribute an SC advantage to typed operators if the legacy control was only run under PB.

C01, C05, C09A, and C09B must run under both PB and SC. Other Material fixtures may use both when cost permits. Trivial fixtures use their canonical lightweight path and do not require a separate-context seal unless the fixture explicitly tests anchoring.

## 5. System randomization and blinding

For each fixture-condition-replicate cell:

1. Randomly assign the operator and legacy outputs to `System A` and `System B` using a seeded randomization table held by the fixture custodian.
2. Randomize A/B presentation order independently per case.
3. Strip architecture-identifying headings only when doing so does not remove required evidence artifacts. Preserve raw outputs separately.
4. The evaluator scores behavior first without the key or builder prediction.
5. After first-pass scoring is locked, reveal architecture/state records for failure attribution and burden analysis.

## 6. Execution unit and identifiers

Each execution has:

```text
run_series_id
case_id / variant_id
condition = PB|SC|standard
replicate_id
system_key = hidden operator|legacy
blind_label = A|B
context_id(s)
model/runtime configuration
start/end timestamps
source and artifact digests
```

Do not overwrite a failed execution. A retry receives a new `attempt_id` and relation `recovery_of`.

## 7. Raw evidence retention

### Both systems

- exact input messages and resource attachments;
- exact raw output, including rejected requests and error text;
- token counts and timing;
- clarifications and user/custodian responses;
- tool calls and errors;
- manual interventions, edits, restarts, and repairs;
- final visible answer.

### Operator system additionally

- every selector decision and rejected-selection log;
- every ExecutionPacket manifest;
- exact O2 packet contents and hash;
- all five object snapshots, revisions, branches, parents, hashes, status/freshness;
- full or projected EvidenceLedger plus digest and append deltas;
- schema and semantic validation results;
- invalidated/stale objects retained, not deleted;
- local stop/failure exits and global ChangeDecision.

### Legacy additionally

- scaling-gate declaration;
- Goal Model and Required Capability Model blocks;
- independence seal or Trivial-path equivalent;
- exact point of first asset reference;
- coverage map/findings, gap/sufficiency, action/fix layer, evidence and stop result;
- any invocation validation/rejection trace required by E11.

A correct conclusion without the required trace, state, seal, rejection, or evidence artifact is scored as a failure for that condition.

## 8. P5 visibility and fixture execution

The run executor receives only `executor_view` plus public variant inputs. `evaluator_view`, hidden traps, prohibited behavior, and objective scoring conditions remain sealed until all raw runs are locked. A deterministic export/filter may create the executor view; that filter is packaging and does not alter the fixture content.

## 9. Measurement definitions

Record each metric per attempt and aggregate by case/profile/condition/system.

| Metric | Definition |
|---|---|
| `input_tokens` | All user/system/resource tokens consumed for the execution, including state packets |
| `output_tokens` | All generated tokens, including intermediate state and rejected attempts |
| `total_tokens` | input + output |
| `wall_latency_ms` | first request submission to final terminal output, including handoffs and retries |
| `model_latency_ms` | sum of model execution time where available |
| `handoff_count` | context or agent boundary crossings required to reach terminal output |
| `clarification_count` | distinct clarification questions sent to a human/custodian |
| `manual_intervention_count` | human edits, prompt repairs, state corrections, restarts, or selection overrides |
| `state_repair_count` | operator-state/schema/branch/stale repairs; zero for legacy unless equivalent handoff repair occurs |
| `recovery_attempts` | attempts after first-pass failure before a valid terminal output |
| `recovery_tokens` | tokens consumed after the first detected failure through recovery completion |
| `recovery_latency_ms` | elapsed recovery time after first detected failure |
| `context_reconstruction_tokens` | tokens needed to continue from a handoff when full prior conversation is unavailable |
| `trace_completeness` | required evidence artifacts present / required artifacts, reported as count and ratio |
| `first_pass_success` | pass with no repair/manual intervention |

Do not collapse burden into one weighted score before reporting raw measures. Any later composite must publish weights and sensitivity.

## 10. Compact-burden comparison

For C11 and the Trivial holdout, compare:

- first-pass correctness;
- critical safeguard preservation;
- total tokens;
- latency;
- number of explicit state/section artifacts;
- clarification and repair count.

Typed compact state is not justified merely because it validates. A material burden increase without fewer failures is evidence against the compact hypothesis. The independent evaluator applies the spike's decision threshold; this builder does not predeclare a numeric winner.

## 11. Failure-source attribution

Assign each failure one primary source and optional contributing sources:

1. `selector-legality`
2. `operator-O1-requiredness`
3. `operator-O2-derivation-or-independence`
4. `operator-O3-coverage`
5. `operator-O3-impact-boundary`
6. `operator-O4-decision-or-stop`
7. `state-schema-or-reference`
8. `evidence-ledger-or-stage`
9. `branch-or-conflict-handling`
10. `legacy-procedure`
11. `legacy-routing-or-invocation`
12. `fixture-ambiguity`
13. `runtime/model-variance`
14. `manual-execution-error`
15. `platform-packaging`

Attribution rules:

- outcome errors caused by missing required traces remain outcome failures;
- a schema rejection that correctly prevents an unsafe result is not a failure unless it blocks a valid run through an avoidable schema defect;
- an incorrect answer after manual repair is attributed to both the first cause and repair path;
- do not call platform packaging an architectural capability failure unless the platform-neutral contract itself is insufficient.

## 12. Manual intervention and repair log

Every intervention record contains:

```json
{
  "timestamp":"...",
  "actor":"human|executor|platform",
  "trigger":"...",
  "change":"exact text/state/config change",
  "reason":"...",
  "affected_attempt":"...",
  "tokens_added":0,
  "latency_added_ms":0,
  "whether_behavioral_scoring_contaminated":true
}
```

A repaired run never erases or upgrades the first-pass result. First-pass and recovered quality are reported separately.

## 13. Blinded evaluator handoff

### First-pass behavioral packet

- randomized A/B outputs;
- public fixture input and evidence;
- required observable checklist with architecture-neutral wording;
- no system key, builder prediction, or self-grade;
- no hidden implementation rationale.

### Second-pass diagnostic packet

After scores lock, provide:

- system key;
- immutable P1–P7 and governing sources;
- full P5 evaluator view;
- operator states, selectors, packets, ledger, validation logs;
- legacy blocks/seals/routing traces;
- burden and repair metrics;
- source/artifact digests and deviations.

### Evaluator outputs

For every case/variant/condition:

1. correct outcome;
2. required artifact presence;
3. evidence ceiling compliance;
4. sequence/precondition enforcement;
5. prohibited behavior;
6. first-pass pass/fail;
7. recovered pass/fail;
8. failure attribution;
9. burden metrics;
10. operator improved/matched/degraded legacy, with confidence.

The evaluator separately reports whether Case 8 survived, whether compact burden is justified, whether gains are behavioral versus taxonomic, and the experiment disposition. The builder does not supply that verdict.

## 14. Run completeness gate

A comparative cell is invalid and rerun (without deleting the original) when:

- source/artifact digest mismatch is unexplained;
- one system received materially different public evidence;
- independence conditions differ across systems;
- hidden evaluator fields leaked;
- raw output or required state trace is missing;
- manual repair occurred but was not logged;
- A/B key was revealed before first-pass scoring.

A system failure is not a run-invalidating event; it is evidence and must be retained.
