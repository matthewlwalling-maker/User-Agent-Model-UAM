#!/usr/bin/env python3
"""Validate and normalize Agent Builder AB1-AB9 Prompt Macro invocations."""
from __future__ import annotations
import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

MODES = {
    "holistic": "architecture",
    "component": "architecture",
    "subcomponent": "behavior",
    "delta": "architecture",
    "targeted": "behavior",
    "blind": "output",
    "independent": "architecture",
    "adversarial": "behavior",
    "regression": "verification",
    "verification": "verification",
    "goal-completeness": "architecture",
}
LENSES = {
    "intent", "architecture", "boundary", "source", "resource", "runtime",
    "safety", "behavior", "output", "efficiency", "maintainability",
    "deployment", "verification", "generalization",
}
EVIDENCE = {
    "design-time", "simulated", "live-runtime", "post-implementation",
    "production-observed",
}
ACTIONS = {
    "assess-only", "recommend", "patch", "augment", "rewrite", "implement",
    "retest", "package", "gate",
}
OPEN_ACTIONS = {"recommend", "augment", "rewrite", "implement"}
HOST_TO_SKILL = {
    "AB1": "artifact-change",
    "AB2": "adversarial-evaluation",
    "AB3": "version-comparison",
    "AB4": "architecture-assessment",
    "AB5": "deployment-readiness",
    "AB6": "failure-triage",
    "AB7": "failure-triage",
    "AB8": "handoff-package",
    "AB9": "handoff-package",
}

@dataclass
class Result:
    valid: bool
    original: str
    normalized: str | None = None
    host: str | None = None
    skill: str | None = None
    skill_path: str | None = None
    mode: str | None = None
    lens: str | None = None
    scope: str | None = None
    evidence: str | None = None
    action: str | None = None
    open_architecture: bool = False
    defaults_applied: list[str] | None = None
    warnings: list[str] | None = None
    rule: str | None = None
    error: str | None = None
    minimal_correction: str | None = None


def fail(original: str, rule: str, error: str, correction: str) -> Result:
    return Result(False, original, rule=rule, error=error, minimal_correction=correction,
                  defaults_applied=[], warnings=[])


def parse(invocation: str) -> Result:
    original = invocation.strip()
    if not original:
        return fail(original, "V1", "empty invocation", "Provide an invocation beginning with AB1. through AB9.")

    flag = False
    body = original
    if body.endswith(" +open-architecture"):
        flag = True
        body = body[:-len(" +open-architecture")].rstrip()
    elif "+open-architecture" in body:
        return fail(original, "V7", "flag must be the exact trailing suffix ' +open-architecture'",
                    "Move +open-architecture to the end of the invocation.")

    m = re.match(r"^(AB\d+)\.(.*)$", body, flags=re.S)
    if not m or not re.fullmatch(r"AB[1-9]", m.group(1)):
        return fail(original, "V1", "bad host (only AB1 through AB9; no leading zero)",
                    "Replace the host with AB1 through AB9.")
    host, remainder = m.group(1), m.group(2).strip()
    if not remainder:
        return fail(original, "V6", "empty scope phrase", "Add a non-empty scope after the host.")

    parts = remainder.split(".")
    defaults: list[str] = []
    warnings: list[str] = []

    # An explicit trailing action creates a strict invocation and therefore requires
    # an immediately preceding evidence token. This prevents silent repair of
    # AB4....augment when the mandatory evidence stage was omitted.
    action = None
    evidence = None
    if parts and parts[-1] in ACTIONS:
        action = parts.pop()
        if not parts or parts[-1] not in EVIDENCE:
            return fail(original, "V4", "explicit action is missing its immediately preceding evidence stage",
                        f"Insert an evidence stage before .{action}, for example .design-time.{action}.")
        evidence = parts.pop()
    else:
        action = "assess-only"
        defaults.append("action=assess-only")
        if parts and parts[-1] in EVIDENCE:
            evidence = parts.pop()
        else:
            evidence = "design-time"
            defaults.append("evidence=design-time")

    mode = "holistic"
    if parts and parts[0] in MODES:
        mode = parts.pop(0)
    else:
        defaults.append("mode=holistic")

    if parts and parts[0] in LENSES:
        lens = parts.pop(0)
    else:
        lens = MODES[mode]
        defaults.append(f"lens={lens}")

    scope = ".".join(parts).strip()
    if not scope:
        return fail(original, "V6", "empty scope phrase",
                    "Add free-text scope between the mode/lens and evidence/action positions.")

    if flag and action not in OPEN_ACTIONS:
        return fail(original, "V7", f"illegal +open-architecture/action pair: {action}",
                    "Use recommend, augment, rewrite, or implement; or remove the flag.")

    if mode == "goal-completeness" and host != "AB4":
        warnings.append("V8: goal-completeness is AB4-primary; this host is acting as a consumer")
    if host == "AB2" and mode == "adversarial" and "action=assess-only" in defaults:
        warnings.append("E001: Core Router defaulted action to assess-only; use an explicit evidence stage and .retest to execute tests")

    skill = HOST_TO_SKILL[host]
    flag_text = " +open-architecture" if flag else ""
    normalized = f"{host}.{mode}.{lens}.{scope}.{evidence}.{action}{flag_text}"
    return Result(
        True, original, normalized=normalized, host=host, skill=skill,
        skill_path=f".agents/skills/{skill}/SKILL.md", mode=mode, lens=lens,
        scope=scope, evidence=evidence, action=action, open_architecture=flag,
        defaults_applied=defaults, warnings=warnings,
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("invocation", help="Exact Prompt Macro invocation")
    ap.add_argument("--json", action="store_true", dest="as_json")
    args = ap.parse_args()
    result = parse(args.invocation)
    if args.as_json:
        print(json.dumps(asdict(result), indent=2, ensure_ascii=False))
    elif result.valid:
        print(result.normalized)
        if result.defaults_applied:
            print("Defaults: " + ", ".join(result.defaults_applied))
        if result.warnings:
            print("Warnings: " + "; ".join(result.warnings))
        print(f"Skill: {result.skill} ({result.skill_path})")
    else:
        print(f"FAIL {result.rule}: {result.error}", file=sys.stderr)
        print(f"Correction: {result.minimal_correction}", file=sys.stderr)
    return 0 if result.valid else 2

if __name__ == "__main__":
    raise SystemExit(main())
