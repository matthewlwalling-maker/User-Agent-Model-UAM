#!/usr/bin/env python3
"""Create or append an immutable evaluation-attempt record."""
from __future__ import annotations
import argparse, json, uuid
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-series-id', required=True)
    ap.add_argument('--case-id', required=True)
    ap.add_argument('--target-revision', required=True)
    ap.add_argument('--evidence-stage', required=True,
                    choices=['design-time','simulated','live-runtime','post-implementation','production-observed'])
    ap.add_argument('--input-file', required=True)
    ap.add_argument('--output-file', required=True)
    ap.add_argument('--command', action='append', default=[])
    ap.add_argument('--manual-intervention', action='append', default=[])
    ap.add_argument('--recovery-of')
    ap.add_argument('-o', '--record', required=True)
    args = ap.parse_args()
    payload = {
        'attempt_id': 'ATT-' + uuid.uuid4().hex[:12],
        'recovery_of': args.recovery_of,
        'run_series_id': args.run_series_id,
        'case_id': args.case_id,
        'target_revision': args.target_revision,
        'evidence_stage': args.evidence_stage,
        'started_or_recorded_at_utc': datetime.now(timezone.utc).isoformat(),
        'input_file': args.input_file,
        'output_file': args.output_file,
        'commands': args.command,
        'manual_interventions': args.manual_intervention,
        'scoring': None,
    }
    path = Path(args.record)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(payload, ensure_ascii=False) + '\n')
    print(payload['attempt_id'])
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
