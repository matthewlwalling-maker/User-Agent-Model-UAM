# Agent Builder Codex Skills v1.0.1

A repo-scoped Codex Skills implementation of the Agent Builder Prompt Macro Framework.

## Operational Skills

- `$architecture-assessment`
- `$artifact-change`
- `$adversarial-evaluation`
- `$version-comparison`
- `$failure-triage`
- `$deployment-readiness`
- `$handoff-package`

`$prompt-macro-router` is an explicit-only compatibility and recovery utility, not an eighth operational Skill.

## Invocation interfaces

1. Natural language: `Assess whether this workflow is complete for safe writeback.`
2. Direct Skill: `$architecture-assessment Assess this workflow...`
3. Prompt Macro: `AB4.goal-completeness.assess this workflow.design-time.recommend`

Bare AB1–AB9 macros are handled by the root `AGENTS.md`, validated deterministically, and dispatched to one operational Skill. Downstream handoffs are never auto-executed.

## Status

Yellow — design-time deployable for repo-scoped evaluation. Live-runtime and production-observed claims require new evidence. See `Deployment_Validation_Record_v1.0.1.md`.

## Governance artifacts

- `Alignment_Decision_Record_v1.0.md`
- `Agent_Operations_Extraction_and_Skill_Tiering_v1.0.md`
- `Implementation_Decisions_and_Source_Errata_v1.0.1.md`
- `Deferred_Capabilities_and_Revisit_Conditions_v1.0.md`
- `Deployment_Validation_Record_v1.0.1.md`
- `AB2_Shorthand_Default_Patch_Closure_Record_v1.0.1.md`
