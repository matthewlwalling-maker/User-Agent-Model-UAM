# Codex Skills Deployment Validation Record

**Version:** 1.0.1  
**Evidence stage:** design-time construction validation  
**Decision:** Yellow — repo-scoped deployable for smoke testing with named limitations

## Included

- Seven operational Skills with distinct triggers and boundaries.
- One explicit-only Prompt Macro recovery utility.
- Bare AB1–AB9 compatibility through `AGENTS.md`.
- Deterministic Prompt Macro parser and route map.
- Canonical 00–08 Prompt Macro Framework reference bundle.
- Deferred-capabilities register.
- Experimental O1–O4 package preserved without deployment authority.
- Source-freeze, evaluation-capture, and handoff-packaging utilities.
- Package and parser tests.

## Construction gates

| Gate | Result |
|---|---|
| Every operational Skill has valid `SKILL.md` name and description | PASS |
| Skill names match committed no-prefix names | PASS |
| Router utility has implicit invocation disabled | PASS |
| Bare Prompt Macros map AB1–AB9 to the committed seven-Skill model | PASS |
| Explicit action without evidence is rejected | PASS |
| Illegal `+open-architecture` action pair is rejected | PASS |
| Canonical authority bundle is complete | PASS |
| AB2 shorthand follows Core Router default action | PASS |
| Explicit AB2 `.simulated.retest` maps to adversarial evaluation | PASS |
| AB2 `.retest` without evidence is rejected | PASS |
| Experimental package cannot override deployed authority | PASS by instruction and location |
| No automatic multi-Skill chaining | PASS by contract |
| Deferred cases are recorded with revisit conditions | PASS |

## Named limitations

- Codex runtime trigger behavior has not yet been observed in the user's active repository.
- No live-runtime Skill invocation evidence has been captured.
- No E1–E12 run has yet been executed against the generated `architecture-assessment` Skill.
- Scripts are construction-tested here but not yet run in the user's Windows repository.
- User-level installation and plugin distribution are outside this release.
- Historical release `v1.0` carried a Quickstart AB2 shorthand discrepancy. It is closed in this patch and preserved only in prior-release records.
- O1–O4 typed orchestration remains experimental.

## Conditions to advance

To advance from Yellow:

1. Install repo-scoped package in the active Agent Builder repository.
2. Run direct-Skill, natural-language, valid-PM, invalid-PM, and overlap trigger tests.
3. Execute E1–E12 against `architecture-assessment` at simulated evidence.
4. Run one authorized change → regression → readiness sequence.
5. Capture failures without editing this release in place; issue v1.1 for material corrections.

Green for live use requires the intended runtime-specific gates to pass at the evidence stage being claimed.
