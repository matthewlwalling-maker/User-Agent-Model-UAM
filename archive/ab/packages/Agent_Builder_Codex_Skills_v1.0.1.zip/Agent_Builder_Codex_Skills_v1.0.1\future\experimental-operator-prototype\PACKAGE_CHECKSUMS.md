# Package File Inventory and Checksums

This packaging companion is not an eighth architectural artifact.

| File | SHA-256 | Bytes |
|---|---|---:|
| `P1_Prototype_Authority_and_Scope_v0.1.md` | `c824cd72c8d9ca819234b1cb06950fcadaa2b1d62b828c9a6638bb6eb1ee8e5d` | 8696 |
| `P2_State_Schemas_v0.1.json` | `b6ba0285bf75fa5e9c61bc3708c1a416f15fbc2e858466efc0065a60295e084d` | 79428 |
| `P3_Operator_Runtime_Contracts_v0.1.md` | `014f2e97db00accf862aa75bda6e93a2d826571f277469540b5d4e81c4f48596` | 17214 |
| `P4_Selector_and_State_Transition_Protocol_v0.1.md` | `2a87cdd11260a3b6209138f00e7f9a60fcb0f0f396540833e3d80c1444d7291d` | 9639 |
| `P5_Comparative_Fixture_Pack_v0.1.yaml` | `d65249c891b88240db1aec9128fd92b14baac7b2d1af224ce895bb4c77376fde` | 17948 |
| `P6_AB_Run_and_Evidence_Capture_Protocol_v0.1.md` | `af1baf27c6389bdd0544a2304dfef5c119a40945ec80e2066bda5a32ae7d4e67` | 11960 |
| `P7_Prototype_Build_Validation_Record_v0.1.md` | `22b13a98a9d4ebf0d599dc3bc06f859551d66cbdc080cea0342a3863d52af18a` | 6293 |
