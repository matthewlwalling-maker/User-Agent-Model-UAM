---
name: prompt-macro-router
description: Explicit recovery and testing utility for Agent Builder AB1-AB9 Prompt Macros. Validate, normalize, and map a macro to the correct operational Skill. Use only when directly invoked or when debugging routing; ordinary bare AB macros are handled by AGENTS.md.
---

# Prompt Macro Router

This is a compatibility and recovery utility, not an eighth operational capability.

## Procedure

1. Preserve the exact invocation.
2. Run `python ../_shared/scripts/validate_pm_invocation.py --json "<invocation>"`.
3. On failure, return the rule, reason, and minimal correction. Do not execute any operation.
4. On success, show the normalized invocation, defaults, warnings, mapped Skill, and Skill path.
5. When explicitly asked to continue, read the mapped Skill and execute it under the normalized fields.
6. Never broaden the action, own substantive state, or automatically chain a downstream Skill.

Read `../_shared/references/pm-routing-map.md`, the canonical Core Router, and Component Registry when diagnosing a routing discrepancy.
