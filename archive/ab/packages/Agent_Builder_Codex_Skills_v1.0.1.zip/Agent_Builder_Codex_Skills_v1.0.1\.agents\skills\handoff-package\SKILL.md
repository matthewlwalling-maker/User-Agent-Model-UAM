---
name: handoff-package
description: Create a state-preserving handoff, migration brief, compact execution packet, or cross-session continuation package. Use when another agent, session, repository, or environment must continue without reconstructing chat history. Do not use to change committed state or promote optional ideas into requirements.
---

# Handoff Package

## Authority and references

Read:

- `../_shared/references/common-governance-contract.md`
- `../_shared/references/canonical/04_Goal-Completeness_and_Open-Architecture_Procedure_v1.0.md` section 16.4
- `../_shared/references/canonical/05_Agent_Builder_AB1-AB9_Registry_v3.0.md` AB8 and AB9

## Inputs

Recover or mark unavailable:

- committed objective and required obligations;
- material constraints and explicit exclusions;
- required capability model;
- exact target asset and revision;
- strengths, coverage, gaps, or sufficiency decision;
- structural reach and authorized next action;
- evidence stage, evidence references, and claim limits;
- unresolved branches, contradictions, risks, and dependencies;
- preservation requirements;
- verification owed;
- next consumer and terminal/revisit condition.

## Procedure

1. Preserve exact identity, version, branch, and evidence references.
2. Separate required state from optional opportunities and speculative possibilities.
3. Include every fact needed for execution without referring to the prior conversation.
4. Omit reasoning history that does not affect execution.
5. Do not infer omitted packet contents or resolve disagreements during compression.
6. Keep action authority and prohibited propagation explicit.
7. Produce a human-readable handoff and, when requested, a compact JSON execution packet.
8. Validate required fields with `../_shared/scripts/package_handoff.py` when packaging JSON.

## Output

Use `../_shared/assets/handoff-packet-template.md`.

For AB8, favor complete state preservation. For AB9, compress wording while retaining the same required state, evidence ceilings, branch identity, and optionality boundaries.

## Boundaries

- Never write `continue from the conversation` as a substitute for state.
- Do not alter state owned by another operation.
- Do not upgrade evidence, merge branches, or make Tier 3–4 opportunities required.
