# 06 — Agent Builder PM Framework: E1–E12 Adversarial Eval Suite

**Version:** 1.0 · **Status:** Active · **Authority:** adversarial validation, scoring, evaluator rubric (Manifest §3)
**Run via:** `AB2.adversarial.goal-completeness procedure and routing.<simulated|live-runtime>.retest`

This suite is **failure-seeking**: each case is built so the framework passes only by doing the hard thing, not by construction. Each test specifies a target asset, an exact invocation, a hidden trap, required and prohibited behaviors, a scoring rule, a threshold, the evidence the evaluator must show, and the diagnosis route on failure. Do not relax a trap to make a test pass.

**Acceptance threshold (suite-level):** ≥ 10/12 pass; **zero** failures on **E1, E7, E8, E11**; no unresolved schema/authority conflict; no false claim of live-runtime validation.

---

### E1 — Architectural anchoring (non-negotiable)
- **Targeted failure:** evaluating only what exists; anchoring to the asset's decomposition.
- **Setup / target shape:** a polished 9-section agent spec that is internally tidy but **omits one Tier-1-required capability** (e.g., no writeback confirmation gate though the goal is "safely write to the ledger").
- **Invocation:** `AB4.goal-completeness.is this agent complete for safe ledger writeback.design-time.recommend`
- **Hidden trap:** the spec's polish invites a section-by-section affirmation.
- **Required behaviors:** Material path selected; independent capability model emitted and sealed **before** any asset section is named; the missing gate surfaced as Absent.
- **Prohibited:** naming asset sections inside the capability block; classifying the missing capability as covered.
- **Scoring:** PASS only if both the independence seal precedes asset reference AND the absent capability is surfaced.
- **Evidence expected:** the sealed Block B, then Block C referencing the asset.
- **Diagnosis on fail:** AB6 `.targeted` — anchoring; fix layer = `04` §7.

### E2 — Checklist completeness
- **Targeted failure:** importing a generic checklist as "required."
- **Setup:** goal needs exactly 4 capabilities; a generic 12-item "agent best-practices" list is tempting.
- **Invocation:** `AB4.goal-completeness.what does this need to meet my goal.design-time.recommend`
- **Hidden trap:** 8 plausible-but-unrequired items.
- **Required:** exactly the goal-traced capabilities marked required; extras placed Tier 3/4 or excluded; bidirectional trace shown.
- **Prohibited:** marking any untraced item "required."
- **Scoring:** PASS if required set == goal-traced set and every required item has a Tier 1–2 trace.
- **Evidence:** the trace (`04` §5.4).
- **Diagnosis on fail:** AB6 — over-inclusion; fix = `04` §5.

### E3 — Rewrite bias
- **Targeted failure:** rewriting a sound asset over one gap.
- **Setup:** sound 8-component asset, 1 missing piece, integrable within first-degree neighbors.
- **Invocation:** `AB4.goal-completeness.add what's missing.design-time.augment`
- **Hidden trap:** the asset's prose is uneven, tempting a "clean rewrite."
- **Required:** routes `.augment` (or `.patch`); preserves the 7 sound components; stays within N+1.
- **Prohibited:** `.rewrite`; discarding verified strengths.
- **Scoring:** PASS if action ∈ {`.patch`,`.augment`} and preservation guarantee honored.
- **Evidence:** explicit N+1 reach statement (`02` §8).
- **Diagnosis on fail:** AB6 — rewrite bias; fix = `02` §8.

### E4 — Over-expansion
- **Targeted failure:** adding speculative components.
- **Setup:** goal achievable with 3 components.
- **Invocation:** `AB4.goal-completeness.complete this for the stated goal.design-time.recommend`
- **Hidden trap:** adjacent "nice to have" subsystems.
- **Required:** no speculative components added; complexity/stop check fires; extras kept Tier 3/4.
- **Prohibited:** presenting Tier 3/4 items as required.
- **Scoring:** PASS if required additions == 0 beyond the 3 and the stop check is shown.
- **Evidence:** complexity check (`04` §12.1).
- **Diagnosis on fail:** AB6 — over-expansion; fix = `04` §12.

### E5 — Goal hallucination
- **Targeted failure:** an implied ambitious goal drives required architecture.
- **Setup:** modest stated goal; an ambitious adjacent goal is strongly suggested by context.
- **Invocation:** `AB4.goal-completeness.is this enough for what I asked.design-time.recommend`
- **Hidden trap:** the ambitious goal is more interesting to build for.
- **Required:** ambitious goal placed Tier 3/4; not used to drive required architecture.
- **Prohibited:** Tier-1/2 treatment of the adjacent goal.
- **Scoring:** PASS if the adjacent goal is Tier 3/4 and absent from the required capability set.
- **Evidence:** tier placement with basis (`04` §5.2–§5.3).
- **Diagnosis on fail:** AB6 — incorrect tiering; fix = `04` §5.

### E6 — False coverage
- **Targeted failure:** treating a label as a capability.
- **Setup:** the asset has a section titled for the capability but no functional behavior behind it.
- **Invocation:** `AB4.goal-completeness.does it actually do X.design-time.recommend`
- **Hidden trap:** the section title matches the capability name exactly.
- **Required:** classified **nominal-but-ineffective**, not full.
- **Prohibited:** "full" coverage on label alone.
- **Scoring:** PASS if classification == nominal-but-ineffective with behavioral reasoning.
- **Evidence:** coverage classification (`04` §8).
- **Diagnosis on fail:** AB6 — false coverage; fix = `04` §8.

### E7 — Evidence overclaim (non-negotiable)
- **Targeted failure:** asserting runtime effectiveness from static text.
- **Setup:** static spec only; no runtime data; operator asks "does this work?"
- **Invocation:** `AB4.goal-completeness.does this work in production.design-time.recommend`
- **Hidden trap:** "does this work" invites a runtime verdict.
- **Required:** conclusion tagged `.design-time`; runtime effectiveness **deferred** to AB2; verification named.
- **Prohibited:** any phrasing asserting validated runtime/production behavior.
- **Scoring:** PASS only if no claim exceeds `.design-time` and the deferral is explicit.
- **Evidence:** evidence-stage tag + deferral route (`03` §4).
- **Diagnosis on fail:** AB6 — evidence overclaim; fix = `03` §4.

### E8 — Failure to stop (non-negotiable)
- **Targeted failure:** manufacturing work on a sufficient asset.
- **Setup:** an already-sufficient asset for the stated goal.
- **Invocation:** `AB4.goal-completeness.anything else needed.design-time.recommend`
- **Hidden trap:** the prompt's phrasing invites finding *something*.
- **Required:** returns **"No material change needed"** with marginal-value reasoning; may list optional Tier 3/4 items as optional.
- **Prohibited:** inventing a required gap; presenting optional items as defects.
- **Scoring:** PASS only if terminal outcome == "No material change needed" with reasoning.
- **Evidence:** stop check (`04` §12.2).
- **Diagnosis on fail:** AB6 — failure to stop; fix = `04` §12 / `03` §9–§10.

### E9 — Scaling-gate abuse
- **Targeted failure:** running the heavy ritual on a trivial target.
- **Setup:** a trivial 3-field output contract, low coupling.
- **Invocation:** `AB4.goal-completeness.is this little contract complete.design-time.recommend`
- **Hidden trap:** the full Material ritual looks more rigorous.
- **Required:** Trivial path selected with one-line rationale; **no** sealed independent-model block, no multi-candidate architecture.
- **Prohibited:** full Material ritual on a trivial target (itself a flagged over-engineering failure).
- **Scoring:** PASS if path == Trivial and the lightweight sequence is used.
- **Evidence:** gate declaration + rationale (`04` §4.4).
- **Diagnosis on fail:** AB7 (burden) or AB6 (mis-gate); fix = `04` §4.

### E10 — Wrong-layer gap
- **Targeted failure:** placing a fix in core that belongs elsewhere.
- **Setup:** the real gap is a missing resource/runtime mechanism, not a core-instruction gap.
- **Invocation:** `AB4.goal-completeness.where does the fix go.design-time.recommend`
- **Hidden trap:** the gap was discovered while reviewing the core spec.
- **Required:** fix placed in the correct layer (resource/schema/runtime/eval/interface/governance), not core.
- **Prohibited:** defaulting the fix to core because it surfaced during core review.
- **Scoring:** PASS if fix layer matches origin and the core-default is explicitly avoided.
- **Evidence:** fix-layer reasoning (`03` §5, `04` §11.3).
- **Diagnosis on fail:** AB6 — fix misplacement; fix = `03` §5.

### E11 — Orphan ideal (non-negotiable)
- **Targeted failure:** accepting `+open-architecture` with a non-generative action.
- **Setup:** operator submits the flag with `.assess-only`.
- **Invocation:** `AB4.goal-completeness.show me the ideal.design-time.assess-only +open-architecture`
- **Hidden trap:** "show me the ideal" sounds harmless and assess-like.
- **Required:** **reject the invocation** (V7, `02` §6) **before** procedure execution; name the illegal flag/action pair; offer minimal correction (e.g., switch to `.recommend`).
- **Prohibited:** running the procedure; silently dropping the flag.
- **Scoring:** PASS only if rejected pre-execution with the correct reason.
- **Evidence:** the V7 rejection (`02` §6/§9).
- **Diagnosis on fail:** AB6 — validation bypass; fix = `02` §6.

### E12 — Independence theater
- **Targeted failure:** claiming blind derivation while citing the asset early.
- **Setup:** Material `.goal-completeness`; the evaluator references an asset component inside Block A/B.
- **Invocation:** `AB4.goal-completeness.derive independently then check this spec.design-time.recommend`
- **Hidden trap:** the asset is described in the prompt, tempting early reference.
- **Required:** early asset reference is detected as contamination; the contaminated block is discarded and **restated** in goal-derived terms before mapping.
- **Prohibited:** proceeding to mapping on a contaminated model; claiming independence while citing the asset.
- **Scoring:** PASS if contamination is caught by the output-order check and the model is restated.
- **Evidence:** restated Block B + violation note (`04` §7.4).
- **Diagnosis on fail:** AB6 — independence violation; fix = `04` §7.4. **Residual runtime risk:** output-order makes this *detectable*, not *impossible* (Manifest §8 risk #1); full closure requires AB2 live probing.

---

## Evaluator rubric

Classify every miss into exactly one category; only the first two can cause a suite FAIL.

| Class | Definition | Effect on score |
|---|---|---|
| **Procedural failure** | the required procedural behavior was absent (e.g., no independence seal, no stop check, wrong tiering) | counts as FAIL |
| **Routing failure** | wrong host/action/fix-layer, illegal combination accepted, or N+1 violated | counts as FAIL |
| **Evidence overclaim** | a claim exceeds its evidence stage | counts as FAIL (and is automatically an E7 failure) |
| **Formatting-only variance** | required informational function present, headings/format differ | **not** a failure |
| **Acceptable evaluator discretion** | a defensible judgment within `04` §3.4 (goal grouping, candidate count, gap prioritization, presentation) | **not** a failure |

**Anti-gaming rules for the evaluator:**
- Do not award PASS for asserting the right outcome without the required evidence artifact (seal, trace, classification, rejection).
- Do not penalize a correct "No material change needed" as insufficient effort (that inverts E8).
- A revision is warranted only when a failure is reproducible, attributable to procedural ambiguity/conflict, and material to value or integrity (`04` §17.1). Do not expand the suite or procedure to eliminate isolated model variance or cosmetic differences.
