# Agent Operations Extraction and Skill Tiering

**Version:** 1.0  
**Source:** Agent Builder Prompt Macro Framework 00–08, with O1–O4 retained as experimental reference only

## Tier 1 — Operational Skills deployed in v1

| Skill | Valuable operations owned |
|---|---|
| `architecture-assessment` | intent reconstruction; Trivial/Material scaling; requirement tiering; independent capability derivation; behavioral coverage; gap discovery; correct fix layer; target recommendation; complexity/stop decision |
| `artifact-change` | authorized patch; N+1 augmentation; explicit rewrite; implementation; dependency-aware preservation; change record; regression list |
| `adversarial-evaluation` | failure-seeking eval design; regression/verification/blind profiles; source freeze; raw evidence capture; immutable retries; evidence-stage scoring |
| `version-comparison` | frozen-basis comparison; delta analysis; ranking; donor components; synthesis; tradeoff preservation |
| `failure-triage` | observed-failure diagnosis; failure classification; severity/confidence; fix-layer placement; smallest remedy; AB7 burden/interface calibration profile |
| `deployment-readiness` | implementation/test/resource/integration gate; Green/Yellow/Red/Blocked decision; named limitations; advancement conditions |
| `handoff-package` | state-preserving handoff; branch/evidence preservation; context compression; portable execution packet; terminal/next-consumer contract |

## Tier 2 — Shared control-plane operations

These govern every Skill and are not standalone capabilities:

- Prompt Macro recognition and anchored parsing;
- default resolution and legality checks;
- authority lookup;
- evidence-stage claim ceilings;
- action authorization;
- smallest-sufficient-change routing;
- severity/confidence separation;
- correct-fix-layer selection;
- bounded assumptions and material ambiguity handling;
- branch/provenance preservation;
- no-material-change and stopping logic.

## Tier 3 — Parameters, not Skills

- Modes: holistic, component, subcomponent, delta, targeted, blind, independent, adversarial, regression, verification, goal-completeness.
- Lenses: intent, architecture, boundary, source, resource, runtime, safety, behavior, output, efficiency, maintainability, deployment, verification, generalization.
- Actions: assess-only, recommend, patch, augment, rewrite, implement, retest, package, gate.
- Evidence stages: design-time, simulated, live-runtime, post-implementation, production-observed.

## Tier 4 — Deferred or experimental

- general research procedure;
- generic document/write-up procedure;
- standalone runtime calibration;
- production-observed readiness;
- mandatory O1–O4 typed orchestration;
- cross-repository evidence automation;
- autonomous deployment;
- plugin distribution;
- automatic multi-Skill chaining;
- production telemetry.

See `Deferred_Capabilities_and_Revisit_Conditions_v1.0.md` for triggers and evidence requirements.
