# Alignment Decision Record

**Version:** 1.0  
**Status:** Committed for v1 construction

## Committed decisions

1. Deploy seven operational Skills with no `agent-` prefix:
   - `architecture-assessment`
   - `artifact-change`
   - `adversarial-evaluation`
   - `version-comparison`
   - `failure-triage`
   - `deployment-readiness`
   - `handoff-package`
2. Retain `prompt-macro-router` only as an explicit, non-implicit recovery and routing-test utility.
3. Support natural language, direct `$skill-name`, and bare AB1–AB9 Prompt Macro interfaces.
4. Handle bare Prompt Macros through a thin `AGENTS.md` compatibility rule and deterministic validator.
5. Hard-reject illegal explicit macros; do not silently repair missing mandatory evidence before an explicit action.
6. Preserve recoverable shorthand defaults from the authoritative Core Router.
7. Map AB7 runtime calibration to a profile within `failure-triage` until standalone runtime evidence justifies a separate Skill.
8. Combine AB8 handoff and AB9 compression under `handoff-package`.
9. Do not automatically chain Skills. Each downstream action requires separate authorization.
10. Keep O1–O4 typed orchestration experimental and non-governing.
11. Record all held capabilities in a deferred-capabilities artifact with explicit revisit conditions.
12. Deploy repo-scoped first; user-level and plugin distribution remain deferred.

## Reopen conditions

Reopen this contract only when trigger collisions, material runtime failures, new Codex platform behavior, comparative O1–O4 evidence, or a user goal change materially affects the architecture.
