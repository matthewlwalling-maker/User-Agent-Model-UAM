# Execution-Ready Handoff

## Committed objective and required obligations

## Material constraints and exclusions

## Required capability model

## Target asset and exact revision

## Coverage, strengths, gaps, and decision

## Evidence stage, evidence references, and claim limits

## Authorized next action and prohibited action reach

## Dependencies, branches, unresolved risks, and preservation requirements

## Verification owed

## Next consumer and terminal/revisit condition
