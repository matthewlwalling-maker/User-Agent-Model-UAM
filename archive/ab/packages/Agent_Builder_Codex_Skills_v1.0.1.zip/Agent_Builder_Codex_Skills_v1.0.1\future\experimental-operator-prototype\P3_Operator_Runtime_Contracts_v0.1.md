# P3 — Operator Runtime Contracts

**Version:** 0.1  
**Schema dependency:** P2  
**Transition dependency:** P4  
**Fixture dependency:** P5

## 1. Universal execution packet

An `ExecutionPacket` is a transport record, not a sixth state object. Every operator invocation must receive this complete packet and may not rely on conversation memory.

```json
{
  "run_id": "RUN-...",
  "operator_id": "O1|O2|O3|O4",
  "requested_output_kind": "GoalContract|CapabilityModel|CoverageMap|ChangeDecision",
  "profile": "material|compact",
  "independence_condition": "not-applicable|packet-boundary|separate-context",
  "input_objects": [{"object_id":"...","revision":1,"branch_id":"...","content_hash":"...","snapshot":{}}],
  "evidence_ledger_projection": {
    "ledger_id":"EL-...",
    "revision":1,
    "ledger_digest":"sha256",
    "projection":"full|referenced-subset",
    "included_entries":[],
    "omitted_entry_count":0,
    "append_delta_allowed":true
  },
  "external_inputs": [],
  "permitted_reads": [],
  "forbidden_inputs": [],
  "selector_decision": {"selected_operator":"O...","basis":[],"rejected_operators":[]},
  "expected_output": {"object_kind":"...","schema_id":"P2#/$defs/..."}
}
```

Packet validity rules:

1. Every object snapshot must match its exact ID, revision, branch, and hash.
2. Every cited evidence entry must be included in the ledger projection.
3. `referenced-subset` retains one logical ledger through stable `ledger_id`, exact revision/digest, included entry IDs, omitted count, and append delta. It is not a new ledger.
4. A consumer may not infer omitted ledger contents.
5. Any forbidden input present in the packet is a hard failure, even if the operator claims not to have used it.
6. Output must validate against P2 and name any semantic validation failure by P2 error code.

## 2. O1 — Normalize Goal and Obligations

### Selection

**Select when:** no current GoalContract exists; goal/constraint evidence changed; the current contract is stale/invalid/open; requiredness basis is missing; or a material interpretation must be branched.

**Do not select when:** a committed current GoalContract already exists and the requested work is capability derivation, coverage, or intervention choice.

### Exact inputs

- user objective and target reference;
- material constraints and requested claim stage;
- existing GoalContract only when revising;
- ledger entries supporting the request and constraints;
- no need for the asset decomposition, coverage judgments, or proposed edits.

### Preconditions

- a target outcome is recoverable, or bounded interpretations can be represented;
- source provenance is available or explicitly marked unavailable;
- the operator has write authority for GoalContract and append authority for goal/constraint ledger entries.

### Permitted reads and writes

- **Read:** intake, governing goals/constraints, prior GoalContract branches, supporting ledger entries.
- **Write:** GoalContract; append-only evidence entries for goals/constraints.
- **Prohibited:** CapabilityModel, CoverageMap, ChangeDecision; asset coverage or intervention claims.

### Required output

One P2-valid GoalContract revision, plus an EvidenceLedger append delta if new source/inference records are needed. It must separate `explicit-required`, `entailed-required`, `optional`, and `speculative` obligations and state compact/material profile basis.

### Evidence ceiling

O1 may classify obligation basis at the available source stage. It may not claim capability sufficiency, asset coverage, implementation quality, or runtime behavior.

### Failure exits

- `blocked-material-ambiguity`
- `no-recoverable-outcome`
- `provenance-missing`
- `branch-conflict`
- P2 errors `MCP-E100`, `MCP-E110`, `MCP-E120`

### Stop behavior

Local stop after a committed GoalContract or an explicit blocking exit. O1 never issues the global architecture/change decision.

### Adversarial checks

- optional or attractive future goals remain optional/speculative;
- methods are not silently converted into outcomes;
- entailed requiredness contains a necessity argument;
- a trivial target does not receive material serialization;
- conflicting interpretations branch rather than silently merge.

### Executable instruction contract

```text
You are O1 Normalize Goal and Obligations. Use only the supplied ExecutionPacket.
Create or revise exactly one GoalContract under P2. Separate explicit-required,
entailed-required, optional, and speculative obligations; every class needs a
source-backed basis, and every entailed obligation needs a necessity argument.
Choose compact or material from coupling and omission risk. Preserve material
ambiguity as a branch or blocking state. Do not derive capabilities, assess the
asset, select an intervention, or rely on conversation memory. Append evidence
only; never rewrite ledger history. Return: validation result, GoalContract,
ledger append delta, and one local stop/failure code.
```

## 3. O2 — Derive Required Capabilities

### Selection

**Select when:** a committed current GoalContract exists and no current CapabilityModel matches it; a model is stale; or model branches require owner-led re-derivation/adjudication.

**Do not select when:** GoalContract is materially unresolved; the task is asset mapping or intervention; or the only prompt to run is an asset section name.

### Exact inputs

- exact committed GoalContract revision;
- only goal/constraint evidence required by that contract;
- independence condition and packet hash;
- prior CapabilityModel branches only for explicit owner-led adjudication.

Normal material-path packets prohibit asset text, component names, section labels, coverage judgments, and proposed edits.

### Preconditions

- GoalContract is committed/current;
- required/optional basis is complete;
- packet contents pass the independence filter;
- ledger projection includes every source used for necessity inferences.

### Permitted reads and writes

- **Read:** GoalContract, goal/constraint evidence, prior model branches only when adjudicating.
- **Write:** CapabilityModel; append-only design-time inference entries.
- **Prohibited:** asset coverage, implementation assessment, change reach, fix layer, intervention, or target architecture.

### Required output

One P2-valid CapabilityModel revision with behavioral capabilities, bidirectional obligation trace, derivation boundary, completeness state, and preserved disagreement branches.

### Independence handling

- `packet-boundary`: record that the broader context may have seen the asset; never label it full cognitive independence.
- `separate-context`: record that this execution context has never received the asset.
- Any forbidden packet content or asset-derived category triggers `MCP-E220`; discard the model and rerun from a clean packet/context.

### Evidence ceiling

Design-time necessity and candidate sufficiency relative to the GoalContract only. No asset or runtime claims.

### Failure exits

- `goal-contract-invalid`
- `independence-contamination`
- `model-incomplete`
- `material-model-conflict`
- `unsupported-necessity-inference`
- P2 errors `MCP-E200`, `MCP-E210`, `MCP-E220`, `MCP-E230`

### Stop behavior

Local stop after a candidate-complete, explicitly incomplete, or contested CapabilityModel. Material disagreement remains branched; no silent union.

### Adversarial checks

- discover required behavior omitted from a polished asset;
- reject generic checklist items without obligation trace;
- use behavioral statements, not section titles;
- preserve materially different branches;
- keep design-time necessity distinct from observed performance.

### Executable instruction contract

```text
You are O2 Derive Required Capabilities. Use only the supplied ExecutionPacket.
First validate that the GoalContract is committed/current and the packet contains
no forbidden asset decomposition, section labels, coverage judgments, or edits.
Derive the smallest candidate-complete set of implementation-neutral behavioral
capabilities needed for required obligations and constraints. Every capability
must trace to a required obligation, and every required obligation must be
covered. Record the exact independence condition and packet hash. Preserve
materially disagreeing models as branches; do not union them silently. Do not
assess the asset or choose a change. Return validation, CapabilityModel, optional
ledger append delta, and one local stop/failure code.
```

## 4. O3 — Assess Capability Coverage

### Selection

**Select when:** exact committed/current GoalContract and CapabilityModel revisions exist; the asset version/hash is identified; and evidence permits at least bounded coverage findings.

**Do not select when:** CapabilityModel is absent, stale, contaminated, or materially unresolved without branch selection; the task is goal normalization, capability derivation, or action selection.

### Exact inputs

- current GoalContract and CapabilityModel branch;
- exact asset version and text/behavior packet;
- scoped EvidenceLedger projection;
- supplied dependency/interface facts, if any;
- no intervention proposal from O4.

### Preconditions

- upstream refs/hashes match;
- every required capability is resolvable;
- asset version is fixed;
- evidence stage is explicit;
- material model branches are assessed separately.

### Permitted reads and writes

- **Read:** GoalContract, CapabilityModel, asset, dependency/interface facts, EvidenceLedger.
- **Write:** CoverageMap; append-only asset/test evidence entries.
- **Prohibited:** modifying requiredness/capabilities, selecting local correction/addition/restructure, generating target architecture, or implementing changes.

### Exact impact facts O3 must produce

For every material gap:

1. `gap_type` and required-obligation consequence;
2. originating layer candidates;
3. touched elements;
4. directly connected first-degree dependencies;
5. known second-degree-or-broader dependencies;
6. semantic centrality;
7. explicit propagation facts with evidence;
8. `change_reach` (`named-elements-only`, `n-plus-1`, `broader-than-n-plus-1`, `unknown`);
9. whether dependency facts are complete for the decision;
10. preservation feasibility;
11. material unknowns;
12. whether a separate impact job is required; and
13. O4 readiness (`intervention-ready`, `block-only`, `not-ready`) with basis.

These facts are **decision-ready** when they let O4 apply its mapping without discovering, revising, or extending coverage/dependency facts. `block-only` is decision-ready for a block, not for an intervention.

### Enforceable impact boundary

O3 may perform only coverage-linked impact observation from the supplied asset, supplied dependency map, or bounded first-degree interface trace. It crosses into a materially separate operator job when it must gather new sources, traverse undocumented system graphs, inspect a runtime/platform not in evidence, simulate propagation, or design the future system. O3 then sets `impact_job_required=true`, `o4_readiness=block-only`, and stops. It must not hide that work in prose.

### Evidence ceiling

Coverage and impact claims are limited to the ledger stage and scope. Label matches alone cannot produce `full-at-stage`; static text cannot support runtime effectiveness.

### Failure exits

- `missing-capability-model`
- `stale-upstream`
- `asset-version-unknown`
- `insufficient-evidence`
- `material-branch-conflict`
- `impact-not-decision-ready`
- P2 errors `MCP-E400`, `MCP-E410`, `MCP-E420`, `MCP-E421`, `MCP-E430`

### Stop behavior

Local stop after every capability is classified or explicitly unknown and every material gap has O4 readiness. If internal work is incomplete, use `not-ready`; if the missing work is a distinct impact job, use `block-only`.

### Adversarial checks

- reject O3-before-O2;
- classify labels without behavior as nominal-but-ineffective;
- preserve evidence ceiling;
- distinguish graphical proximity from semantic reach;
- never encode an intervention choice in CoverageMap.

### Executable instruction contract

```text
You are O3 Assess Capability Coverage. Use only the supplied ExecutionPacket.
Reject execution unless GoalContract, CapabilityModel, asset version, and ledger
refs are exact/current. Assess actual behavior against every required capability;
a label is not behavior. For each material gap, emit the exact impact facts in P3
and P2, using only supplied/observable dependency evidence. Do not select a fix.
If decision-ready reach requires new source collection, undocumented graph
traversal, runtime inspection, causal simulation, or design work, set
impact_job_required=true and o4_readiness=block-only. Preserve model branches and
evidence ceilings. Return validation, CoverageMap, ledger append delta, and one
local stop/failure code.
```

## 5. O4 — Choose Intervention or Stop

### Selection

**Select when:** a current committed CoverageMap has `overall_o4_readiness` of `intervention-ready` or `block-only`; or branch-specific maps prove a decision is invariant.

**Do not select when:** CoverageMap is absent/stale/not-ready; coverage/impact facts still need analysis; the user asks for implementation, platform packaging, testing, or deployment.

### Exact inputs

- exact current CoverageMap;
- referenced GoalContract and CapabilityModel for required/optional and relation context;
- read-only EvidenceLedger projection;
- no new asset or dependency evidence that has not been processed by O3.

### Preconditions

- exact refs/hashes match;
- no hidden decision-material conflict;
- every target gap has O4 readiness;
- evidence ceiling is explicit.

### Permitted reads and writes

- **Read:** all five object types, but only existing fields and evidence.
- **Write:** ChangeDecision only.
- **Prohibited:** rewriting coverage, adding dependency facts, implementing, testing, or generating target architecture.

### Deterministic decision mapping

O4 applies, but does not re-derive, these mappings:

| O3 facts | Eligible O4 decision |
|---|---|
| no material gaps; required capabilities adequate at stage | `no-material-change` |
| `gap_type=local-defect`, reach `named-elements-only`, preservation established/plausible | `local-correction` |
| `gap_type=missing-capability`, reach `n-plus-1`, no broader propagation, preservation established/plausible | `bounded-capability-addition` |
| reach `broader-than-n-plus-1` or preservation ruled out by systemic facts | `system-restructure` |
| architecture appears sufficient but requested claim exceeds evidence | `verification-required` |
| O3 `block-only` because separate impact job is required | `blocked-by-insufficient-impact-knowledge` |
| valid branches imply different decisions | `blocked-by-material-disagreement` |
| requested next operation is implementation/test/deployment/other unowned work | `stop-unowned-operation` |

If multiple eligible decisions remain, choose the least reach that satisfies all material gaps and evidence constraints. O4 may not "fill in" missing impact facts to make one eligible.

### Evidence ceiling

Decision claims may not exceed the highest scoped ledger support. Change success and runtime effectiveness are never claimed before corresponding evidence exists.

### Failure exits

- `insufficient-impact-knowledge`
- `material-branch-conflict`
- `evidence-below-request`
- `unowned-next-operation`
- `no-legitimate-decision`
- P2 errors `MCP-E500`, `MCP-E510`, `MCP-E520`, `MCP-E530`, `MCP-E610`

### Stop behavior

O4 owns the global terminal decision. One committed ChangeDecision ends the four-operator run. Re-entry requires a named revisit trigger, a changed upstream revision, or new evidence.

### Adversarial checks

- no manufactured work on a sufficient asset;
- no rewrite for polish;
- no bounded addition with unresolved systemic reach;
- no required work from optional goals;
- no evidence promotion;
- no invented ownership of implementation/testing/deployment.

### Executable instruction contract

```text
You are O4 Choose Intervention or Stop. Use only the supplied ExecutionPacket.
Reject if CoverageMap is stale or not-ready. Treat its coverage and impact facts as
immutable; do not redo O3 analysis. Apply the P3 decision mapping and choose the
smallest eligible reach, or return verification/block/disagreement/unowned stop.
Optional goals cannot create target gaps. Match the decision claim to the ledger
evidence ceiling. Write exactly one ChangeDecision and no upstream state. Do not
implement, test, package, deploy, or design a target architecture. Return
validation, ChangeDecision, and the global terminal stop code.
```

## 6. Compact packet requirements

A compact run may place the five state projections and selector result in one serialized response. It still must expose:

- obligation class and basis;
- capability-to-obligation trace;
- exact object revisions, branches, hashes, and ledger identity;
- evidence references and ceiling;
- coverage classification and impact readiness;
- decision and stop basis;
- unresolved branches/conflicts.

A compact packet failing any item is invalid (`MCP-E120` or `MCP-E620`), even if its prose reaches the right conclusion.
