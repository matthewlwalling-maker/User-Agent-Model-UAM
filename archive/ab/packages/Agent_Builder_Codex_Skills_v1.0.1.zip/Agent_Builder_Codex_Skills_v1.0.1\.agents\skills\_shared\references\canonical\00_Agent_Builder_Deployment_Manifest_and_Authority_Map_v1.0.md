# 00 — Agent Builder PM Framework: Deployment Manifest & Authority Map

**Version:** 1.0.1
**Status:** Yellow — Deployable with named limitations (see `08`)
**Date:** 2026-06-18
**Change class:** Patch revision. Quickstart AB2 shorthand example corrected to follow Core Router default resolution. No locked architectural decision, PM schema, Skill boundary, E1-E12 scoring rule, automatic chaining policy, or experimental O1-O4 status revised.

---

## 1. Package purpose

Convert the canonical Agent Builder PM Framework working architecture (v2.0 + Goal-Completeness Procedure v1.0) into the smallest complete, internally consistent, testable artifact package required for **initial deployment** of the framework as an attachable resource bundle for an agent host.

This package gives an agent enough instruction to parse and route Prompt Macro (PM) invocations, preserves the shared assessment contract and component legality, operationalizes AB1–AB9, makes the Goal-Completeness & Open-Architecture Procedure executable, provides adversarial validation against E1–E12, preserves state across files, and separates design-time readiness from live-runtime validation.

It is **minimum-complete, not theoretically exhaustive.**

---

## 2. Artifact inventory

| # | Artifact | Version | Status | Disposition |
|---|---|---|---|---|
| 00 | Deployment Manifest & Authority Map | 1.0 | Active | Created |
| 01 | Core Router | 1.0 | Active | Created |
| 02 | Component Registry | 1.0 | Active | Created (materializes v2.0 §2/§3/§5 + Procedure §10–§11) |
| 03 | Assessment Contract | 1.0 | Active | Created (materializes v2.0 §5 + Procedure §3) |
| 04 | Goal-Completeness & Open-Architecture Procedure | 1.0 | Active | **Retained unchanged** (canonical) |
| 05 | AB1–AB9 Registry | 3.0 | Active | Created (consolidates v1.0 §3 + v2.0 §6 + Procedure §16) |
| 06 | E1–E12 Adversarial Eval Suite | 1.0 | Active | Created (operationalizes v2.0 §7 + Procedure §17) |
| 07 | Deployment Quickstart | 1.0.1 | Active | Patch-corrected AB2 shorthand default example |
| 08 | Deployment Validation Record | 1.0.1 | Active | Patch validation recorded |

---

## 3. Authority order (resolution of conflict)

When two artifacts disagree, the **lower-numbered authority wins for its own domain**, and later canonical decisions supersede earlier drafts. Each artifact owns one domain; cross-domain claims defer to the owner.

| Domain | Authoritative artifact |
|---|---|
| Package scope, authority, supersession, release status | 00 |
| Invocation recognition, schema parsing, default resolution, routing dispatch | 01 |
| Legal tokens, compatibility, schema validation, action boundaries, N+1 | 02 |
| Cross-AB assessment behavior, required I/O, evidence/fix-layer/stop rules | 03 |
| Goal-completeness execution (gate, ladder, capability model, gaps, open-architecture) | 04 |
| Per-AB roles, modes, lenses, handoffs, default routes, examples | 05 |
| Adversarial validation, scoring, evaluator rubric | 06 |
| Operator usage | 07 |
| Release state and gate conditions | 08 |

**Supersession of source drafts:** v2.0 Framework supersedes Architectural Development Handoff v1.0. Goal-Completeness Procedure v1.0 supersedes v2.0 §4 (inline). This package supersedes all source drafts as the deployment surface; source drafts remain valid only for intent and traceability and may not override locked architecture.

---

## 4. Dependencies

```
00 (manifest)  ── governs ──> all
01 (router)    ── routes to ─> 02, 03, 04, 05
02 (registry)  ── consumed by ─> 01, 03, 04, 05, 06
03 (contract)  ── consumed by ─> 04, 05, 06
04 (procedure) ── consumed by ─> 05 (AB4 host), 06 (E1–E12 target)
05 (AB registry) ── consumed by ─> 01 (dispatch), 06 (diagnosis routes), 07
06 (eval)      ── consumed by ─> 08 (results)
07 (quickstart) ── reads ─> 01, 02, 04, 05, 06
08 (validation) ── records ─> all
```

No artifact depends on a source draft at runtime. The package is self-contained.

---

## 5. Layer placement rule (what belongs where)

| Content | Belongs in |
|---|---|
| "How do I recognize and parse an invocation?" | 01 Core Router (thin) |
| "Is this token/combination legal? Which action boundary applies?" | 02 Component Registry |
| "What must every AB assessment produce and obey?" | 03 Assessment Contract |
| "How do I execute a goal-completeness pass?" | 04 Procedure |
| "Which AB hosts this, with what defaults and handoffs?" | 05 AB1–AB9 Registry |
| "How do I prove the framework behaves correctly?" | 06 Eval Suite |

**Core (01) must not duplicate registry, contract, procedure, or eval logic.** A gap discovered during core review does not automatically belong in core (Procedure §11.3).

---

## 6. Change-control rule

1. Fix a conflict at the **narrowest owning source** (the artifact that owns the domain in §3). Never patch the same rule independently in two files.
2. A token, action boundary, N+1 definition, or evidence-stage name appears **once** as authoritative (02) and is **referenced** elsewhere, never re-defined.
3. Revising a locked decision (see §7) requires a demonstrable contradiction or deployment-blocking defect, recorded in `08`, before any artifact edit.
4. "No material change needed" is a valid disposition for any artifact at any review.
5. Version bump only on material change; do not regenerate to mint a version number.

---

## 7. Locked decisions (carried, not reopened)

- Canonical schema: `AB{n}.{mode}[.{lens}].{scope phrase}.{evidence}.{action}[ +open-architecture]`; required positions AB/mode/scope/evidence/action; lens optional via registry default.
- AB1–AB9 is the lifecycle router. **No AB10.**
- `.goal-completeness` is a mode, primarily hosted by AB4.
- `+open-architecture` is a flag, legal only with generative actions (`.recommend`, `.augment`, `.rewrite`, `.implement`); invalid with `.assess-only`.
- `.augment` ≠ `.patch` ≠ `.rewrite`; `.augment` bounded by the N+1 Dependency Radius; required N+2 propagation routes to `.rewrite`.
- Only Tier 1–2 goals drive required architecture by default.
- Material-path goal-completeness emits the independent capability model before any asset reference (output-order independence).
- "No material change needed" is a valid terminal outcome.
- Evidence stages are never conflated; a design-time conclusion is never phrased as validated runtime behavior.
- Natural-language scope phrases and period delimiters remain usable.
- Routing detail lives in registries/procedure, not core.

**No locked decision required revision during packaging or patch `v1.0.1`.** See `08` §"Locked-decision review."

---

## 8. Deployment assumptions & known unvalidated areas

**Assumptions:** the host can attach ordered markdown resources; the host follows attached instruction precedence over its own defaults where they conflict on PM behavior; the operator invokes via full strings or shorthand+defaults.

**Known unvalidated (require live-runtime evidence, not more design-time architecture):**
1. **Independence-by-output-order is necessary but not sufficient** (Procedure §7.1, v2.0 §8 risk #1). Output order makes anchoring *detectable*, not *impossible*; residual closure depends on AB2 live probing of E1/E12.
2. **Scaling-gate boundary is heuristic** (Procedure §4.2, risk #2). Coupling/omission-risk classification and the ~40% rewrite indicator are uncalibrated against a real asset corpus.
3. **Lens-optionality determinism** (risk #4). Omitted lens → registry default; two operators typing the same shorthand can diverge if a default changes.

These are the basis for the **Yellow** release status. They are closed by initial deployment + Phase 6 calibration (see `08` and `07`), not by additional design-time work.
