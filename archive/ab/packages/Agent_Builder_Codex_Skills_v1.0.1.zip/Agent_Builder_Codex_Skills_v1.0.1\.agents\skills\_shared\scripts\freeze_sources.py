#!/usr/bin/env python3
"""Create a deterministic SHA-256 source-freeze manifest."""
from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('paths', nargs='+')
    ap.add_argument('-o', '--output', default='source-freeze.json')
    ap.add_argument('--run-series-id')
    args = ap.parse_args()
    files = []
    for raw in args.paths:
        p = Path(raw)
        candidates = sorted(x for x in (p.rglob('*') if p.is_dir() else [p]) if x.is_file())
        for f in candidates:
            files.append({'path': str(f), 'sha256': digest(f), 'bytes': f.stat().st_size})
    payload = {
        'run_series_id': args.run_series_id,
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'files': files,
    }
    Path(args.output).write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print(args.output)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
