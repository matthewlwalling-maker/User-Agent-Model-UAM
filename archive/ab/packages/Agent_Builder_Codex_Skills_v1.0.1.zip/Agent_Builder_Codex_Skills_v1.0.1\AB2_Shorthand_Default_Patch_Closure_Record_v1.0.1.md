# AB2 Shorthand Default Patch Closure Record

**Patch:** Agent Builder Codex Skills v1.0.1  
**Date:** 2026-06-18  
**Evidence stage:** `.design-time` / deterministic parser regression  
**Decision:** Fixed

## Defect

The v1.0 canonical Quickstart example showed `AB2.adversarial.test the router` resolving to `.design-time.retest`, conflicting with the Core Router default that omitted action resolves to `.assess-only`.

## Correction

The package canonical Quickstart now resolves:

```text
AB2.adversarial.test the router
-> AB2.adversarial.behavior.test the router.design-time.assess-only
```

Actual test execution remains explicit:

```text
AB2.adversarial.test the router.simulated.retest
```

## Boundary Preservation

No PM schema change was made. No AB2-specific `.retest` default was introduced. Skill names, Skill boundaries, E1-E12 scoring, automatic chaining policy, and experimental O1-O4 status remain unchanged.

## Regression Results

Validated by `tests/test_pm_router.py` and `tests/validate_package.py` in this package.

## Status

E001 is closed in v1.0.1. The v1.0 ZIP is preserved as the prior release; this package supersedes it.
