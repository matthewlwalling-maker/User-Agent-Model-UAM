# 01 — Agent Builder PM Framework: Core Router

**Version:** 1.0 · **Status:** Active · **Authority:** invocation recognition, parsing, default resolution, dispatch (Manifest §3)

This file is intentionally thin. It tells the agent how to **recognize, parse, and dispatch** a PM invocation. It does **not** contain the legal-token tables (`02`), the assessment contract (`03`), the goal-completeness procedure (`04`), the per-AB roles (`05`), or the eval suite (`06`). When in doubt, route to the owning artifact rather than answering from this file.

---

## 1. Agent Builder purpose

Agent Builder is a lifecycle router for reusable agent-design reasoning procedures. The operator invokes a procedure with a compact expression; the agent parses it, resolves defaults, validates it against the registry, and executes the hosting AB's procedure under the shared assessment contract. AB1–AB9 are the only top-level hosts. There is no AB10.

---

## 2. Invocation recognition

Treat a message as a PM invocation when it begins with `AB` followed by a single digit `1`–`9` and a period (e.g., `AB4.`). A message may also arrive as a UI button or shorthand with omitted positions (§4). Anything not matching `AB[1-9].` is ordinary conversation, not an invocation.

---

## 3. Schema parsing

Canonical schema:

```
AB{n}.{mode}[.{lens}].{scope phrase}.{evidence}.{action}[ +open-architecture]
```

Parse by **anchored vocabularies**, not by counting periods, because the scope phrase is natural language and may contain spaces and periods:

1. **Host** — leading `AB{n}`, `n ∈ 1..9`.
2. **Mode** — the next token; must be a registry mode (`02`).
3. **Lens (optional)** — if the token immediately after mode is a registry lens (`02`), consume it as the lens; otherwise there is no explicit lens and scope begins here.
4. **Action** — the last registry action token (`02`) in the string is the action.
5. **Evidence** — the registry evidence token (`02`) immediately preceding the action is the evidence stage.
6. **Flag (optional)** — a trailing ` +open-architecture` suffix.
7. **Scope phrase** — everything between the mode/lens and the evidence token. Preserve it verbatim as natural language.

Evidence, action, and flag are recognized by **membership in their closed vocabularies** (`02`), which is what lets the scope phrase remain free text. If the closed-vocabulary anchors cannot be found, treat as malformed (§9).

---

## 4. Default resolution (shorthand / button entry)

When a position is omitted at a button or shorthand entry, apply the registry defaults:

| Omitted position | Default |
|---|---|
| mode | `.holistic` |
| lens | mode's default lens (`02`) |
| evidence | `.design-time` |
| action | `.assess-only` |

Host and scope are never defaulted — an invocation with no host or no scope is malformed (§9). State each default actually applied in one line before executing, so the resolved invocation is inspectable.

---

## 5. Authority lookup order

Resolve any question by consulting, in order: this router (recognition/parse only) → `02` (is it legal?) → `03` (what must the assessment obey?) → `04` (goal-completeness execution) / `05` (which AB, what defaults/handoffs). Never resolve a legality, contract, or routing question from memory; consult the owning artifact (Manifest §3).

---

## 6. Route-to-resource behavior

After parsing and validation:

1. Dispatch to the hosting AB's entry in `05`; obey that entry's modes, default lens, evidence, actions, handoffs, and stop condition.
2. If mode is `.goal-completeness`, execute `04` under AB4's host rules; honor the Material-path output-order exception (`03` §exception, `04` §7).
3. Apply the shared assessment contract (`03`) to every assessment regardless of host.
4. Emit only the handoffs needed to close material uncertainty (`05` routes).

The router carries forward, unchanged, any prior frozen goal model / capability model / gap register supplied with the invocation (handoff continuity is owned by AB8; the router must not silently drop it).

---

## 7. Universal evidence discipline

Evidence stage is a **mandatory** position and a **claim ceiling**: a conclusion may be stated only at the evidence level actually available. A `.design-time` review may assess architectural plausibility; it may never be phrased as validated runtime behavior. If the operator requests a runtime claim without runtime evidence, downgrade the claim to the available stage and name the verification still required (`03`, `06`).

---

## 8. Action authorization discipline

The action position is what the agent is permitted to do, and is **mandatory**.

- Reject `+open-architecture` with `.assess-only` or any non-generative action before executing anything (`02` flag rule). This is a hard rejection, not a warning.
- Route generative actions by structural reach: `.patch` (local), `.augment` (bounded by N+1), `.rewrite` (whole asset / N+2 cascade) — boundaries owned by `02`. Do not hide a `.rewrite` inside a sequence of nominal `.augment`s.
- Do not perform an irreversible or higher-reach action than the invocation authorizes.

---

## 9. Stop & no-material-change behavior

- "No material change needed" is always an available terminal outcome (`03`, `04` §12). Return it, with marginal-value reasoning, when every Tier 1–2 goal has adequate support and remaining issues are below the action threshold.
- Stop when expected marginal improvement is below complexity, instability, or regression risk. Do not iterate for its own sake.

---

## 10. Malformed invocation handling

Reject (do not guess) and state the specific defect when:

- host is missing or is `AB0`/`AB10`+;
- mode is missing or not a registry mode;
- evidence or action position cannot be resolved to a registry token;
- an explicit lens token is not a registry lens;
- `+open-architecture` accompanies a non-generative action;
- scope phrase is empty.

For a recoverable omission at shorthand entry, apply §4 defaults and proceed (that is not malformed). For an illegal token or illegal combination, reject with the reason and the minimal correction; do not silently normalize an illegal invocation into a legal one.

---

## 11. Preserve natural-language scope

The scope phrase is free text by design. Do not force it into coded tokens, do not strip its words, and do not require the operator to escape periods or spaces inside it. Minimizing operator typing is a goal; rigid syntax is not. Period delimiters and plain-language scope must both remain usable.
