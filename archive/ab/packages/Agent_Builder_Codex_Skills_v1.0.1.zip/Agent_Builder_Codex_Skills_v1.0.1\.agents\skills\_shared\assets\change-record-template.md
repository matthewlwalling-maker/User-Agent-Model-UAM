# Change Record

- Target revision:
- Authorized action:
- Authorized boundary:
- Files/components changed:
- Direct dependencies changed:
- Preserved elements:
- Prohibited propagation respected:
- Tests run:
- Test results:
- Regressions or residual risk:
- Next authorized operation:
