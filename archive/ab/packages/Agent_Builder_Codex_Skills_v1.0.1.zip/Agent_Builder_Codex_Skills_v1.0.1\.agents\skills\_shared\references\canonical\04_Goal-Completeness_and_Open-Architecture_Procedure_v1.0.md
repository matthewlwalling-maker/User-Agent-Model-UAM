# Goal-Completeness & Open-Architecture Procedure v1.0

**Framework:** Agent Builder PM Framework  
**Phase:** 3  
**Status:** Canonical procedure candidate  
**Primary host:** AB4  
**Primary mode:** `.goal-completeness`  
**Optional flag:** `+open-architecture`  
**Governing schema:** `AB{n}.{mode}[.{lens}].{scope phrase}.{evidence}.{action}[ +open-architecture]`

---

## 1. Purpose

This procedure determines whether an existing asset is sufficient, complete, and appropriately structured to accomplish the user’s actual goals.

It is designed to prevent five recurring failures:

1. evaluating only what already exists;
2. mistaking section labels for effective capability;
3. inventing unsupported goals or generic checklist requirements;
4. rewriting sound architecture when a patch or augmentation is enough;
5. continuing to add complexity after material completeness has been reached.

The procedure permits generation of new components, relationships, stages, controls, interfaces, and validation loops when they materially improve goal attainment. It does not treat novelty, maximalism, or first-principles redesign as inherently valuable.

---

## 2. Authority and Locked Dependencies

This procedure inherits and does not reopen the following framework decisions:

- `.goal-completeness` is an assessment mode, primarily hosted by AB4.
- `+open-architecture` is a flag, not a mode or lens.
- `+open-architecture` is legal only with the generative actions authorized by the Component Registry: `.recommend`, `.augment`, `.rewrite`, or `.implement`; it is invalid with `.assess-only` and all other actions.
- Only Tier 1 and Tier 2 goals may drive required architecture by default.
- `.augment` may revise the interfaces of directly affected first-degree dependencies only.
- A required N+2 dependency cascade routes to `.rewrite`.
- Evidence stage and requested action remain mandatory invocation positions.
- “No material change needed” is a valid terminal outcome.
- AB1–AB9 remain the lifecycle router; this procedure does not create AB10.

---

## 3. Procedure Contract

### 3.1 Required inputs

The evaluator should identify, infer, or explicitly mark as unavailable:

- asset or system under review;
- user objective;
- relevant lifecycle stage;
- material constraints;
- evidence stage;
- requested action;
- whether `+open-architecture` is active.

Missing detail does not automatically require clarification. The evaluator should proceed using bounded assumptions unless an unresolved assumption would materially change the architecture or authorize a hard-to-reverse action.

### 3.2 Required outputs

Every completed procedure must contain:

1. scaling-gate path and rationale;
2. goal model;
3. required capability model;
4. asset-to-capability coverage assessment;
5. material gap or sufficiency determination;
6. correct action and fix location;
7. evidence limitation and verification requirement;
8. complexity and stop determination.

The exact headings, tables, and amount of detail may vary with the target. The evaluator must preserve the informational function, not a rigid template.

### 3.3 Hard invariants

The evaluator must:

- use only Tier 1–2 goals to define required architecture;
- distinguish required capabilities from optional opportunities;
- derive the capability model before asset mapping;
- on the Material path, emit the complete capability model before naming or discussing existing asset components;
- distinguish nominal coverage from effective coverage;
- label conclusions according to the supplied evidence stage;
- route patch, augment, or rewrite according to structural reach;
- permit “No material change needed”;
- stop when additional complexity has lower expected value than its burden or regression risk.

### 3.4 Flexible judgments

The evaluator retains discretion over:

- whether the target is Trivial or Material;
- the number and grouping of goals or capabilities;
- the categories used in the capability model;
- whether clarification is needed;
- whether multiple architecture candidates are decision-useful;
- how gaps are prioritized;
- whether a finding is best expressed as a component, relationship, rule, lifecycle stage, runtime mechanism, resource, or test;
- the presentation format, provided output-order independence is preserved.

Heuristics in this procedure guide judgment. They are not substitutes for judgment.

---

## 4. Trivial vs. Material Scaling Gate

### 4.1 Gate objective

Choose the least costly procedure that can still detect a material completeness failure.

The gate is not a quality grade. A polished asset can be Material; an important asset can still be structurally Trivial.

### 4.2 Classification signals

Treat a target as presumptively **Trivial** when most of the following are true:

- one bounded objective;
- a short prompt, contract, component, or single-step output;
- few meaningful dependencies;
- little or no state, tool, resource, governance, or lifecycle interaction;
- a gap can be understood without reconstructing a system;
- likely changes remain local.

Treat a target as presumptively **Material** when any combination of the following materially affects success:

- multiple stages, actors, resources, tools, or outputs;
- coupled components or cross-layer dependencies;
- state, memory, routing, authority, validation, or deployment behavior;
- more than one plausible architecture;
- a completeness error could remain hidden behind nominal section coverage;
- the likely remedy may require augmentation, restructuring, or cross-PM handoff.

The earlier “approximately five components” signal remains a useful orientation, not a hard threshold. Coupling and consequence matter more than raw component count.

### 4.3 Gate decision steps

1. **Identify the unit of assessment.**  
   Determine whether the target is a local artifact, a bounded subsystem, or a multi-part system.

2. **Estimate architectural coupling.**  
   Note whether success depends on relationships, sequencing, state, authority, runtime support, or validation loops.

3. **Estimate omission risk.**  
   Ask whether a missing capability could be detected through a short direct comparison or requires an independent system model.

4. **Select a path.**  
   Choose Trivial when the lightweight pass can reliably expose material gaps. Choose Material when simplification would create anchoring or false-completeness risk.

5. **State the path and one-sentence rationale.**  
   Do not provide a long gate analysis unless the classification itself is disputed or consequential.

6. **Allow reclassification.**  
   If the lightweight pass exposes material coupling, escalate immediately to the Material path. If an initially Material target resolves into a genuinely local question before asset inspection, the evaluator may demote to the Trivial path and explain why.

### 4.4 Trivial path: exact operational sequence

1. State: `Scaling gate: Trivial`, with a brief rationale.
2. Reconstruct the explicit objective and any indispensable implied success condition.
3. Derive a compact required-capability set, normally three to six capabilities but fewer or more when justified.
4. Compare those capabilities directly with the target.
5. Classify each as full, partial, nominal-but-ineffective, absent, duplicated, or misplaced when relevant.
6. Identify only material gaps.
7. Route the result:
   - `.assess-only` or `.recommend` when no artifact change is authorized;
   - `.patch` for a local correction;
   - escalate to the Material path before `.augment` or `.rewrite` if system-level integration has become necessary.
8. Apply the complexity and stop check.
9. Conclude with either the material change required or “No material change needed.”

The Trivial path does not require a sealed independent-model block, multiple architecture candidates, or a full gap register.

### 4.5 Material path: exact operational sequence

1. State: `Scaling gate: Material`, with a brief rationale.
2. Execute the four-tier Inferred-Goal Ladder.
3. Derive the Required Capability Model using only Tier 1–2 goals and material constraints.
4. Emit and seal the capability model before any existing asset component is named or evaluated.
5. Inspect the asset only after the sealed block is complete.
6. Map asset components and behaviors to the required capabilities.
7. Classify coverage.
8. Identify missing components, relationships, rules, stages, controls, runtime support, interfaces, and validation loops.
9. Prioritize only material gaps by contribution to Tier 1–2 goals, omission consequence, confidence, and complexity cost.
10. Decide whether alternative architectures are useful.
11. Route the authorized action: assess, recommend, patch, augment, rewrite, implement, retest, package, or gate.
12. Produce the target architecture or action deliverable at the level warranted by the request.
13. Apply evidence limits and specify follow-on verification.
14. Apply the complexity and stop check.
15. Conclude with a material-change decision, including “No material change needed” when warranted.

---

## 5. Four-Tier Inferred-Goal Ladder

### 5.1 Purpose

The ladder preserves generative reasoning without allowing attractive but unsupported goals to become mandatory architecture.

### 5.2 Tier definitions

| Tier | Label | Qualification test | Architectural effect |
|---|---|---|---|
| 1 | Explicit | Directly stated by the user or governing asset | Required |
| 2 | Strongly implied | Necessary for, or directly entailed by, a Tier 1 goal or material constraint | Required |
| 3 | Plausible future | Reasonably useful later, but not necessary for the stated goal now | Optional only |
| 4 | Speculative opportunity | Adjacent, ambitious, or weakly supported possibility | Excluded unless promoted by the user |

### 5.3 Execution steps

1. **Extract Tier 1 goals.**  
   Preserve the user’s wording where useful. Separate desired outcomes from requested methods.

2. **Derive Tier 2 goals using the necessity test.**  
   A goal qualifies as Tier 2 when omitting it would materially undermine a Tier 1 goal, violate a material constraint, or make the requested outcome nonfunctional.

3. **Place beneficial but nonessential goals in Tier 3.**  
   Do not elevate a goal merely because it is common practice, elegant, scalable, or likely to be useful.

4. **Place weakly supported adjacent opportunities in Tier 4.**  
   These may be named to preserve insight, but they cannot drive required components.

5. **Record the basis and confidence.**  
   For each inferred goal, briefly state why it belongs in that tier. Confidence may be qualitative.

6. **Resolve material ambiguity.**  
   When two plausible Tier 1–2 interpretations would produce materially different architectures:
   - ask one focused clarification when required for correctness or irreversible action; or
   - present bounded branches and continue when a reversible recommendation is sufficient.

7. **Freeze the required-goal set for capability derivation.**  
   Only Tier 1–2 goals enter the required capability model.

8. **Permit later promotion, not silent drift.**  
   A Tier 3–4 goal may become required only through user direction or new governing evidence.

### 5.4 Bidirectional trace rule

- Every required capability must trace to at least one Tier 1–2 goal or material constraint.
- Every Tier 1–2 goal must be supported by at least one required capability.
- A capability without a valid trace is optional, speculative, or unjustified.
- A goal without capability support reveals an architectural gap or an incomplete capability model.

This trace may be expressed as a table, annotations, or concise references. A large matrix is not mandatory when a smaller format is clearer.

---

## 6. Required Capability Model

### 6.1 Derivation question

Ask:

> If no current asset structure were available, what capabilities would be necessary and sufficient to accomplish the frozen Tier 1–2 goal set under the material constraints?

### 6.2 Candidate capability domains

Use only the domains that help explain the target:

- inputs and context;
- reasoning and decisions;
- workflow and lifecycle;
- state and memory;
- resources and source routing;
- tools and deterministic operations;
- boundaries, authority, and governance;
- outputs and interfaces;
- validation, feedback, and regression control;
- maintenance, portability, and extensibility.

These are prompts for discovery, not a checklist. The evaluator may combine, omit, or add domains.

### 6.3 Capability quality test

A required capability should be:

- stated behaviorally rather than as a section title;
- necessary or materially value-adding to Tier 1–2 goals;
- specific enough to assess coverage;
- neutral about the existing implementation;
- no broader than needed to support the goal.

---

## 7. Output-Order Independence Layout

### 7.1 Purpose

The output order makes architectural anchoring inspectable. It does not prove that the model never saw the asset; it ensures the evaluator must present a goal-derived capability model before using the asset’s decomposition as the frame.

### 7.2 Material-path output layout

The following order is mandatory in function, while headings may vary:

#### Block A — Path and Goal Basis

- scaling-gate path;
- evidence stage;
- Tier 1–4 Goal Model;
- material assumptions and constraints.

Do not name or discuss existing asset components.

#### Block B — Independent Required Capability Model

- complete Tier 1–2-derived capability set;
- concise goal-to-capability traces;
- optional Tier 3–4 opportunities clearly separated.

Do not name, quote, mirror, or organize the model around existing asset components.

#### Independence Seal

End Block B with a visible delimiter such as:

`— Independent capability model complete; asset assessment begins below. —`

#### Block C — Substantive Verdict and Asset Mapping

After the seal:

- headline verdict or grade;
- component-to-capability mapping;
- coverage classifications;
- material findings.

#### Block D — Gap and Architecture Decision

- material gap register;
- alternative architecture candidates when decision-useful;
- recommended target architecture;
- action route and correct fix layer.

#### Block E — Evidence, Verification, Complexity, and Stop

- evidence limitation;
- required follow-on test or verification;
- complexity/value assessment;
- terminal decision.

### 7.3 Headline-order exception

For the Material `.goal-completeness` path, output-order independence takes precedence over the generic “headline verdict first” convention.

A procedural path declaration may appear first, but the substantive asset verdict must appear only after the independent capability model is complete. Phase 4 must encode this as a mode-specific output-order exception rather than weakening the universal contract for other modes.

### 7.4 Independence violation and recovery

Independence is violated when Block A or Block B:

- names an existing asset component;
- quotes the asset’s section labels as capability categories;
- assesses current coverage;
- frames the capability model as edits to the current structure.

When a violation occurs, discard the contaminated capability block and restate it in goal-derived, implementation-neutral terms before continuing.

### 7.5 Trivial-path layout

The Trivial path may use:

1. path declaration;
2. compact goal and capability set;
3. direct mapping and verdict;
4. action, evidence, and stop decision.

No seal is required.

---

## 8. Asset Mapping and Coverage Classification

After independence is sealed, inspect actual behavior, not merely labels or stated intent.

| Classification | Meaning |
|---|---|
| Full | The capability is materially present and usable for the stated goal at the available evidence stage. |
| Partial | Some required behavior exists, but a material portion is missing, unreliable, or disconnected. |
| Nominal-but-ineffective | A label, section, or claimed mechanism exists, but the required behavior is not actually established. |
| Absent | No meaningful implementation is present. |
| Duplicated | Multiple components cover substantially the same function without justified reinforcement. |
| Misplaced | The capability exists in a layer or component that creates boundary, maintenance, authority, or execution problems. |

A design-time review may assess whether the architecture plausibly supports a capability. It may not claim observed runtime effectiveness without the corresponding evidence.

---

## 9. Gap Discovery and Prioritization

### 9.1 Search space

A material gap may be:

- a missing component;
- a missing relationship or dependency;
- a missing decision or routing rule;
- a missing lifecycle stage;
- missing state or memory behavior;
- missing runtime or tool support;
- missing source authority or resource;
- missing user interaction or interface behavior;
- missing validation, feedback, or regression loop;
- a duplicated, overloaded, or misplaced capability.

### 9.2 Gap qualification

A gap is material when it:

- prevents or substantially weakens a Tier 1–2 goal;
- creates a likely failure mode with meaningful consequence;
- forces another component to operate outside its intended boundary;
- blocks verification, safe action, maintenance, or reliable handoff where those are necessary to the goal.

### 9.3 Prioritization factors

Use judgment across:

- contribution to Tier 1–2 goals;
- consequence of omission;
- confidence in the diagnosis;
- dependency reach;
- implementation burden;
- regression or instability risk.

A numeric score is optional. Do not fabricate precision.

---

## 10. Open-Architecture Execution

### 10.1 Effect of the flag

The flag is accepted only with `.recommend`, `.augment`, `.rewrite`, or `.implement`. Invalid action combinations must be rejected before the procedure runs.

`+open-architecture` directs the evaluator to treat the current asset as evidence and one candidate solution, not as the solution-space boundary.

The evaluator may propose:

- new decomposition;
- new components or lifecycle stages;
- different core/resource/runtime placement;
- deterministic subsystems;
- new validation or feedback loops;
- different interfaces or authority boundaries.

The flag does not authorize speculative expansion. Every required proposal still traces to Tier 1–2 goals.

### 10.2 Alternative-architecture trigger

Generate multiple architecture candidates when they would expose a real decision, particularly when:

- two or more components are materially misplaced or duplicated;
- a required capability has no coherent home in the current decomposition;
- `+open-architecture` is active;
- the asset’s structure creates material uncertainty about whether augmentation or restructuring is superior.

The evaluator may provide one architecture when alternatives would be cosmetic or redundant, but must briefly state why variants add no decision value.

### 10.3 Candidate forms

When multiple candidates are warranted, useful forms include:

1. conservative augmentation;
2. optimized restructuring;
3. open-architecture ideal.

These labels are optional. The candidates should differ in meaningful structural tradeoffs, not wording.

---

## 11. Action Routing and Structural Reach

### 11.1 Route by the smallest sufficient change

| Action | Use when |
|---|---|
| `.assess-only` | Evaluation is requested and no generative flag is active. |
| `.recommend` | The user wants a decision or target state without direct artifact modification. |
| `.patch` | A known local defect can be corrected while unnamed components remain stable. |
| `.augment` | The base architecture is sound but lacks a material capability that can be integrated within the N+1 dependency radius. |
| `.rewrite` | The base architecture is materially defective, approximately 40% or more is misplaced/duplicated/ineffective, or required integration creates an N+2 cascade. |
| `.implement` | The authorized target architecture should be applied. |
| `.retest` | The relevant implementation or runtime behavior should be evaluated again. |
| `.package` | The procedure outputs should be converted into a portable execution or handoff packet. |
| `.gate` | The result should produce a readiness decision. |

The approximate 40% indicator is a routing heuristic, not a mechanical count. Structural centrality and dependency impact may outweigh the number of components.

### 11.2 N+1 Dependency Radius

For `.augment`:

- the new or materially revised component is N;
- interfaces of directly connected first-degree neighbors may be revised;
- second-degree or broader cascading revisions are not augmentation;
- when coherent integration requires N+2 propagation, route to `.rewrite`.

Do not hide a rewrite inside a sequence of nominal augmentations.

### 11.3 Correct fix layer

Place the remedy where the failure originates:

- core instruction;
- procedure or registry;
- resource or source map;
- schema or deterministic logic;
- runtime/tool integration;
- evaluation harness;
- interface or output compiler;
- deployment/governance layer.

A gap discovered during core review does not automatically belong in core.

---

## 12. Complexity and Stop Check

### 12.1 Required questions

Before finalizing, ask:

1. Does each required addition materially support a Tier 1–2 goal?
2. Is the proposed structure simpler than another equally effective option?
3. Does the expected value exceed implementation, maintenance, and regression cost?
4. Is any Tier 3–4 opportunity being presented as mandatory?
5. Would further iteration materially change the decision or expected outcome?

### 12.2 Valid terminal outcomes

#### Material change required

Use when one or more material Tier 1–2 gaps remain.

State:

- the gap;
- consequence;
- smallest sufficient action;
- verification requirement.

#### No material change needed

Use when:

- every Tier 1–2 goal has adequate capability support at the assessed evidence stage;
- remaining issues are cosmetic, low-value, speculative, or below the action threshold;
- additional architecture would add more burden or risk than expected value.

The evaluator may still list optional Tier 3–4 enhancements, but must not present them as defects or required next steps.

#### Insufficient evidence for effectiveness

Use when architecture appears complete at design time but runtime or post-implementation behavior is unverified.

This is not the same as an architectural gap. Route verification to the appropriate AB2, AB3, AB5, AB6, or AB7 procedure.

---

## 13. Evidence and Follow-On Routing

The procedure must match claims to evidence:

- `.design-time` → architectural plausibility and textual completeness;
- `.simulated` → behavior under controlled test prompts or fixtures;
- `.live-runtime` → observed execution in the active environment;
- `.post-implementation` → verification after a specific change;
- `.production-observed` → repeated real-world behavior.

Typical handoffs:

- gap implementation → AB1;
- adversarial or runtime testing → AB2;
- original-versus-target comparison → AB3;
- readiness gate → AB5;
- failure diagnosis or regression → AB6;
- burden, clarification, or interface calibration → AB7;
- state-preserving handoff → AB8;
- portable execution packet → AB9.

The procedure should recommend only the handoffs needed to close material uncertainty.

---

## 14. Minimum Output Templates

### 14.1 Trivial path

```text
Scaling gate: Trivial — [reason]

Goal and required capabilities
- [goal/capability]
- [...]

Coverage and verdict
- [coverage finding]

Action
- [smallest sufficient action or No material change needed]

Evidence and stop
- Evidence stage: [...]
- Verification: [...]
- Stop condition: [...]
```

### 14.2 Material path

```text
Scaling gate: Material — [reason]
Evidence stage: [...]

Goal Model
- Tier 1: [...]
- Tier 2: [...]
- Tier 3: [...]
- Tier 4: [...]

Independent Required Capability Model
- [capability] ← [Tier 1/2 trace]
- [...]

— Independent capability model complete; asset assessment begins below. —

Headline verdict
[verdict]

Coverage assessment
[map or findings]

Material gap register
[gaps, placement, dependency reach, priority, confidence, cost]

Architecture decision
[target architecture or No material change needed]

Action and routing
[action, fix layer, follow-on AB route]

Evidence, verification, complexity, and stop
[limits, test requirement, marginal-value conclusion]
```

These templates are defaults, not formatting mandates.

---

## 15. Procedure Self-Check

Before returning the result, verify:

- Was the scaling path stated and proportionate?
- Did only Tier 1–2 goals drive required architecture?
- Does every required capability trace to a Tier 1–2 goal or constraint?
- Does every Tier 1–2 goal have capability support?
- On the Material path, was the independent model completed before asset reference?
- Was nominal coverage distinguished from effective coverage?
- Were changes routed by smallest sufficient structural reach?
- Was the N+1 limit preserved for augmentation?
- Were design-time and runtime claims separated?
- Were optional opportunities kept optional?
- Was “No material change needed” genuinely available?
- Did the evaluator stop when marginal value fell below cost or risk?

A failed self-check should cause targeted correction of the affected section, not an automatic full rewrite of the assessment.

---

## 16. Phase 4 Transition Rules

Phase 4 updates the AB1–AB9 Registry. It must consume this procedure without duplicating it.

### 16.1 Registry entries to add or revise

1. **AB4**
   - primary host for `.goal-completeness`;
   - default lens `.architecture`;
   - default evidence `.design-time`;
   - legal actions governed by the Component Registry;
   - output-order exception reference for the Material path;
   - `+open-architecture` routing.

2. **AB1**
   - consumes the gap register and target architecture;
   - applies `.patch`, `.augment`, `.rewrite`, or `.implement`;
   - must preserve the N+1 augmentation limit.

3. **AB2**
   - validates E1–E12 and any implementation-specific evals;
   - tests evidence claims rather than redefining the goal model.

4. **AB3**
   - compares original, augmented, or rewritten architectures against the frozen Tier 1–2 goal and capability model.

5. **AB5**
   - gates deployment only after required post-implementation evidence is available.

6. **AB6**
   - diagnoses procedure failures, including anchoring, over-expansion, incorrect tiering, and action misrouting.

7. **AB7**
   - calibrates gate burden, clarification behavior, interface usability, and stop conditions.

8. **AB8**
   - carries forward the frozen goal model, capability model, gap register, action decision, evidence limits, and unresolved risks.

9. **AB9**
   - packages the procedure inputs and outputs without collapsing Tier 3–4 opportunities into requirements.

### 16.2 Registry reference rule

The AB1–AB9 Registry should reference this procedure by name and version. It should not reproduce the full ladder, gate, coverage taxonomy, or templates.

### 16.3 Output-order rule

The registry must encode:

> For `AB4.goal-completeness` on the Material path, the procedure-specific independence order overrides the generic headline-first output convention.

### 16.4 Handoff state

A Phase 4 handoff is complete only when it preserves:

- selected scaling path;
- frozen Tier 1–2 goal set;
- independent capability model;
- gap or sufficiency decision;
- structural-reach determination;
- evidence stage;
- verification requirement;
- stop condition.

---

## 17. E1–E12 Validation Criteria

| Eval | Required observable behavior |
|---|---|
| E1 — Architectural anchoring | Material path; independent capability model appears before any asset component reference; absent capability is surfaced. |
| E2 — Checklist completeness | Required capabilities trace only to Tier 1–2 goals; generic extras are Tier 3–4 or excluded. |
| E3 — Rewrite bias | Sound base with one gap routes to patch or augment; unaffected strengths remain preserved. |
| E4 — Over-expansion | Minimal goal receives minimal sufficient architecture; low-value additions fail the complexity check. |
| E5 — Goal hallucination | Ambitious adjacent goal remains Tier 3–4 and does not drive required architecture. |
| E6 — False coverage | A nominal section without functional behavior is classified nominal-but-ineffective. |
| E7 — Evidence overclaim | Static review remains design-time; runtime effectiveness is not asserted. |
| E8 — Failure to stop | Sufficient asset returns “No material change needed” with marginal-value reasoning. |
| E9 — Scaling-gate abuse | Bounded target takes the Trivial path and skips the sealed full-procedure ritual. |
| E10 — Wrong-layer gap | Remedy is placed in the correct resource, schema, runtime, eval, interface, or governance layer rather than defaulting to core. |
| E11 — Orphan ideal | `+open-architecture` with `.assess-only` is rejected before procedure execution. |
| E12 — Independence theater | Any early asset reference contaminates the model; the evaluator detects and restates it before mapping. |

### 17.1 Acceptance threshold

The inherited acceptance threshold remains:

- at least 10 of 12 cases pass;
- zero failures on E1, E7, E8, or E11.

A procedure revision is warranted when a failure is:

- reproducible;
- attributable to procedural ambiguity or conflict;
- material to user value or framework integrity.

Do not expand the procedure merely to eliminate isolated model variance, cosmetic differences, or evaluator formatting preferences.

---

## 18. Decision on Prior Constraints

**No material change needed.**

The locked schema, component roles, four-tier boundary, N+1 augmentation radius, and E1–E12 design remain sufficient.

Four targeted clarifications are incorporated:

1. the scaling gate uses coupling and omission risk, not a rigid component count;
2. the path may be reclassified when new structural information emerges;
3. Material-path output-order independence overrides the generic headline-first convention;
4. architecture variants are required only when they expose a real decision.

These clarifications operationalize the existing architecture without reopening it.
