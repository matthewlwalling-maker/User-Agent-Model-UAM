# Package Manifest

**Package:** Agent Builder Codex Skills  
**Version:** 1.0.1  
**Release status:** Yellow — repo-scoped design-time deployable for smoke testing

## Execution authority

1. Root `AGENTS.md` owns bare Prompt Macro compatibility behavior.
2. Each operational `SKILL.md` owns its workflow.
3. `_shared/references/canonical/00–08` remains the governing framework source set.
4. `_shared/scripts/validate_pm_invocation.py` owns deterministic Prompt Macro normalization for this package.
5. Package validation records describe readiness but do not override workflow authority.
6. `/future/experimental-operator-prototype` is non-governing.

## Operational inventory

Seven implicit-capable Skills plus one explicit-only router utility.

## Package companion artifacts

- alignment decision record;
- operation extraction and tiering;
- implementation decisions and source errata;
- AB2 shorthand default patch closure record;
- deferred-capabilities register;
- deployment validation record;
- installation guide;
- checksums;
- tests.

## Patch revision 1.0.1

This patch corrects the canonical Quickstart AB2 shorthand example to follow the Core Router action default. It does not change Skill names, Skill boundaries, the PM schema, E1-E12 scoring, automatic chaining policy, or experimental O1-O4 status.
