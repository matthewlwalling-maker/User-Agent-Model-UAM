# Skill Architecture and Operation Map

## Deployment model

Seven focused operational Skills share one governance library. The Prompt Macro layer is a thin compatibility adapter. Modes, lenses, evidence stages, and actions remain parameters—not separate Skills.

## Operation ownership

| Skill | Owns | Does not own |
|---|---|---|
| `architecture-assessment` | goal model, required capability model, coverage, gaps, target recommendation | file modification, test execution, readiness gate |
| `artifact-change` | authorized patch/augment/rewrite/implementation and change record | open-ended goal redefinition, independent gating |
| `adversarial-evaluation` | failure-seeking tests, runs, evidence capture, pass/fail | target repair during frozen run, root-cause certainty without triage |
| `version-comparison` | frozen-basis comparison, ranking, donor components, synthesis | criterion drift, implementation |
| `failure-triage` | observed failure classification, fix layer, smallest remedy; AB7 profile | speculative runtime claims, broad rewrite without evidence |
| `deployment-readiness` | Green/Yellow/Red/Blocked gate and advancement conditions | implementation or invented evidence |
| `handoff-package` | state-preserving handoff and compact packet | changing committed state or evidence promotion |

## Shared infrastructure

- `AGENTS.md`: recognizes bare AB macros and delegates.
- `validate_pm_invocation.py`: deterministic legality, normalization, and mapping.
- `_shared/references`: canonical authority and governance.
- `_shared/assets`: output templates.
- `_shared/scripts`: source freeze, run capture, and handoff packaging.

## Experimental boundary

The O1–O4 operator prototype is retained only under `/future`. It may inform future typed orchestration after comparative validation; it does not govern v1 execution.
