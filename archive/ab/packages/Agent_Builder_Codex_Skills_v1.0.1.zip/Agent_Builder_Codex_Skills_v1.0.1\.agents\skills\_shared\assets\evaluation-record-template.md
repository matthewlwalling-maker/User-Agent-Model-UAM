# Evaluation Record

- Run ID:
- Target revision:
- Evidence stage:
- Frozen goal/capability basis:
- Fixtures and commands:
- Raw output location:

## Case results

## Threshold result

## Failure classifications

## Evidence limitations

## Recommended next operation
