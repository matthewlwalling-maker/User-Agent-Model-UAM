# Minimum Composition Spike Architect — Agent Builder Experiment v0.1

**Artifact type:** Design-time architectural spike  
**Decision scope:** Four contract-bearing operators and five shared state objects only  
**Baseline:** Agent Builder Assessment Contract v1.0; Goal-Completeness & Open-Architecture Procedure v1.0; E1–E12 Adversarial Eval Suite v1.0; Component Registry v1.0 where action-boundary semantics are needed  
**Evidence stage:** Design-time only  
**Replacement status:** Not authorized; this artifact defines an experiment, not a migration

---

## 1. Experiment verdict upfront

### Verdict

**The spike is worth constructing as scoped, but only as a comparative implementation prototype—not as a replacement architecture.**

The four-operator model can reproduce most of the legacy procedure’s important behavioral safeguards while making composition, stale-state detection, evidence provenance, and failure ownership more observable. Its strongest plausible advantage is not better reasoning by itself. It is the ability to make illegal sequencing and unsupported claim promotion structurally detectable rather than merely procedurally discouraged.

The proposed architecture does **not yet demonstrate a capability advantage**. At design time, three of its apparent improvements are partly contract externalization:

1. the legacy goal ladder becomes a typed `GoalContract`;
2. the independent capability block becomes a committed `CapabilityModel` boundary;
3. the legacy action and stop logic becomes `ChangeDecision`.

Those are useful only if they reduce critical failures, localize failures more accurately, or preserve quality with less context—not because they are cleaner nouns.

### Most likely falsifier

**The most likely falsifier is change-boundary quality.** `Choose Intervention or Stop` cannot distinguish a local change from a semantically system-wide change unless `Assess Capability Coverage` emits reliable dependency-impact observations. If the third operator must perform substantial graph, interface, and propagation analysis to make the fourth operator valid, then either:

- the third operator has become a hidden dependency-impact operator; or
- the four-operator boundary is too small and intervention routing will degrade relative to the legacy N+1/N+2 procedure.

Case 8—where a change is graphically near but semantically system-wide—is therefore the most important test in the prototype.

### Secondary falsifier

The secondary falsifier is **small-task burden**. If a trivial three-field contract requires five fully populated state objects and four explicit handoffs, the operator system loses the legacy scaling gate’s burden control. The spike therefore uses a compact projection for trivial work; if that projection cannot preserve the same safeguards, typed state is not justified for trivial tasks.

### Design-time conclusion

The architecture is **promising as an execution substrate for the legacy reasoning procedure**, but it is not yet a replacement for the broader AB1–AB9 lifecycle system. It may prove that AB routing and the six-position invocation schema are interface/lifecycle layers rather than the underlying capability model. It does not yet prove that the operator model is itself the better capability model.

---

## 2. Minimal state model

### 2.1 State-model principles

The state model exists only to make composition and failure observable. It must not become a substitute for generative reasoning.

The five state objects use a shared metadata envelope. The envelope is a convention, **not a sixth state object**.

#### Common metadata envelope

| Field | Requirement | Purpose |
|---|---:|---|
| `object_id` | Required | Stable identity for references and stale-state checks. |
| `schema_version` | Required | Contract version, initially `mcs-0.1`. |
| `revision` | Required | Monotonic object revision. |
| `status` | Required | `draft`, `committed`, `contested`, `invalid`, or `superseded`. |
| `branch_id` | Required | Branch identity; default `main`. |
| `parent_refs` | Required after first revision | Exact upstream object revisions used to create this revision. |
| `producer` | Required | Operator name or `external-intake`. |
| `evidence_refs` | Required, may be empty | References to supporting `EvidenceLedger` entries. |
| `conflict_refs` | Optional | Competing branches or claims that prevent silent convergence. |

#### Common validation rules

1. A downstream object may consume only `committed` upstream revisions unless its contract explicitly allows contested branches.
2. Any upstream revision change makes downstream objects stale until revalidated or regenerated.
3. A field may not silently change meaning between revisions.
4. Conflicting claims remain on separate branches. A merge creates a new revision with both parents and an explicit `resolution_basis`.
5. No object may claim an evidence stage higher than the highest applicable evidence entry supporting that claim.
6. `invalid` and `contested` are observable states, not errors to hide by auto-completion.

### 2.2 `GoalContract`

#### Purpose

Capture the target outcome, material constraints, and the boundary between required and non-required obligations before capability derivation.

#### Minimum required fields

| Field | Minimum content |
|---|---|
| `target_ref` | The asset/system/question being assessed, without using its component structure as the goal frame. |
| `outcome_statement` | The user-visible result to be accomplished. |
| `obligations[]` | Each obligation has `id`, `statement`, `class`, `basis`, `source_refs`, and `confidence`. |
| `constraints[]` | Each material constraint has `id`, `statement`, `basis`, and `source_refs`. |
| `assessment_profile` | `compact` or `material`, with one-sentence basis. |
| `unresolved_ambiguities[]` | Material ambiguities, bounded assumptions, or empty. |
| `freeze_state` | `open`, `committed`, or `blocked`. |

#### Obligation classes

| Class | Required architecture effect |
|---|---|
| `explicit-required` | Drives required capabilities. |
| `entailed-required` | Drives required capabilities because omission would materially defeat an explicit outcome or constraint. |
| `optional` | May be retained as an opportunity but cannot drive required capability. |
| `speculative` | Excluded from required architecture unless promoted by new user direction or governing evidence. |

This is semantically close to the legacy Tier 1–4 ladder. The experiment does not claim that renaming the ladder is an architectural gain.

#### Optional fields

- `requested_claim` — e.g., design completeness, simulated behavior, production effectiveness.
- `authorized_decision_scope` — assess, recommend, or decide only; no implementation authority is implied.
- `alternative_interpretations[]` — bounded branches where clarification is not mandatory.
- `excluded_methods[]` — requested methods explicitly separated from outcomes.

#### Provenance requirements

- Every explicit obligation cites the user request or governing source.
- Every entailed obligation states the necessity argument.
- Optional and speculative obligations retain their basis so they can be promoted later without being silently required now.
- Any assumption that materially affects capability derivation is represented, not buried in prose.

#### Validation rules

- At least one `explicit-required` obligation exists.
- Every `entailed-required` obligation includes a necessity basis.
- No `optional` or `speculative` item has `required=true` or equivalent effect.
- The `assessment_profile` is based on coupling and omission risk, not polish or component count alone.
- `freeze_state=committed` only when unresolved ambiguity would not materially change the required capability set, or when bounded branches are explicitly preserved.

#### Invalid or incomplete states

- Required versus optional basis is missing.
- The outcome is only a requested method with no recoverable objective.
- Two material interpretations are silently merged.
- A polished asset’s section labels are copied into obligations without user-goal justification.
- `compact` is selected despite material coupling or hidden omission risk.

#### Field ownership

| Field | Create/modify authority |
|---|---|
| Outcome, obligations, constraints, profile, ambiguity, freeze state | `Normalize Goal and Obligations` only. |
| Metadata and provenance references | Creating operator; later correction by a superseding revision from the same operator. |
| External source statements | External intake may seed; the operator normalizes but does not rewrite source provenance. |

#### Disagreement representation

Competing goal interpretations receive separate `branch_id` values. A branch may be selected only with an explicit reason. A merged goal contract must reference both parent branches and state what evidence resolved the disagreement.

---

### 2.3 `CapabilityModel`

#### Purpose

Represent the implementation-neutral capabilities necessary and sufficient, at design time, to satisfy the committed required obligations.

#### Minimum required fields

| Field | Minimum content |
|---|---|
| `goal_contract_ref` | Exact committed `GoalContract` revision. |
| `capabilities[]` | Each has `id`, behavioral statement, required-obligation refs, success condition, scope boundary, and confidence. |
| `obligation_coverage` | Trace showing every required obligation has at least one capability. |
| `derivation_boundary` | Inputs available, forbidden inputs, and whether asset decomposition was withheld, unavailable, or available-but-not-used. |
| `model_completeness` | `candidate-complete`, `incomplete`, or `contested`, with basis. |
| `open_questions[]` | Unresolved questions that may change the model. |

#### Optional fields

- `capability_relations[]` — sequencing, dependency, or interaction needed to understand sufficiency.
- `alternative_models[]` — references to separately committed branches.
- `nonrequired_opportunities[]` — optional ideas retained without entering the required model.
- `sufficiency_rationale` — concise explanation of why the set is neither under- nor over-inclusive.

#### Provenance requirements

- Every capability traces to at least one required obligation or material constraint.
- Every required obligation traces to at least one capability.
- Inferences reference the goal or constraint that licenses them.
- The derivation packet is recorded so independence can be inspected.

#### Validation rules

- Capability statements are behavioral, not asset section titles.
- No capability is required solely because it is conventional, elegant, scalable, or present in the asset.
- Material-path derivation may not consume asset component names, asset section labels, current coverage judgments, or proposed edits.
- `candidate-complete` is a design-time claim only; it does not assert that an asset implements the model.
- If two capability models disagree materially, neither is silently treated as canonical.

#### Invalid or incomplete states

- The referenced `GoalContract` is stale, contested, or not committed.
- An untraced capability is marked required.
- An obligation lacks capability support.
- The model mirrors the asset’s decomposition without a goal-derived reason.
- Independence is claimed despite an undocumented input packet.

#### Field ownership

| Field | Create/modify authority |
|---|---|
| Capabilities, traces, relations, derivation boundary, completeness | `Derive Required Capabilities` only. |
| Coverage or asset implementation claims | No authority; those belong in `CoverageMap`. |
| Intervention or change reach | No authority; those belong in `ChangeDecision`. |

#### Disagreement representation

Materially different capability sets remain separate branches. Reconciliation is another execution of `Derive Required Capabilities`, producing a new branch with explicit comparison and resolution basis. Downstream assessment may evaluate branches separately; it may not average or union them silently.

---

### 2.4 `EvidenceLedger`

#### Purpose

Provide one append-only, shared source of evidence provenance and claim ceilings across all state objects.

#### Minimum required fields

| Field | Minimum content |
|---|---|
| `entries[]` | Each entry contains `evidence_id`, `source_ref`, `source_type`, `stage`, `statement`, `claim_refs`, `polarity`, `scope`, `limitations`, and `recorded_by`. |
| `stage_vocabulary` | `design-time`, `simulated`, `live-runtime`, `post-implementation`, `production-observed`. |

`polarity` is `supports`, `contradicts`, or `context-only`.

#### Optional fields

- `collection_method`
- `asset_version_ref`
- `test_case_ref`
- `supersedes_evidence_id`
- `reliability_note`

#### Provenance requirements

- Every entry has a resolvable source or is explicitly marked `model-inference`.
- Model inference cannot be promoted into observed evidence.
- Corrections supersede entries; they do not erase history.
- Evidence scope identifies which asset version, branch, capability, or claim it applies to.

#### Validation rules

- A claim may not cite an evidence entry whose scope does not cover it.
- A claim’s stage may not exceed the entry’s stage.
- `production-observed` requires repeated real-world observations, not a static design or one simulation.
- New evidence is required for stage promotion; rewording a claim is insufficient.
- Contradictory entries remain visible.

#### Invalid or incomplete states

- An entry lacks a source, scope, or stage.
- A design document is recorded as runtime observation.
- One evidence item is generalized beyond its asset version or test scope.
- Contradictory evidence is silently deleted or merged.

#### Field ownership

| Ledger operation | Authority |
|---|---|
| Seed source evidence | External intake. |
| Append goal/constraint evidence | `Normalize Goal and Obligations`. |
| Append derivation assumptions/inferences | `Derive Required Capabilities`. |
| Append asset observations and test evidence | `Assess Capability Coverage`. |
| Append no new factual evidence | `Choose Intervention or Stop`; it may only reference existing entries and record decision rationale in `ChangeDecision`. |
| Modify/delete prior entry | None. Corrections use superseding entries. |

#### Disagreement representation

Conflicting evidence entries coexist with opposite polarity. A state object that depends on the conflict becomes `contested` or branches. No operator may resolve evidence conflict merely by choosing the preferred entry without a stated adjudication rule.

---

### 2.5 `CoverageMap`

#### Purpose

Assess how the actual asset’s behavior covers each required capability at the available evidence stage, while exposing enough structural impact information for a later change decision.

#### Minimum required fields

| Field | Minimum content |
|---|---|
| `capability_model_ref` | Exact committed model revision. |
| `goal_contract_ref` | Exact goal contract revision. |
| `asset_ref` | Exact asset or system version assessed. |
| `evidence_ledger_ref` | Ledger revision used. |
| `coverage_entries[]` | Per capability: `capability_ref`, classification, asset behavior refs, evidence refs, rationale, confidence, and unresolved evidence. |
| `gap_entries[]` | Material missing/partial/ineffective capability, consequence, and likely origin layer candidates. |
| `impact_observations[]` | For each material gap: touched elements, directly connected elements, possible broader propagation, semantic centrality, and unknowns. |
| `assessment_stage` | Highest evidence stage actually supported for each material conclusion. |

#### Coverage classifications

- `full-at-stage`
- `partial`
- `nominal-but-ineffective`
- `absent`
- `duplicated`
- `misplaced`
- `unknown-insufficient-evidence`

#### Optional fields

- `strengths_to_preserve[]`
- `coverage_relations[]`
- `failure_scenarios[]`
- `layer_candidates[]`
- `branch_comparison[]`

#### Provenance requirements

- Every coverage classification cites asset behavior and evidence, not a heading alone.
- “Full” is always qualified by evidence stage.
- Impact observations distinguish direct graphical proximity from semantic reach.
- Uncertainty is recorded where dependency information is absent.

#### Validation rules

- Every required capability has one coverage entry or an explicit unknown status.
- `full-at-stage` is invalid on label match alone.
- Runtime or production effectiveness is invalid without corresponding evidence.
- Gap consequence traces to a required obligation.
- `impact_observations` may describe reach but may not choose patch, augmentation, or restructure.
- A materially disputed capability model is assessed branch by branch.

#### Invalid or incomplete states

- Assessment begins before a valid capability model exists.
- Asset version is unspecified.
- Coverage is inferred from nominal labels.
- A plausibility claim is restated as validated behavior.
- Structural-reach facts needed for intervention are missing but the map presents itself as decision-ready.

#### Field ownership

| Field | Create/modify authority |
|---|---|
| Coverage, gaps, observed layer, impact observations, preserved strengths | `Assess Capability Coverage` only. |
| Capability requirements | No authority. |
| Final fix layer or action route | No authority. |

#### Disagreement representation

Different asset interpretations or capability branches produce separate coverage branches. A downstream decision may choose between them only if the decision is invariant across branches; otherwise it must return `blocked-by-material-disagreement`.

---

### 2.6 `ChangeDecision`

#### Purpose

Choose the smallest defensible intervention—or stop—without exceeding evidence or structural-impact knowledge.

#### Minimum required fields

| Field | Minimum content |
|---|---|
| `coverage_map_ref` | Exact committed `CoverageMap` revision. |
| `decision` | One of the allowed terminal decisions below. |
| `target_gap_refs[]` | Material gaps addressed, or empty for no-change. |
| `selected_fix_layer` | Originating layer, `multiple`, `unknown`, or `not-applicable`. |
| `change_boundary` | Touched elements, preserved elements, allowed neighbor changes, prohibited propagation, and uncertainty. |
| `decision_basis` | Goal, coverage, evidence, burden, and risk rationale. |
| `evidence_ceiling` | Highest claim stage supported. |
| `verification_required` | What evidence would be needed after change or to answer a higher-stage claim. |
| `stop_reason` | Why this is terminal for the four-operator spike. |
| `confidence` | Diagnostic confidence, separate from severity. |
| `next_consumer_contract` | Minimum inputs required by an external implementer, tester, or evaluator; may be `none`. |

#### Allowed decisions

- `no-material-change`
- `local-correction`
- `bounded-capability-addition`
- `system-restructure`
- `verification-required`
- `blocked-by-insufficient-impact-knowledge`
- `blocked-by-material-disagreement`
- `stop-unowned-operation`

#### Optional fields

- `alternatives_rejected[]`
- `severity`
- `residual_risks[]`
- `optional_opportunities[]`
- `revisit_trigger`

#### Provenance requirements

- Every action decision cites coverage and impact observations.
- Every no-change decision cites adequate support for required obligations and marginal-value reasoning.
- Verification requirements identify the evidence stage still owed.
- A restructure decision states why bounded addition is insufficient.

#### Validation rules

- `no-material-change` is valid only when all required capabilities are adequately covered at the assessed stage and remaining issues are optional, cosmetic, speculative, or below threshold.
- `bounded-capability-addition` is invalid when broader propagation is known or materially unresolved.
- `system-restructure` is invalid merely because prose is uneven or a cleaner architecture exists.
- `verification-required` is mandatory when the requested claim exceeds available evidence and no architecture gap is established.
- `stop-unowned-operation` names the missing job; it does not invent a fifth operator.
- No decision authorizes implementation; this spike is assessment-only.

#### Invalid or incomplete states

- Coverage map is stale or contested in a decision-material way.
- Change reach is selected without impact evidence.
- Optional opportunities are presented as defects.
- A production claim is made from design-time evidence.
- No stop rationale is present.

#### Field ownership

All substantive fields are created or modified only by `Choose Intervention or Stop`. Upstream operators may not preselect the action.

#### Disagreement representation

If competing valid branches produce different actions, the decision is `blocked-by-material-disagreement`. A branch-specific decision may still be recorded, but no universal decision is issued.

---

## 3. Four operator contracts

### 3.1 Operator 1 — Normalize Goal and Obligations

| Contract element | Specification |
|---|---|
| **Purpose and owned transformation** | Convert intake language and governing constraints into a committed `GoalContract`; own required/optional classification and compact/material profile. |
| **Valid selection conditions** | No current `GoalContract`; goal/constraint evidence changed; current contract is stale, invalid, or explicitly reopened. |
| **Explicit non-selection conditions** | A committed current `GoalContract` already exists and no relevant intake changed; the task is capability derivation, asset coverage, or intervention choice. |
| **Consumed state** | Existing `GoalContract` metadata and fields when revising; `EvidenceLedger` entries relevant to user goals and constraints. External intake may be consumed but is not a shared state object. |
| **Preconditions** | A target outcome can be identified or bounded assumptions can be stated; source provenance is available or explicitly unavailable. |
| **Produced state** | New or revised `GoalContract`; append-only goal/constraint entries in `EvidenceLedger`. |
| **Postconditions** | Required obligations are separated from optional/speculative opportunities; material constraints are explicit; assessment profile and ambiguity state are inspectable. |
| **Invariants** | Only explicit and logically entailed obligations may drive required architecture; methods are not automatically treated as outcomes; attractive adjacent goals remain optional/speculative; no asset coverage judgment occurs. |
| **Evidence and claim ceiling** | May claim that an obligation is explicit, entailed, optional, or speculative based on request/constraints. May not claim required capabilities, asset sufficiency, or runtime effectiveness. |
| **Read authority** | User request, governing goal statements, constraints, prior goal branches, relevant evidence. May read an asset’s declared purpose but not use its component decomposition as the goal taxonomy. |
| **Write authority** | `GoalContract`; relevant append-only `EvidenceLedger` entries. No write to other state objects. |
| **Permitted side effects** | None. One focused clarification may be requested only when unresolved ambiguity materially changes architecture or authorizes a hard-to-reverse decision. |
| **Legal downstream consumers** | `Derive Required Capabilities`; selector; independent evaluator. |
| **Failure exits** | `blocked-material-ambiguity`; `no-recoverable-outcome`; `provenance-missing`; `branch-conflict`. |
| **Local stop condition** | Stop when the goal contract is committed, or when a named failure exit prevents a valid commitment. |

#### Adversarial contract tests

1. **Optional-goal temptation:** An attractive future capability must remain `optional` or `speculative`.
2. **Missing basis:** A required/optional label without basis makes the contract invalid.
3. **Method/outcome confusion:** “Rewrite this as a multi-agent system” does not prove multi-agent architecture is the goal.
4. **Trivial burden:** A bounded three-field contract should produce a compact goal contract, not enterprise metadata.
5. **Conflicting user sources:** Contradictory goals create branches or a clarification, not a silent merge.

---

### 3.2 Operator 2 — Derive Required Capabilities

| Contract element | Specification |
|---|---|
| **Purpose and owned transformation** | Produce an implementation-neutral `CapabilityModel` from the committed required obligations. |
| **Valid selection conditions** | A current committed `GoalContract` exists; no current capability model matches its revision; a model branch requires explicit re-derivation or adjudication. |
| **Explicit non-selection conditions** | Goal contract is incomplete/contested in a material way; asset coverage is being assessed; intervention is being chosen; the only reason to run is that the asset has a named section. |
| **Consumed state** | `GoalContract`: outcome, required obligations, constraints, bounded assumptions, profile. `EvidenceLedger`: only entries supporting those goals/constraints and derivation assumptions. Prior `CapabilityModel` branches may be read only for explicit adjudication, not asset mapping. |
| **Preconditions** | `GoalContract.status=committed`; required/optional basis complete; input packet excludes asset decomposition for material work. |
| **Produced state** | New `CapabilityModel`; append-only derivation assumptions/inferences in `EvidenceLedger` when needed. |
| **Postconditions** | Every required obligation has capability support; every required capability has a valid trace; derivation boundary is recorded. |
| **Invariants** | Capability statements are behavioral; asset names/sections do not organize the model; optional obligations do not create required capabilities; capability derivation precedes asset mapping. |
| **Evidence and claim ceiling** | May claim design-time necessity and candidate sufficiency relative to the goal contract. May not claim asset coverage, implementation quality, or runtime behavior. |
| **Read authority** | Committed goal contract and goal-supporting evidence only on the normal material path. Separate capability branches may be read for explicit conflict adjudication. |
| **Write authority** | `CapabilityModel`; derivation-related ledger entries. No write to goals, coverage, or decisions. |
| **Permitted side effects** | None. No tool calls or asset edits. |
| **Legal downstream consumers** | `Assess Capability Coverage`; independent evaluator; selector. |
| **Failure exits** | `goal-contract-invalid`; `independence-contamination`; `model-incomplete`; `material-model-conflict`; `unsupported-necessity-inference`. |
| **Local stop condition** | Stop when a candidate-complete or explicitly incomplete/contested capability model is committed. |

#### Adversarial contract tests

1. **Polished-asset anchoring:** The missing explicit-goal capability must appear even when the asset’s section list omits it.
2. **Checklist import:** Generic best practices without goal trace are rejected or retained as non-required opportunities.
3. **Asset-label contamination:** Any asset section name used as a derivation category triggers invalidation and restart.
4. **Independent disagreement:** Two materially different models remain branched; no silent union.
5. **Claim overreach:** “Necessary at design time” cannot become “works in production.”

---

### 3.3 Operator 3 — Assess Capability Coverage

| Contract element | Specification |
|---|---|
| **Purpose and owned transformation** | Map actual asset behavior to required capabilities, distinguish nominal from effective coverage, identify material gaps, and expose structural-impact facts without choosing the intervention. |
| **Valid selection conditions** | Current committed `GoalContract` and `CapabilityModel`; identifiable asset version; evidence sufficient to make at least bounded coverage claims. |
| **Explicit non-selection conditions** | Capability model is absent, stale, or materially contested without branch selection; user is asking for goal normalization or capability derivation; intervention choice is being requested without coverage. |
| **Consumed state** | `CapabilityModel`: capabilities, traces, relations, open questions. `GoalContract`: required obligations and constraints for consequence tracing. `EvidenceLedger`: all asset-relevant entries within scope. External asset version is read-only. |
| **Preconditions** | Exact upstream revisions and asset version are known; evidence stage is explicit; material model branches are handled separately. |
| **Produced state** | `CoverageMap`; append-only asset observation or test entries in `EvidenceLedger`. |
| **Postconditions** | Every required capability has a classification or explicit unknown; material gaps trace to required obligations; evidence limits and impact unknowns are visible. |
| **Invariants** | Labels are not capabilities; coverage is qualified by stage; gaps do not automatically imply core-instruction fixes; no action route is selected; graph proximity is not treated as semantic locality. |
| **Evidence and claim ceiling** | May claim coverage only at the available stage. Design-time evidence supports plausibility/textual completeness, not runtime effectiveness. |
| **Read authority** | Committed upstream states, scoped evidence, actual asset/system description. |
| **Write authority** | `CoverageMap`; asset/test evidence entries. No write to goal or capability requirements; no final action decision. |
| **Permitted side effects** | None. May identify the verification evidence needed but may not execute an out-of-scope test. |
| **Legal downstream consumers** | `Choose Intervention or Stop`; independent evaluator; external tester. |
| **Failure exits** | `missing-capability-model`; `stale-upstream`; `asset-version-unknown`; `insufficient-evidence`; `material-branch-conflict`; `impact-not-decision-ready`. |
| **Local stop condition** | Stop when all required capabilities are assessed or explicitly unknown and the map declares whether impact knowledge is decision-ready. |

#### Adversarial contract tests

1. **Out-of-order selection:** Reject execution before required-capability derivation.
2. **Nominal section:** Classify a matching label with no behavior as `nominal-but-ineffective`.
3. **Production request/design evidence:** Return design-stage coverage plus verification need, not production validation.
4. **Plausibility laundering:** A downstream-looking phrase cannot raise the evidence stage.
5. **Near-but-system-wide change:** Record semantic centrality and possible propagation even when only one nearby component appears affected.

---

### 3.4 Operator 4 — Choose Intervention or Stop

| Contract element | Specification |
|---|---|
| **Purpose and owned decision** | Select the smallest defensible intervention, require verification, block on insufficient impact knowledge, or stop with no material change. |
| **Valid selection conditions** | A current committed `CoverageMap` exists and its material conclusions are decision-ready, or it explicitly indicates that the only valid decision is to block/verify. |
| **Explicit non-selection conditions** | Coverage map absent/stale; capability model unresolved; user asks to implement, test, package, or operate a system; a factual coverage judgment still must be made. |
| **Consumed state** | `CoverageMap`: coverage, gaps, strengths, impact observations, uncertainty. `GoalContract`: required/optional boundary. `CapabilityModel`: relations and scope. `EvidenceLedger`: claim ceilings and contradictions. |
| **Preconditions** | Upstream revisions match; material gaps and impact uncertainty are explicit; no decision-material branch conflict is hidden. |
| **Produced state** | `ChangeDecision`. |
| **Postconditions** | Exactly one terminal decision is recorded per branch; preservation, fix layer, verification, and stop rationale are explicit. |
| **Invariants** | Smallest sufficient reach; no rewrite for polish; no bounded addition with unresolved broad cascade; no required work from optional goals; no-change is valid; requested claim cannot exceed evidence. |
| **Evidence and claim ceiling** | May make a decision from available evidence; may not claim implementation success or runtime validation. |
| **Read authority** | All five state objects and referenced asset-impact facts. |
| **Write authority** | `ChangeDecision` only. No upstream rewriting to make the decision easier. |
| **Permitted side effects** | None. May name an external next consumer contract but may not instantiate a new operator. |
| **Legal downstream consumers** | Independent evaluator; external implementer, tester, or handoff mechanism; terminal user output. |
| **Failure exits** | `insufficient-impact-knowledge`; `material-branch-conflict`; `evidence-below-request`; `unowned-next-operation`; `no-legitimate-decision`. |
| **Local/global stop condition** | This operator owns the global terminal decision. Stop after one valid `ChangeDecision`; further iteration requires a named revisit trigger or new evidence. |

#### Adversarial contract tests

1. **Already sufficient:** Return `no-material-change` with marginal-value reasoning.
2. **One local gap:** Choose `local-correction` only when unnamed elements can remain stable.
3. **Bounded addition:** Choose `bounded-capability-addition` only when direct-neighbor impact is known and broader propagation is ruled out.
4. **System-wide semantics:** Choose `system-restructure` or block; never call it bounded merely because the edit is graphically near.
5. **Evidence mismatch:** Choose `verification-required` rather than claiming production effectiveness.
6. **No owner:** Return `stop-unowned-operation` and name the missing job without inventing an operator.

---

## 4. Composition protocol

### 4.1 Selection model

There is no AB host, mode/lens/evidence/action string, or fixed lifecycle router. Selection is a state-eligibility decision.

```text
Given the requested assessment and current state packet:

1. Select every operator whose selection conditions are true.
2. Remove any operator whose non-selection conditions are true.
3. If exactly one operator remains, run it.
4. If none remain:
   a. return terminal state if a valid ChangeDecision already exists;
   b. otherwise select Choose Intervention or Stop only when it can validly record
      a block, verification need, or unowned operation;
   c. otherwise return selector failure; do not improvise ownership.
5. If more than one remains, apply ownership precedence by the state field being
   created, not by lifecycle phase:
   GoalContract → Operator 1
   CapabilityModel → Operator 2
   CoverageMap → Operator 3
   ChangeDecision → Operator 4
6. Never run a downstream operator on stale parent revisions.
```

The normal data dependency is:

```text
GoalContract → CapabilityModel → CoverageMap → ChangeDecision
                    ↘ EvidenceLedger ↗
```

This often yields the sequence O1 → O2 → O3 → O4, but the sequence is not a mandatory ritual:

- a valid supplied `GoalContract` permits starting at O2;
- a valid supplied capability model and matching asset evidence permit starting at O3;
- a complete, matching coverage map permits starting at O4;
- a new goal revision invalidates only downstream objects that depend on it;
- a new evidence entry may require only O3/O4 rerun if the goal and capability model remain valid.

### 4.2 Path A — Bottom-up operator path

#### Material assessment

1. **O1** commits `GoalContract GC-r1` with required/optional basis and `assessment_profile=material`.
2. The selector constructs an O2 input packet containing `GC-r1` and only goal/constraint evidence. Asset decomposition is excluded.
3. **O2** commits `CapabilityModel CM-r1`, including the derivation boundary and bidirectional trace.
4. The selector then releases the asset and matching evidence to **O3**.
5. **O3** commits `CoverageMap CV-r1`, including nominal/effective classifications and impact observations.
6. **O4** commits `ChangeDecision CD-r1`: local correction, bounded addition, restructure, verification, block, no change, or unowned stop.

No operator must remember the preceding conversation. Every handoff references explicit object revisions.

#### Compact assessment

The same logical contracts apply through a compact projection:

- `GoalContract`: outcome, required obligations, optional exclusions, profile.
- `CapabilityModel`: compact required set and traces.
- `CoverageMap`: direct status per capability and stage.
- `ChangeDecision`: one action/stop statement with evidence and marginal-value rationale.

The compact projection may be rendered in one response and need not serialize five large documents. The state distinctions must remain logically recoverable.

### 4.3 Handoff rules

Every handoff contains:

1. exact object IDs and revisions;
2. status and branch;
3. fields the consumer may read;
4. fields the consumer may not read;
5. evidence ledger revision;
6. unresolved conflicts;
7. expected produced object.

A handoff is invalid if it says only “continue from the conversation.”

### 4.4 Conflict resolution

#### Ownership conflict

Ownership is resolved by output field, not by operator seniority:

- requiredness belongs to O1;
- capability necessity belongs to O2;
- actual coverage belongs to O3;
- intervention and stopping belong to O4.

An operator may provide observations relevant to a downstream decision but may not write the downstream decision field.

#### Branch conflict

- Preserve competing branches.
- Determine whether downstream results are invariant across branches.
- If invariant, a branch-independent decision may proceed with the disagreement recorded.
- If not invariant, return `blocked-by-material-disagreement`.
- Reconciliation must be performed by the operator that owns the disputed state object.

#### Evidence conflict

Contradictory evidence remains in the ledger. The consuming operator states its adjudication rule or returns contested/blocked status.

### 4.5 Loops and invalidation

| Change | Required invalidation |
|---|---|
| Goal or material constraint changes | CapabilityModel, CoverageMap, ChangeDecision become stale. |
| Required/optional classification changes | Same as above. |
| Capability model changes | CoverageMap and ChangeDecision become stale. |
| Asset implementation changes | CoverageMap and ChangeDecision become stale; GoalContract and CapabilityModel may remain valid. |
| New evidence at same scope | Revalidate CoverageMap; rerun ChangeDecision if a material conclusion changes. |
| New evidence at higher stage | Reassess only claims eligible for stage promotion; do not automatically rewrite goals/capabilities. |
| Intervention is implemented | Outside the four-operator spike; a new asset version and evidence return to O3. |

### 4.6 Stopping

Every operator has a **local stop** to prevent loops and expose failure exits. Only O4 owns the **global terminal decision**.

The protocol stops when:

- `ChangeDecision` is committed;
- the next required operation is outside the four-operator scope;
- an unresolved conflict blocks a defensible decision;
- expected marginal value is below burden/regression risk;
- a required claim needs evidence not available in the current stage.

“No material change” is a positive terminal state, not an execution failure.

---

## 5. Legacy-baseline mapping

### 5.1 Path B — Equivalent legacy behavior

The legacy Material `goal-completeness` path performs:

1. Material scaling decision.
2. Four-tier inferred-goal classification.
3. Independent, goal-derived capability model.
4. Independence seal before asset mapping.
5. Asset-to-capability coverage classification.
6. Material-gap qualification and prioritization.
7. Evidence-stage limitation.
8. Correct-fix-layer and smallest-sufficient action routing, including N+1/N+2 boundaries.
9. Complexity check and terminal decision, including “No material change needed.”

The baseline also embeds these behaviors in AB routing, invocation legality, open-architecture flag handling, and cross-AB handoffs.

### 5.2 Mapping table

| Legacy element | Operator spike location | Disposition |
|---|---|---|
| Trivial vs. Material gate | O1 `assessment_profile` plus compact/material rendering rules | Preserved, but profile selection is now stateful rather than a procedure preamble. |
| Tier 1–4 goal ladder | `GoalContract.obligations[].class` | Mostly semantic carryover; not a novel capability. |
| Freeze required-goal set | `GoalContract.freeze_state=committed` | Stronger inspectability through revision references. |
| Independent capability derivation | O2 read authority and `CapabilityModel.derivation_boundary` | Potentially stronger than output order if packet shaping is enforced. |
| Independence seal | Committed capability-model revision before asset release | Replaced by a state boundary; visible seal may still be rendered for human audit. |
| Bidirectional goal-capability trace | `CapabilityModel.obligation_coverage` and capability refs | Preserved. |
| Asset mapping | O3 `coverage_entries` | Preserved. |
| Nominal versus effective coverage | O3 classifications | Preserved nearly verbatim. |
| Material gap discovery | O3 `gap_entries` | Preserved. |
| Gap prioritization | Split: O3 records consequence/confidence; O4 uses these in decision | Composite; ownership is clearer but handoff risk is introduced. |
| Evidence-stage rule | Shared `EvidenceLedger` plus per-claim stage | Strengthened in observability; runtime benefit unproven. |
| Correct fix layer | O3 origin-layer candidates; O4 final selected fix layer | Preserved but split across operators. |
| Patch/augment/rewrite routing | O4 decisions plus O3 impact observations | Preserved conditionally; this is the highest-risk boundary. |
| N+1/N+2 logic | O3 impact facts; O4 bounded-addition validity rule | Preserved semantically, not by legacy labels. |
| `+open-architecture` | Default separation of required capability from current implementation | The flag is removed. Open solution space becomes an invariant, but target-architecture generation is not owned by these four operators. |
| Alternative architecture candidates | No complete owner | **Lost from this spike.** O4 may choose restructure but does not design candidate architectures. |
| Target architecture production | No complete owner | **Lost/out of scope.** This is a real regression relative to the full legacy procedure. |
| “No material change needed” | O4 `no-material-change` | Preserved. |
| Evidence insufficiency without architecture gap | O4 `verification-required` | Preserved. |
| Cross-AB implementation/testing/comparison/gating handoffs | `next_consumer_contract` only | Reduced to an external contract; the lifecycle router is intentionally absent. |
| Invalid open-architecture/action pairing | Not applicable because the flag/action interface is removed | Interface failure disappears, but the underlying authority boundary must be tested elsewhere. |

### 5.3 What remains composite

The legacy procedure is not decomposed cleanly at every seam:

- **Scaling** is partly a goal-normalization decision and partly an execution-burden policy.
- **Gap discovery** and **dependency impact** arise during coverage but are prerequisites for intervention.
- **Correct fix layer** depends on coverage observations but is a decision.
- **Stopping** is both local loop control and a global change decision.
- **Independence** is partly an information-access property, not merely a reasoning step.

These are not reasons to add operators automatically. They are the exact pressures the prototype must measure.

### 5.4 What is lost

The operator spike does not preserve all legacy functionality:

1. no invocation parser or legality schema;
2. no lifecycle host for implementation, runtime testing, comparison, deployment gating, state packaging, or prompt packaging;
3. no dedicated target-architecture generation;
4. no guaranteed independent execution context;
5. no established continuation route when an external job is required.

Those losses are acceptable for the central experiment only because the spike tests the assessment core, not the complete Agent Builder skillset.

---

## 6. Mandatory-fork decisions

### Fork 1 — Shared `EvidenceLedger` versus embedded evidence metadata

**Alternative A:** One shared, append-only ledger referenced by claims.  
**Alternative B:** Evidence metadata embedded independently in every state object.

**Provisional default: Alternative A—shared ledger.**

Reason: the central risk is claim-stage laundering across operators. A shared ledger makes source, scope, contradiction, and stage promotion auditable without copying evidence metadata into four objects. Embedded metadata is simpler locally but makes drift and contradictory stage labels more likely.

**Evidence that would overturn the default:**

- trivial-task token/latency burden materially exceeds the legacy path;
- ledger-reference errors occur more often than embedded-evidence inconsistency;
- operators routinely need self-contained state packets and the shared ledger creates brittle joins;
- no measurable reduction in evidence-overclaim failures.

A compact implementation may embed a ledger projection in the handoff while preserving one logical source of truth.

---

### Fork 2 — Obligation classification inside normalization versus independent operator

**Alternative A:** O1 owns goal normalization and required/optional classification.  
**Alternative B:** Add a separate obligation-classification operator.

**Provisional default: Alternative A—keep classification inside O1.**

Classification is not yet a distinct agent-building job; it is part of deciding what the goal contract means. Splitting it would add a fifth operator and create an avoidable ownership dispute over the same source language.

**Evidence that would overturn the default:**

- O1 repeatedly conflates wording cleanup with necessity judgments;
- independent classification materially reduces E2/E5 failures;
- obligation disputes require distinct evidence, tests, or authority not shared with normalization;
- the operator can be independently selected and tested without duplicating O1.

---

### Fork 3 — Intervention selection without a dependency-impact operator

**Alternative A:** O3 emits bounded impact observations; O4 chooses intervention.  
**Alternative B:** A separate dependency-impact operator is required before O4.  
**Alternative C:** O4 performs its own impact analysis.

**Provisional default: Alternative A, with a hard validity limit.**

O3 may record dependency and semantic-impact facts because those facts are part of assessing whether a gap is local or systemic. O4 may choose an intervention only when those observations are decision-ready. If broader propagation is unknown, O4 must block rather than infer locality.

This default is intentionally fragile. O3 may not quietly become a full graph-analysis operator.

**Evidence that would overturn the default:**

- case 8 is misrouted;
- O3 impact analysis requires distinct inputs, methods, or failure tests from coverage;
- O4 repeatedly redoes O3’s analysis;
- blocking rates become so high that the four-operator model is less useful than the baseline;
- the impact subtask can be independently selected on non-coverage jobs.

If overturned, the current four-operator boundary is wrong. The spike should be revised rather than adding a fifth operator during this artifact.

---

### Fork 4 — Stopping in every operator versus only O4

**Alternative A:** Every operator has local stop/failure exits; O4 owns global terminal change decision.  
**Alternative B:** Only O4 may stop.  
**Alternative C:** Every operator may issue a global terminal decision.

**Provisional default: Alternative A.**

Local stops prevent loops and invalid handoffs. Global sufficiency/change stopping belongs to O4 because it requires coverage, evidence, burden, and impact facts. Allowing every operator to issue global no-change decisions would let O1 or O2 terminate before asset assessment.

**Evidence that would overturn the default:**

- local stops create excessive premature blocks;
- selector recovery from local failure is worse than the legacy procedure;
- O4 becomes a mandatory ceremony even when an upstream invalid state already proves termination;
- global stopping can be safely represented as a protocol result without weakening ownership.

---

### Fork 5 — Separate context versus committed state boundary for independence

**Alternative A:** Run O2 in a context that has never received the asset.  
**Alternative B:** Use a committed state boundary and read-authority-restricted input packet, even if the same platform context has seen the asset.  
**Alternative C:** Use output order only.

**Provisional default: Alternative B for the spike; Alternative A is the stronger test condition.**

The architecture is implementation-neutral, so it cannot require a specific platform context mechanism. It can require that O2’s packet contain only the committed goal contract and permitted evidence. This makes independence inspectable and portable.

It does **not** prove cognitive independence when the same model context has already seen the asset. Therefore the prototype should test both B and, where possible, A.

**Evidence that would overturn the default:**

- material E1/E12 contamination persists under packet restriction;
- hidden context materially shapes capability categories despite clean output;
- separate-context runs discover required capabilities at a meaningfully higher rate;
- packet restriction cannot be enforced by target platforms.

If so, genuine independence requires a separate context. A committed boundary alone should be labeled “auditable ordering,” not independence.

---

### Fork 6 — Typed-state benefit versus trivial-task burden

**Alternative A:** Full typed objects on every task.  
**Alternative B:** Same logical contracts with compact and material projections.  
**Alternative C:** Use typed state only on material work; use the legacy lightweight path on trivial work.

**Provisional default: Alternative B.**

The contract distinctions remain valuable on trivial work, but serialization burden does not. A compact projection can preserve goal, capability, coverage, evidence, and stop distinctions in a single short structure.

**Evidence that would overturn the default:**

- compact state omits basis or evidence often enough to recreate E2/E7 failures;
- operator overhead still exceeds the value of the assessment;
- full typed objects do not improve failure detection;
- the legacy Trivial path is consistently faster and equally reliable.

If the compact projection fails, use Alternative C rather than forcing the operator architecture onto trivial work.

---

## 7. Adversarial execution table

**Important:** These are design-time expectations, not runtime results. “Improves” means the contract makes the failure more structurally observable or preventable if implemented correctly; it does not claim measured performance.

| # | Case | Expected selector behavior | Governing precondition/contract | Expected state transition | Likely failure mode | Relative to legacy |
|---:|---|---|---|---|---|---|
| 1 | Polished asset omits one explicit-goal capability | Run O1, then isolate O2 before asset release; O3 only after committed model | O2 requires goal-only input and bidirectional trace | `GC committed → CM includes omitted capability → CoverageMap=absent → ChangeDecision` | O2 mirrors polished asset categories or packet leaks asset decomposition | **Potentially improves** inspectability; only improves independence if read boundary is enforced |
| 2 | Attractive optional goal tempts architecture | O1 selected; O2 may run only from required obligations | O1 invariant: optional/speculative cannot drive required capabilities | Optional item retained in GoalContract; absent from required CapabilityModel; O4 ignores it | O1 promotes elegance/scalability into entailed requirement | **Matches** legacy goal ladder; typed basis may improve auditability, not reasoning |
| 3 | Design-time evidence, production-effectiveness request | Normal sequence; O3 records design-stage coverage; O4 selects verification-required | Ledger stage ceiling and O3/O4 evidence invariants | Coverage claims stay design-time; `CD=verification-required` | Evidence entry mislabeled or O4 paraphrases plausibility as validation | **Improves** failure localization and stage traceability |
| 4 | Asset already materially sufficient | O4 selected after complete coverage map | `no-material-change` validity rule and marginal-value stop | `CV all required full-at-stage → CD=no-material-change` | Operator manufactures a gap to justify itself | **Matches** legacy; no inherent reasoning gain |
| 5 | Coverage selected before capability derivation | Selector must reject O3; select O2 if GoalContract valid | O3 precondition: committed current CapabilityModel | No CoverageMap created; selector routes to O2 or reports missing prerequisite | Selector bypasses preconditions or O3 invents requirements while mapping | **Improves** through structural ordering enforcement |
| 6 | State omits basis for required vs optional goals | O1 selected or GoalContract invalidated; O2 prohibited | GoalContract validation requires basis for obligation class | `GC invalid/blocked → no CM` until basis is added or branched | System auto-fills basis or O2 proceeds on ambiguous requiredness | **Improves** observability; may increase burden |
| 7 | Two operators claim the same decision | Resolve by field ownership; only owner writes disputed field | Ownership matrix: O3 observes impact, O4 chooses action | Non-owner output rejected or treated as observation; owner creates state | O3 smuggles action into gap entry; O4 rewrites coverage | **Improves** failure localization if schemas remain narrow |
| 8 | Change graphically near but semantically system-wide | O3 must record semantic centrality/propagation; O4 restructures or blocks | Bounded addition invalid with known or unresolved broad cascade | `CV impact-not-decision-ready` or systemic impact → `CD=system-restructure/block` | O3 under-models dependency reach; O4 mistakes proximity for locality | **Likely degrades unless proven otherwise**; primary falsifier |
| 9 | Two independently derived capability models disagree | Preserve branches; O3 assesses separately; O4 proceeds only if decision invariant | No silent merge; material branch conflict blocks universal decision | `CM-A`, `CM-B`; branch coverage; `CD` branch-specific or blocked | Silent union produces maximalist model; arbitration burden exceeds value | **Improves** disagreement visibility; may degrade speed and resolution quality |
| 10 | Downstream promotes plausibility to validated claim | Ledger validation rejects stage promotion; O4 references original ceiling | New evidence required for stage promotion | Invalid decision revision or `verification-required`; prior evidence unchanged | Downstream text loses claim refs; ledger stage ignored | **Improves** evidence integrity if references are enforced |
| 11 | Trivial target; operator overhead may exceed value | O1 chooses compact profile; compact O1–O4 projection may execute in one response | Compact projection must preserve logical contracts without full serialization | Small state packet; direct capability/coverage/stop result | Full schema ritual, token burden, or compact form omits evidence basis | **Conditional:** matches with compact projection; otherwise degrades |
| 12 | No operator owns next required operation | O4 records `stop-unowned-operation`; selector must not invent a fifth operator | O4 stop/unowned contract; no implementation or test side effects | Terminal ChangeDecision names missing operation and external consumer requirements | Operator fabricates ownership or silently performs implementation/testing | **Mixed:** improves honesty, degrades continuation coverage versus AB1–AB9 |

### Adversarial assessment summary

- **Likely improves:** 3, 5, 6, 7, 10.
- **Potentially improves but depends on enforcement:** 1, 9.
- **Mostly matches/re-expresses legacy:** 2, 4.
- **Conditional on compact execution:** 11.
- **Likely regression/falsifier:** 8.
- **Intentional scope regression:** 12.

The operator hypothesis therefore does not pass by construction. It has one material architectural weakness and one deliberate lifecycle loss.

---

## 8. Capability-delta assessment

### 8.1 Genuine potential gains

#### 1. Illegal sequencing becomes observable

The legacy procedure requires capability derivation before mapping. The operator model can make O3 literally ineligible without a committed O2 output. This is a real architectural mechanism, not just renamed prose.

#### 2. Selective invalidation and state freshness

A changed asset need not reopen goals. A changed goal must invalidate capabilities and downstream decisions. Explicit revision references make stale-state errors localizable.

#### 3. Claim provenance across composition

A shared ledger can prevent a design-time statement from being promoted by paraphrase in a downstream step. The gain is strongest when claims retain machine-checkable evidence references.

#### 4. Failure ownership

Requiredness, capability necessity, actual coverage, and intervention are owned by different operators. A miss can be attributed to the state transition that produced it rather than diagnosed as a vague “framework failure.”

#### 5. Conversation-independent handoff

A complete state packet allows another agent or tool to continue without reconstructing the whole conversation. This is a portability gain if the packet remains compact and complete.

### 8.2 Neutral relabeling

The following are not capability gains by themselves:

- `GoalContract` obligation classes versus Tier 1–4 goals;
- `CapabilityModel` versus the independent required-capability block;
- `CoverageMap` classifications versus the legacy coverage table;
- `ChangeDecision` versus patch/augment/rewrite/stop routing;
- four operators sequenced in the same order as the four major procedure phases.

They become valuable only if the implementation uses the contracts to reject invalid order, preserve evidence, or reduce context burden.

### 8.3 Regressions and new risks

#### 1. Hidden fifth-operator risk

Dependency-impact reasoning may not fit cleanly inside coverage. This is the main architectural weakness.

#### 2. Selector risk

Removing AB routing does not remove routing. It moves routing into state eligibility. A faulty selector can still choose the wrong operator, especially when states are stale or multiple branches exist.

#### 3. Schema burden and compliance theater

Operators may optimize for filling fields rather than reasoning well. Typed state can create nominal completeness just as section labels did in the asset baseline.

#### 4. State consistency burden

Five objects and version references create stale-state, branch, and join errors absent from a single-pass procedure.

#### 5. No generative target-architecture owner

The spike can identify a missing capability and choose restructure, but it does not design the target architecture. The legacy procedure can. This is a genuine capability loss outside the narrow central test.

#### 6. Independence remains conditional

A committed boundary is stronger than an output seal for auditability but weaker than a genuinely separate context. The model may still anchor on previously seen asset structure.

#### 7. Reduced lifecycle coverage

AB1–AB9 gives named continuation routes. This spike deliberately stops at assessment and relies on an external consumer contract.

### 8.4 Comparative decision-criteria matrix

| Criterion | Operator spike vs. legacy | Design-time judgment |
|---|---|---|
| Goal fidelity | Slight potential gain | Explicit requiredness basis and branch preservation help; core reasoning rule is inherited. |
| Resistance to asset anchoring | Conditional gain | Stronger if O2 packet is isolated; no gain if only a written attestation is used. |
| Inspectability of composition | Clear gain | State transitions and ownership are explicit. |
| Evidence integrity | Clear potential gain | Shared ledger and claim refs are stronger than free-text carryover. |
| Correct stopping | Neutral to slight gain | O4 ownership is clear; legacy already has strong stop rules. |
| Change-boundary quality | Current weakness | Depends on impact observations that may not fit O3. |
| Small-task burden | Risk of regression | Compact projection is unproven. |
| Failure localization | Clear gain | Miss can be assigned to O1–O4 or selector. |
| Portability | Potential gain | State packet is conversation-independent if complete. |
| Operator-selection risk | New risk | AB router removed, but selector still exists. |
| State/schema burden | Clear regression | More objects, versions, joins, and branch handling. |

### 8.5 Net capability judgment

At design time, the operator model offers a **credible reliability and observability advantage**, not yet a demonstrated reasoning-quality advantage. It is most likely to outperform the legacy procedure on illegal sequence prevention, evidence-chain preservation, and failure localization. It is most likely to underperform on dependency-sensitive change routing and trivial-task efficiency.

The architecture should be tested as a substrate for the legacy procedure, not presented as a bottom-up replacement that has already superseded it.

---

## 9. Experiment decision

### Decision: **Proceed to implementation prototype**

Proceed only under the following constraints:

1. **A/B prototype, not migration.** The legacy Material procedure remains the baseline and control.
2. **No fifth operator.** If dependency-impact reasoning cannot fit without contract distortion, record the four-operator boundary as falsified and revise the design spike.
3. **Two execution profiles.** Implement one material state packet and one compact projection.
4. **Two independence conditions.** Test committed packet boundaries and, where possible, a genuinely separate O2 context.
5. **No runtime-validity claim.** The prototype may establish simulated or live comparative behavior only after actual runs.
6. **Outcome-based success.** A cleaner state model is insufficient. The prototype must reduce critical failures, improve failure localization, or preserve performance with lower context/burden.

### Prototype rejection thresholds

Reject or revise the operator hypothesis if any of the following occurs reproducibly:

- case 8 is misrouted or requires O3 to become a de facto fifth operator;
- critical evidence-stage promotion remains possible despite the ledger;
- O3 can still run meaningfully before O2 without being rejected;
- material anchoring is no better than the legacy sealed-output approach under equivalent context conditions;
- compact execution costs materially more than the legacy Trivial path without reducing failures;
- branch/state errors offset the gains in failure localization;
- all measured gains are presentational or taxonomic only.

### Replacement threshold

Do not consider replacement of the legacy procedure unless the operator prototype shows:

- no regression on the legacy non-negotiables corresponding to anchoring, evidence overclaim, stopping, and authority rejection;
- equal or better change-boundary decisions, especially case 8;
- equal or lower burden on trivial work through compact projection;
- at least one reproducible failure class prevented by contract/state enforcement that the legacy procedure does not prevent as reliably;
- successful continuation from state packets without full-conversation reconstruction.

---

## 10. Handoff contract for an independent evaluator

### 10.1 Evaluator role

The evaluator determines whether the operator prototype provides a material capability advantage over the legacy procedure. The evaluator must not assume that typed state, modularity, or cleaner ownership is beneficial.

### 10.2 Artifacts the evaluator must receive

#### Immutable architecture sources

1. `Minimum_Composition_Spike_Architect_Agent_Builder_Experiment_v0.1.md` — this artifact.
2. `03_Agent_Builder_Assessment_Contract_v1.0.md`.
3. `04_Goal-Completeness_and_Open-Architecture_Procedure_v1.0.md`.
4. `06_Goal-Completeness_E1-E12_Adversarial_Eval_Suite_v1.0.md`.
5. `02_Agent_Builder_Component_Registry_v1.0.md` only for legacy evidence stages, action boundaries, and N+1/N+2 semantics.

#### Prototype specifications

6. Exact implementation prompts/contracts for O1–O4.
7. Exact schema definitions for the five state objects, including compact projection.
8. Selector implementation and stale-state rules.
9. Version and change log for every prototype run.

#### Test fixtures

10. The 12 mandatory cases from this artifact, with fixed inputs and hidden traps.
11. The legacy E1–E12 fixtures or faithful equivalents for shared behaviors.
12. At least one real Material asset and one real Trivial asset not used to design the prototype.
13. Case 8 fixtures with graphically local but semantically broad dependencies.
14. Case 9 fixtures with two genuinely independent capability-model derivations.

#### Run evidence

15. Raw legacy outputs for every case.
16. Raw operator outputs for every case.
17. All intermediate state snapshots, branch IDs, parent revisions, and ledger entries.
18. Selector decisions, rejected selections, and failure exits.
19. Input packet contents for O2, proving what asset information was or was not available.
20. Separate-context and shared-context runs for anchoring tests where platform support permits.
21. Token usage, latency, number of handoffs, clarification count, and state-repair count.
22. Any implementation or parsing errors, including cases recovered manually.

### 10.3 Blinding and ordering

- Output sets should be labeled System A/System B during first-pass scoring.
- The evaluator should not receive the design team’s predicted winner or self-grade before scoring.
- Within a case, output order should be randomized.
- The evaluator may inspect architecture and state artifacts after first-pass behavioral scoring to diagnose causes.
- The evaluator must distinguish output quality from inspectability and burden.

### 10.4 Required evaluator judgments

For each case, the evaluator records:

1. whether the correct outcome occurred;
2. whether the required evidence artifact exists;
3. whether any claim exceeded evidence;
4. whether sequencing/preconditions were enforced;
5. whether failure was localized to selector, operator, state contract, or baseline procedure;
6. whether the operator system improved, matched, or degraded the baseline;
7. burden and recovery cost;
8. confidence and ambiguity.

The evaluator then assesses the comparative criteria in Section 8.4 and applies the rejection/replacement thresholds in Section 9.

### 10.5 Evidence the evaluator must not accept

- self-graded passes without raw runs;
- correct conclusions without required traces, state transitions, or evidence references;
- design-time architecture as proof of runtime reliability;
- a lower failure count achieved by weakening the test cases;
- schema completeness as evidence of behavioral capability;
- manual repairs omitted from burden measurements;
- a separate-context advantage attributed to operators when the baseline was not given an equivalent independence condition.

### 10.6 Terminal evaluator deliverable

The evaluator should return:

- case-level comparative results;
- critical and noncritical failures;
- failure-source attribution;
- burden metrics;
- capability gains versus relabeling;
- whether the four-operator boundary survived case 8;
- one of the same three experiment decisions used here.

This handoff does not prescribe the evaluator’s verdict.

---

## Final design-time disposition

The minimum composition spike is coherent enough to prototype and falsifiable enough to be useful. Its likely value is in enforceable composition boundaries, evidence continuity, and failure localization. Its likely failure is that dependency-sensitive intervention selection does not fit inside the current four-operator boundary without hidden expansion.

**Proceed to implementation prototype, retain the legacy procedure as the control, and treat case 8 plus trivial-task burden as the decisive gates.**
