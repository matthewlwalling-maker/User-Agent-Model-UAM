# Agent Builder Prompt Macro Compatibility

This repository contains seven operational Codex Skills and one non-implicit Prompt Macro recovery utility.

When a user request begins with `AB1.` through `AB9.`:

1. Treat it as an explicit Agent Builder Prompt Macro, not ordinary prose.
2. Locate the repository root containing this file, then run:
   `python <repo-root>/.agents/skills/_shared/scripts/validate_pm_invocation.py --json "<exact invocation>"`
3. If validation fails, stop. Name the validator rule and provide only the smallest legal correction. Do not silently drop a flag, alter an action, or invent an evidence stage.
4. If validation succeeds, read the mapped Skill's `SKILL.md` using `skill_path` from the validator output.
5. Execute exactly that Skill using the normalized mode, lens, scope, evidence stage, action, and flag.
6. The router owns no substantive project state and may not broaden the authorized action.
7. Do not automatically execute downstream handoffs. Return the next recommended Prompt Macro or Skill invocation for separate authorization.

Natural-language requests and explicit `$skill-name` invocations remain valid. The Prompt Macro layer is a compatibility interface, not a competing reasoning system.
