---
name: adversarial-evaluation
description: Design or run adversarial, regression, verification, or blind evaluations for prompts, skills, workflows, and agent systems. Use for failure-seeking test suites, behavioral verification, and evidence capture. Do not use to redefine goals, silently fix the target, or claim live-runtime evidence from simulation.
---

# Adversarial Evaluation

## Authority and references

Read:

- `../_shared/references/common-governance-contract.md`
- `../_shared/references/canonical/06_Goal-Completeness_E1-E12_Adversarial_Eval_Suite_v1.0.md`
- `../_shared/references/canonical/03_Agent_Builder_Assessment_Contract_v1.0.md`

For controlled comparative runs, consult `../../../future/experimental-operator-prototype/P6_AB_Run_and_Evidence_Capture_Protocol_v0.1.md` without granting the experimental architecture deployment authority.

## Inputs

Require or mark unavailable: target revision, frozen goal/capability basis, evaluation purpose, evidence stage, fixtures, test commands, thresholds, and evaluator independence condition.

## Procedure

1. Freeze the target, sources, fixtures, commands, environment, and evidence stage.
2. Design failure-seeking cases with a hidden trap, required behavior, prohibited behavior, observable evidence, and explicit scoring rule.
3. Avoid tests that pass by construction.
4. Run the target without modifying it during the frozen series.
5. Preserve exact prompts, raw outputs, commands, errors, retries, and manual interventions.
6. A retry receives a new attempt ID; never overwrite the first failure.
7. Score behavior against the frozen basis. Do not count formatting-only variance unless formatting is itself required behavior.
8. If the same context designed, ran, and scored the test, do not call the result blind or independent.
9. Separate failure observation from root-cause diagnosis. Route diagnosis to `failure-triage`.
10. Label the conclusion at the actual evidence stage.

## Output

- run metadata and frozen basis;
- case-by-case pass/fail with evidence;
- aggregate threshold result;
- observed failure classes without speculative root-cause overreach;
- evidence limitations;
- recommended next operation.

Use `../_shared/assets/evaluation-record-template.md`. Use the shared `freeze_sources.py` and `capture_eval_run.py` when executing repository-local runs.

## Boundaries

- Do not redefine Tier 1–2 goals while testing.
- Do not repair the target inside the same frozen run series.
- Do not describe simulated evidence as live-runtime or production-observed.
