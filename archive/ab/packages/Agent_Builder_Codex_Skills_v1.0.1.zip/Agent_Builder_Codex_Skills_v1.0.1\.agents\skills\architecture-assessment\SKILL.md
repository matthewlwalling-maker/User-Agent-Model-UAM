---
name: architecture-assessment
description: Assess whether a prompt, agent, workflow, schema, resource bundle, or system is complete and correctly structured for its actual goals. Use for architecture reviews, goal-completeness, missing-capability analysis, boundary/resource placement, or open-architecture recommendations. Do not use to modify files or run behavioral tests.
---

# Architecture Assessment

## Authority and references

Before material work, read:

- `../_shared/references/common-governance-contract.md`
- `../_shared/references/source-authority.md`
- `../_shared/references/canonical/03_Agent_Builder_Assessment_Contract_v1.0.md`
- `../_shared/references/canonical/04_Goal-Completeness_and_Open-Architecture_Procedure_v1.0.md`
- `../_shared/references/canonical/02_Agent_Builder_Component_Registry_v1.0.md`

For adversarial self-checks, consult `../_shared/references/canonical/06_Goal-Completeness_E1-E12_Adversarial_Eval_Suite_v1.0.md`.

## Inputs

Recover or mark unavailable: target asset, objective, lifecycle stage, material constraints, evidence stage, authorized action, and whether open architecture is authorized.

When entered through a Prompt Macro, treat its normalized fields as authoritative. For direct natural-language invocation, infer a bounded design-time assessment unless the user supplies a different evidence stage or action.

## Procedure

1. Select the Trivial or Material path from coupling, omission risk, dependencies, state, tools, governance, and consequence—not from polish or raw section count.
2. Separate explicit requirements, necessarily entailed requirements, optional opportunities, and speculative possibilities.
3. Derive the required behavioral capability model from only explicit and entailed requirements.
4. On the Material path, emit and seal the complete capability model before naming or discussing existing asset components.
5. Map actual asset behavior to each required capability. A heading or named section is not proof of behavior.
6. Classify coverage as full-at-stage, partial, nominal-but-ineffective, absent, duplicated, misplaced, or unknown-insufficient-evidence.
7. Identify strengths to preserve and only material gaps.
8. Locate each gap at the originating layer and estimate structural reach.
9. Route to assess-only, recommend, patch, augment, rewrite, implement, retest, package, or gate without exceeding the authorized action.
10. Apply the complexity and stop check. `No material change needed` is valid.

## Output

Preserve these functions; exact formatting may vary:

- scaling path and basis;
- goal model;
- independent required capability model;
- coverage assessment;
- material gap or sufficiency decision;
- strengths to preserve;
- correct fix layer and structural reach;
- authorized recommendation or target architecture;
- evidence limitation and verification owed;
- stop decision.

Use `../_shared/assets/assessment-output-template.md` when a durable artifact is requested.

## Boundaries

- Do not modify the target unless the authorized action explicitly permits implementation and the request clearly identifies the target. Normally hand implementation to `artifact-change`.
- `+open-architecture` expands the solution space only with recommend, augment, rewrite, or implement. It does not authorize speculative requirements.
- Do not claim runtime effectiveness from design-time evidence.
- Do not require experimental O1–O4 typed state in v1.
