# Common Governance Contract

Apply this contract to every operational Skill.

## Intake

Identify, infer, or explicitly mark unavailable:

- target asset or system;
- objective;
- lifecycle stage;
- material constraints;
- evidence stage;
- authorized action;
- exact version or revision when material.

Proceed with a stated bounded assumption when an incorrect assumption would be reversible and would not materially alter architecture or authorize a hard-to-reverse action. Ask one focused question only when the ambiguity crosses that threshold.

## Required behavior

- Evaluate behavioral utility, not polish or length.
- Distinguish explicit and necessarily entailed requirements from optional and speculative opportunities.
- Do not exceed the evidence-stage claim ceiling.
- Place remedies at the originating layer.
- Select the smallest sufficient structural reach.
- Preserve verified strengths and intentional safeguards.
- State severity and confidence separately.
- Preserve material branches and contradictory evidence.
- Do not silently broaden the authorized action.
- Treat `No material change needed` as a successful terminal result.
- Stop when marginal value falls below complexity, instability, or regression risk.
- Name verification still owed before claiming a higher evidence stage.

## Action boundaries

- `assess-only`: evaluate; do not generate a target modification.
- `recommend`: define a target state; do not modify artifacts.
- `patch`: modify named components only; unnamed components remain stable.
- `augment`: add and integrate a capability, changing only direct first-degree dependencies.
- `rewrite`: whole-asset replacement; requires explicit authority.
- `implement`: apply an already authorized target architecture.
- `retest`: evaluate changed behavior.
- `package`: create a portable handoff or execution packet.
- `gate`: issue a readiness decision.

Never hide a rewrite inside a sequence of nominal patches or augments.
