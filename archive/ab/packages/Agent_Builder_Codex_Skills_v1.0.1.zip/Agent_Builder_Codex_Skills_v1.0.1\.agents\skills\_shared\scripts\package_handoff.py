#!/usr/bin/env python3
"""Validate a compact handoff JSON and render Markdown without changing state."""
from __future__ import annotations
import argparse, json
from pathlib import Path

REQUIRED = [
    'objective', 'required_obligations', 'constraints', 'asset_ref',
    'capabilities', 'coverage_decision', 'evidence_stage', 'claim_limits',
    'authorized_next_action', 'prohibited_action_reach', 'unresolved_risks',
    'verification_owed', 'next_consumer', 'terminal_or_revisit_condition',
]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('input_json')
    ap.add_argument('-o', '--output', required=True)
    args = ap.parse_args()
    data = json.loads(Path(args.input_json).read_text(encoding='utf-8'))
    missing = [k for k in REQUIRED if k not in data]
    if missing:
        raise SystemExit('Missing required handoff fields: ' + ', '.join(missing))
    lines = ['# Execution-Ready Handoff', '']
    labels = [
        ('objective','Committed objective'),
        ('required_obligations','Required obligations'),
        ('constraints','Material constraints'),
        ('asset_ref','Asset and revision'),
        ('capabilities','Required capabilities'),
        ('coverage_decision','Coverage/gap/sufficiency decision'),
        ('evidence_stage','Evidence stage'),
        ('claim_limits','Claim limits'),
        ('authorized_next_action','Authorized next action'),
        ('prohibited_action_reach','Prohibited action reach'),
        ('unresolved_risks','Unresolved risks and branches'),
        ('verification_owed','Verification owed'),
        ('next_consumer','Next consumer'),
        ('terminal_or_revisit_condition','Terminal or revisit condition'),
    ]
    for key, label in labels:
        value = data[key]
        lines += [f'## {label}', '', '```json', json.dumps(value, indent=2, ensure_ascii=False), '```', '']
    Path(args.output).write_text('\n'.join(lines), encoding='utf-8')
    print(args.output)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
