# 07 — Agent Builder PM Framework: Deployment Quickstart

**Version:** 1.0.1 · **Status:** Active · **Authority:** operator usage (Manifest §3)

A short operator guide. Authority for any rule lives in the referenced artifact; this file shows how to use them.

---

## 1. Attach and order resources

Attach all nine artifacts to the agent host in numeric order. Order encodes authority (Manifest §3):

```
00 manifest → 01 router → 02 registry → 03 contract → 04 procedure
→ 05 AB registry → 06 eval → 07 quickstart → 08 validation
```

If the host supports a single "instructions" field plus reference documents, place **01 (router)** as the thin core/persona-adjacent instruction and attach **02–06** as reference documents. Do **not** paste the registry, procedure, or eval into the core field — that re-bloats core and is exactly what the layer-placement rule forbids (Manifest §5).

## 2. Minimal core setup

The agent needs only: recognize `AB[1-9].`, parse by anchored vocabularies, resolve defaults, validate against `02`, dispatch to `05`, obey `03`. Everything else is looked up, not memorized.

## 3. Invoking PMs

**Full string:**
```
AB{n}.{mode}[.{lens}].{scope phrase}.{evidence}.{action}[ +open-architecture]
```
**Shorthand / button:** omit any of mode, lens, evidence, action; defaults fill them in (`01` §4):
```
AB4.is this complete for my goal     →  AB4.holistic.architecture.is this complete for my goal.design-time.assess-only
```
The scope phrase is plain English — spaces and periods inside it are fine.

## 4. Default-resolution examples

| You type | Resolves to |
|---|---|
| `AB4.assess this architecture` | `AB4.holistic.architecture.assess this architecture.design-time.assess-only` |
| `AB2.adversarial.test the router` | `AB2.adversarial.behavior.test the router.design-time.assess-only`* |

*Omitted actions always default to `.assess-only` under `01` §4. To actually execute tests, set both the evidence stage and action explicitly, for example: `AB2.adversarial.test the router.simulated.retest`.

## 5. Valid vs invalid invocations

| Invocation | Verdict |
|---|---|
| `AB4.goal-completeness.is my eval harness complete.design-time.recommend` | ✅ valid |
| `AB4.goal-completeness.what are we missing.design-time.recommend +open-architecture` | ✅ valid |
| `AB4.goal-completeness.show me the ideal.design-time.assess-only +open-architecture` | ❌ rejected — orphan ideal (`02` V7) |
| `AB10.holistic.x.design-time.assess-only` | ❌ rejected — no AB10 (`02` V1) |
| `AB4.goal-completeness.add pieces.augment` | ❌ rejected — missing evidence stage (`02` V4) |

## 6. One Trivial and one Material `.goal-completeness`

**Trivial** (low coupling, local question):
```
AB4.goal-completeness.is this 3-field output contract complete.design-time.recommend
→ Scaling gate: Trivial. Compact goal+capability set → direct mapping → verdict → action. No sealed block.
```
**Material** (multi-stage system, anchoring risk):
```
AB4.goal-completeness.is my multi-agent FP&A architecture complete for safe writeback.design-time.recommend +open-architecture
→ Scaling gate: Material. Goal Model → sealed independent capability model → seal → asset mapping → gap register → target architecture → evidence/stop. Headline verdict appears AFTER the seal (the only output-order exception).
```

## 7. Cross-PM workflow examples

**Build → test → diagnose → fix → compare → gate:**
```
AB4.goal-completeness.what's missing.design-time.augment +open-architecture   # produce gap register + target
AB1.targeted.integrate the gap.post-implementation.augment                    # implement within N+1
AB2.adversarial.the new architecture.simulated.retest                          # test
AB6.targeted.any failed eval.live-runtime.recommend                            # diagnose + place fix
AB3.delta.original vs augmented.post-implementation.recommend                  # compare
AB5.holistic.deployment readiness.post-implementation.gate                     # gate
AB8.holistic.carry state forward.design-time.package                           # preserve state
```

## 8. When to use each evidence stage

| Stage | Use when you have |
|---|---|
| `.design-time` | only the text/architecture — plausibility, not behavior |
| `.simulated` | results from controlled test prompts/fixtures |
| `.live-runtime` | observed execution in the real environment |
| `.post-implementation` | verification right after a specific change |
| `.production-observed` | repeated real-world behavior over time |

Never label a conclusion above the evidence you actually have (`03` §4).

## 9. How to run E1–E12

```
AB2.adversarial.goal-completeness procedure and routing.simulated.retest
```
Pre-deployment this is `.simulated` (or design-time spec-conformance). Use `.live-runtime` once an agent is actually running the suite. Score per `06`: ≥10/12, zero failures on E1/E7/E8/E11. Classify misses with the `06` rubric; route diagnosis to AB6, calibration to AB7, comparison to AB3.

## 10. Interpreting "No material change needed"

It is a **success**, not a non-answer. It means every Tier 1–2 goal has adequate support at the assessed evidence stage and remaining items are below the action threshold. Optional Tier 3–4 enhancements may be listed — they are options, not defects. Do not push the agent to manufacture a gap (that is the E8 failure).
