# Implementation Decisions and Source Errata

**Version:** 1.0.1  
**Purpose:** Record source discrepancies and package-level resolutions with patch closure status.

## E001 — AB2 shorthand action default

### Conflict

- `01_Agent_Builder_Core_Router_v1.0.md` §4 states that every omitted action defaults to `.assess-only`.
- `07_Agent_Builder_Deployment_Quickstart_v1.0.md` §4 shows `AB2.adversarial.test the router` resolving to `.retest`.

### Authority resolution

The Deployment Manifest assigns default resolution to `01` (Core Router), while `07` is operator usage guidance. The package therefore resolves the omitted action to `.assess-only`.

### Operational consequence

To authorize execution of tests, use an explicit evidence stage and `.retest`, for example:

```text
AB2.adversarial.test the router.simulated.retest
```

### Status

Closed in patch `v1.0.1`. The canonical Quickstart now resolves `AB2.adversarial.test the router` to `AB2.adversarial.behavior.test the router.design-time.assess-only`. No AB2-specific `.retest` default was introduced; actual test execution still requires an explicit evidence stage and `.retest`.

## E002 — Runtime status ceiling

The canonical framework is Yellow at design-time/simulated evidence. The generated Skills inherit no higher readiness claim. Runtime installation, trigger behavior, and E1–E12 performance remain to be observed.
