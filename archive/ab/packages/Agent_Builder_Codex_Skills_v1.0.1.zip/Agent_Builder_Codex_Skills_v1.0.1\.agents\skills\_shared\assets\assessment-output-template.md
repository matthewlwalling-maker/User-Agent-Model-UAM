# Assessment Output Template

- Evidence stage:
- Authorized action:
- Scaling path:
- Bounded assumptions:

## Goal basis

## Required capability model

## Coverage and material findings

## Gap or sufficiency decision

## Correct fix layer and structural reach

## Verification owed

## Stop decision
