# P1 — Prototype Authority and Scope

**Package:** Minimum Composition Comparative Prototype  
**Version:** 0.1  
**Status:** Design-time runnable specification; no comparative runs completed  
**Provisional build disposition:** `READY FOR COMPARATIVE EXECUTION` subject to P7 construction checks  
**Replacement status:** Not authorized

## 1. Purpose

This package is the smallest platform-neutral prototype specification that makes four contract-bearing operators executable from explicit packets, makes five state objects machine-checkable, exposes illegal sequencing and stale state, preserves evidence ceilings, and permits an A/B comparison against the unchanged legacy Goal-Completeness procedure.

It tests a hypothesis. It does not authorize migration, replacement, implementation, deployment, or a claim that the operator architecture is superior.

## 2. Governing authority

The source set is frozen for a run by exact filename and SHA-256 digest. A changed digest creates a new experiment version.

| Precedence | Source | SHA-256 | Owned domain |
|---:|---|---|---|
| 1 | `Minimum_Composition_Spike_Architect_Agent_Builder_Experiment_v0.1.md` | `e09c6b4b748e690d6162fa8a799a0042decc84065078520300a12f7c559dfa61` | Experimental architecture, state boundaries, forks, cases, falsifiers, thresholds |
| 2 | `03_Agent_Builder_Assessment_Contract_v1.0.md` | `f409a4b242059e71cc2fa906da97da0de15e2137d56b5c2af2a56bb446a9a2f5` | Unchanged legacy cross-assessment contract |
| 3 | `04_Goal-Completeness_and_Open-Architecture_Procedure_v1.0.md` | `23695a1d6635303a4cd7bc92a5510d2106a010a25bf6c449b128a46218058858` | Unchanged legacy Material and Trivial control procedure |
| 4 | `06_Goal-Completeness_E1-E12_Adversarial_Eval_Suite_v1.0.md` | `dfed134a7a602ca3342da2b63667282e318a52dcaf5275d6a9a31f0cf2519e0f` | Inherited adversarial behaviors and failure classes |
| 5 | `02_Agent_Builder_Component_Registry_v1.0.md` | `d927d4e0034ca27f4685b9a7a4c0d73c9bcb0c6f0c32b7c3afa392cc7cd26b23` | Legacy evidence stages, fix layers, action boundaries, N+1/N+2 only |

The handoff packet is operational guidance only and does not override these sources.

Conflict resolution:

1. The spike controls the experimental architecture and falsifiers.
2. The Assessment Contract and Procedure control the legacy baseline and remain unchanged.
3. E1–E12 controls inherited adversarial scoring behaviors.
4. The Component Registry is consulted only for the legacy evidence vocabulary, correct-fix-layer semantics, and patch/augment/rewrite plus N+1/N+2 boundaries.
5. No AB1–AB9 route or six-position invocation schema governs the operator path.

## 3. Artifact inventory and authority

| Artifact | Authority |
|---|---|
| P1 | Package scope, source freeze, vocabulary, change control, exclusions |
| P2 | Five state schemas, metadata convention, projections, structural validation, error codes |
| P3 | O1–O4 execution contracts and packet contents |
| P4 | Deterministic eligibility, transition, invalidation, branch, rejection, and stop protocol |
| P5 | Fixed comparative fixtures, hidden traps, expected observables, objective scoring conditions |
| P6 | A/B execution, capture, randomization, burden metrics, attribution, blinded handoff |
| P7 | Cross-artifact construction audit and exactly one build disposition |

A later artifact may reference an earlier owner but may not redefine its domain. Fix contradictions at the narrowest owning artifact.

## 4. Fixed architecture

### State objects

1. `GoalContract`
2. `CapabilityModel`
3. `EvidenceLedger`
4. `CoverageMap`
5. `ChangeDecision`

### Operators

1. `O1 Normalize Goal and Obligations`
2. `O2 Derive Required Capabilities`
3. `O3 Assess Capability Coverage`
4. `O4 Choose Intervention or Stop`

The common metadata envelope is embedded by schema composition in every state object. It is not instantiable as a state object and therefore is not a sixth object. Transfer packets, logs, and fixture records are protocol records, not architectural state objects.

## 5. Experiment and run vocabulary

### Evidence stages

| Stage | Maximum supported claim |
|---|---|
| `design-time` | Textual completeness and architectural plausibility |
| `simulated` | Behavior observed under controlled prompts or fixtures |
| `live-runtime` | Execution observed in an active environment |
| `post-implementation` | Verification after a specific implemented change |
| `production-observed` | Repeated real-world behavior in production |

A stage promotion requires a new scoped ledger entry. Rewording, handoff, summarization, or model agreement does not promote evidence.

### Independence conditions

| Condition | Definition | Permitted claim |
|---|---|---|
| `packet-boundary` | O2 receives only a committed goal-and-constraint packet, but the broader model context may previously have seen the asset. | Auditable packet restriction; **not** full cognitive independence |
| `separate-context` | O2 executes in a fresh context that has never received the asset. | Stronger context isolation, still not proof of absence of pretrained priors |

The legacy control receives equivalent conditions under P6.

### Execution profiles

- `material`: full state representations and explicit handoffs.
- `compact`: all five logical distinctions remain recoverable, but fields may be serialized together and optional detail omitted.

### Run labels

- `System A` / `System B`: randomized blinded labels. They do not permanently identify the operator or legacy system.
- `first-pass`: no repair or manual correction.
- `recovered`: a later run after logged repair; never replaces the first-pass record.

## 6. Dependency-impact boundary

O3 owns coverage and coverage-linked impact observation. It may use only:

- explicit asset behavior;
- supplied dependency/interface facts;
- bounded first-degree interface tracing directly available in the assessed asset packet; and
- evidence already in the ledger.

O3 may record touched elements, first-degree neighbors, known second-degree-or-broader propagation, semantic centrality, preservation feasibility, and material unknowns. O3 may not collect new external dependency evidence, perform undocumented whole-system discovery, simulate causal propagation, select an intervention, or decide target architecture.

Impact analysis becomes a materially separate job when a defensible reach classification requires any of the following:

1. new source collection beyond the packet;
2. graph traversal across undocumented or unavailable dependencies;
3. platform/runtime inspection not already supplied as evidence;
4. causal simulation or implementation design; or
5. adjudication of ownership/governance facts outside coverage assessment.

At that point O3 sets `impact_job_required=true` and `o4_readiness=block-only`. O4 must return `blocked-by-insufficient-impact-knowledge`; it may not redo the analysis. This preserves the four-operator boundary as a falsifiable limitation rather than hiding a fifth operator.

## 7. Change control

1. Freeze P1–P7 and governing source digests for each comparative run series.
2. Any material schema, prompt, fixture, selector, or scoring change increments the package version and invalidates cross-version aggregate results unless separately reported.
3. Fixture changes after viewing results are prohibited within the same run series.
4. Operator repairs are captured as new revisions and recovered runs; original raw outputs remain immutable.
5. Legacy sources are never patched for convenience. A baseline defect is recorded, not normalized away.
6. "No material change needed" and "boundary falsified" remain valid results.

## 8. Intentionally outside this prototype

- platform adapters, model/provider selection, API transport, authentication, secrets, durable storage, UI, concurrency, and orchestration packaging;
- implementation, testing, deployment, migration, or target-architecture generation beyond a `ChangeDecision`;
- a fifth dependency-impact operator;
- AB1–AB9 routing for the operator path;
- production claims or live-runtime validation;
- evaluator verdicts or replacement decisions;
- statistical power claims beyond the defined fixtures and later holdouts.

These are deferred because they concern platform packaging, lifecycle coverage, or later empirical evaluation rather than the minimum capability architecture.

## 9. Prototype boundary decision

The prototype proceeds without adding an operator or state object. The Case 8 boundary is encoded as a hard block when supplied evidence cannot make impact facts decision-ready. Comparative execution will determine whether this boundary is useful or merely produces excessive blocking.
