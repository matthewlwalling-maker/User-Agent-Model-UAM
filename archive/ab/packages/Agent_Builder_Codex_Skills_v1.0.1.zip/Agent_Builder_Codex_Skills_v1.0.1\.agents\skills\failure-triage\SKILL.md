---
name: failure-triage
description: Diagnose observed failures in prompts, skills, tests, tools, interfaces, or agent workflows and place the smallest fix at the correct layer. Also handles AB7 runtime burden, clarification, and interface calibration when actual evidence is supplied. Do not use for unobserved speculative audits or broad rewrites.
---

# Failure Triage

## Authority and references

Read:

- `../_shared/references/common-governance-contract.md`
- `../_shared/references/canonical/03_Agent_Builder_Assessment_Contract_v1.0.md`
- `../_shared/references/canonical/05_Agent_Builder_AB1-AB9_Registry_v3.0.md`
- relevant failure definitions in `../_shared/references/canonical/06_Goal-Completeness_E1-E12_Adversarial_Eval_Suite_v1.0.md`

## Inputs

Require observed behavior, exact prompt/invocation, raw output or error, target revision, available test evidence, evidence stage, and authorized action.

For AB7 runtime-calibration work, require observed operator burden, clarification behavior, interface friction, or stop-condition evidence. Without such evidence, provide only a design-time hypothesis and name the needed observation.

## Procedure

1. Reconstruct the expected behavior from the frozen goal or governing contract.
2. Separate observation from interpretation.
3. Classify the failure mechanism, such as anchoring, over-expansion, incorrect tiering, false coverage, evidence overclaim, action misrouting, wrong-layer remedy, regression, excessive clarification, interface friction, or failure to stop.
4. Identify the originating fix layer: core instruction, procedure/registry, resource/source map, schema/deterministic logic, runtime/tool integration, eval harness, interface/output compiler, or deployment/governance.
5. State severity and confidence separately.
6. Distinguish local evidence from systemic evidence; one ambiguous miss is not systemic.
7. Recommend the smallest sufficient patch/augment/rewrite route and the exact regression test.
8. Apply a patch only when the action explicitly authorizes it and the target boundary is clear; otherwise hand off to `artifact-change`.

## Output

- observed failure;
- expected behavior;
- root-cause class and supporting evidence;
- originating fix layer;
- severity and confidence;
- smallest remedy and structural reach;
- regression verification owed;
- residual risks and next operation.

## Boundaries

- Do not default failures to the core prompt.
- Do not claim runtime calibration from design-only evidence.
- Do not broaden a targeted diagnosis into a whole-system rewrite without structural evidence and authority.
