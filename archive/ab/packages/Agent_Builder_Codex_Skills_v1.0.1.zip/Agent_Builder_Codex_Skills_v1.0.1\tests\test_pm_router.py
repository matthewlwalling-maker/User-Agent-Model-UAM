import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / '.agents' / 'skills' / '_shared' / 'scripts' / 'validate_pm_invocation.py'
spec = importlib.util.spec_from_file_location('pm', SCRIPT)
pm = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = pm
spec.loader.exec_module(pm)

class PromptMacroTests(unittest.TestCase):
    def test_full_valid(self):
        r = pm.parse('AB4.goal-completeness.assess this architecture.design-time.recommend')
        self.assertTrue(r.valid)
        self.assertEqual(r.skill, 'architecture-assessment')
        self.assertEqual(r.lens, 'architecture')

    def test_bare_shorthand(self):
        r = pm.parse('AB4.assess this architecture')
        self.assertTrue(r.valid)
        self.assertEqual(r.mode, 'holistic')
        self.assertEqual(r.evidence, 'design-time')
        self.assertEqual(r.action, 'assess-only')

    def test_mode_shorthand(self):
        r = pm.parse('AB2.adversarial.test the router')
        self.assertTrue(r.valid)
        self.assertEqual(r.mode, 'adversarial')
        self.assertEqual(r.lens, 'behavior')
        self.assertEqual(r.skill, 'adversarial-evaluation')

    def test_ab2_shorthand_follows_core_router_default(self):
        r = pm.parse('AB2.adversarial.test the router')
        self.assertTrue(r.valid)
        self.assertEqual(r.normalized, 'AB2.adversarial.behavior.test the router.design-time.assess-only')
        self.assertEqual(r.evidence, 'design-time')
        self.assertEqual(r.action, 'assess-only')
        self.assertTrue(any('E001' in w for w in r.warnings))

    def test_ab2_explicit_simulated_retest_maps_to_adversarial_evaluation(self):
        r = pm.parse('AB2.adversarial.test the router.simulated.retest')
        self.assertTrue(r.valid)
        self.assertEqual(r.normalized, 'AB2.adversarial.behavior.test the router.simulated.retest')
        self.assertEqual(r.skill, 'adversarial-evaluation')
        self.assertEqual(r.evidence, 'simulated')
        self.assertEqual(r.action, 'retest')

    def test_ab2_retest_without_evidence_rejected(self):
        r = pm.parse('AB2.adversarial.test the router.retest')
        self.assertFalse(r.valid)
        self.assertEqual(r.rule, 'V4')

    def test_action_without_evidence_rejected(self):
        r = pm.parse('AB4.goal-completeness.add missing pieces.augment')
        self.assertFalse(r.valid)
        self.assertEqual(r.rule, 'V4')

    def test_open_architecture_valid(self):
        r = pm.parse('AB4.goal-completeness.find latent gaps.design-time.recommend +open-architecture')
        self.assertTrue(r.valid)
        self.assertTrue(r.open_architecture)

    def test_orphan_ideal_rejected(self):
        r = pm.parse('AB4.holistic.this architecture.design-time.assess-only +open-architecture')
        self.assertFalse(r.valid)
        self.assertEqual(r.rule, 'V7')

    def test_bad_host(self):
        r = pm.parse('AB10.holistic.x.design-time.assess-only')
        self.assertFalse(r.valid)
        self.assertEqual(r.rule, 'V1')

    def test_scope_periods_preserved(self):
        r = pm.parse('AB3.delta.compare v1.2 vs v1.3.design-time.recommend')
        self.assertTrue(r.valid)
        self.assertEqual(r.scope, 'compare v1.2 vs v1.3')

    def test_ab7_maps_to_triage_profile(self):
        r = pm.parse('AB7.targeted.calibration burden.live-runtime.recommend')
        self.assertTrue(r.valid)
        self.assertEqual(r.skill, 'failure-triage')

    def test_ab8_and_ab9_same_skill(self):
        self.assertEqual(pm.parse('AB8.holistic.state handoff.design-time.package').skill, 'handoff-package')
        self.assertEqual(pm.parse('AB9.holistic.portable packet.design-time.package').skill, 'handoff-package')

if __name__ == '__main__':
    unittest.main()
