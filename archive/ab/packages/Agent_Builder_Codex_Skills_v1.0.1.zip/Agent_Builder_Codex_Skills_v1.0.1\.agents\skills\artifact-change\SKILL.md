---
name: artifact-change
description: Patch, augment, rewrite, or implement an authorized change in prompts, skills, schemas, tests, documentation, configuration, or code. Use when the target and action boundary are committed or narrowly explicit. Do not use for open-ended architecture assessment or deployment gating.
---

# Artifact Change

## Authority and references

Read:

- `../_shared/references/common-governance-contract.md`
- `../_shared/references/source-authority.md`
- `../_shared/references/canonical/02_Agent_Builder_Component_Registry_v1.0.md`
- `../_shared/references/canonical/05_Agent_Builder_AB1-AB9_Registry_v3.0.md`

## Eligibility

Proceed when either:

- a committed goal/capability/gap/action decision is supplied; or
- the user gives a narrow, reversible, explicit change instruction with a clear target.

For a broad rewrite, semantically system-wide propagation, destructive operation, or unresolved change boundary, stop and identify the smallest missing authorization.

## Procedure

1. Confirm the target revision, authorized action, named scope, preservation requirements, and verification commands.
2. Inspect dependencies before editing.
3. Apply the smallest sufficient reach:
   - patch: named components only; leave unnamed components stable;
   - augment: add/integrate capability and revise only directly connected first-degree interfaces;
   - rewrite: whole asset, only with explicit authority;
   - implement: apply the committed target architecture without reopening it.
4. Do not perform unrelated cleanup.
5. Preserve verified strengths and intentional safety redundancy.
6. Record touched files/components, direct dependency edits, and prohibited propagation respected.
7. Run available targeted tests, then material regressions.
8. Distinguish implementation completion from verification completion.
9. Return the revised artifact or patch plus a change record and regression list.

## Output

- modified artifact or exact diff;
- authorized action and boundary;
- files/components changed;
- preserved elements;
- dependency reach;
- tests run and results;
- residual risks;
- next separately authorized operation.

Use `../_shared/assets/change-record-template.md` for a durable record.

## Boundaries

- Never hide a rewrite inside repeated patches or augments.
- Never claim post-implementation success when tests were not run or failed.
- Do not automatically invoke `adversarial-evaluation`; recommend the exact next operation instead.
