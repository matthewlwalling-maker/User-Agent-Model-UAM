# P4 — Selector and State-Transition Protocol

**Version:** 0.1  
**Dependencies:** P2 schemas; P3 runtime contracts

## 1. Selection type

The prototype is **hybrid overall**:

- selection, precondition checks, state transitions, stale detection, and rejections are deterministic;
- reasoning inside the selected operator is constrained-generative under P3;
- no generative model may override selector legality.

This is not AB1–AB9 under new names. The selector owns only dependency-safe creation of the five fixed state objects and one terminal stop. It has no lifecycle hosts, modes, lenses, actions, implementation routes, deployment gate, or prompt-macro syntax.

## 2. Selector input and output

Input:

```json
{
  "requested_result": "normalize-goal|derive-capabilities|assess-coverage|choose-decision|continue-to-terminal",
  "current_objects": [],
  "new_external_inputs": [],
  "requested_branch": "main|branch-id|all",
  "independence_condition": "packet-boundary|separate-context|not-applicable"
}
```

Output:

```json
{
  "selector_result": "selected|rejected|terminal|failure",
  "selected_operator": "O1|O2|O3|O4|null",
  "basis": ["machine-checkable predicate results"],
  "rejected_operators": [{"operator":"O...","code":"...","reason":"..."}],
  "input_packet_manifest": {"allowed_refs":[],"forbidden_inputs":[]},
  "next_expected_object": "...|null"
}
```

Every selector record is retained under P6.

## 3. Eligibility predicates

### O1 eligible

`goal_missing OR goal_stale OR goal_invalid OR relevant_goal_evidence_changed OR requiredness_basis_missing OR goal_reopened`

O1 is ineligible when a committed/current GoalContract exists and no goal/constraint input changed.

### O2 eligible

`goal_committed_current AND (capability_model_missing OR capability_model_stale OR owned_model_adjudication_requested)`

O2 is ineligible if GoalContract is blocked/invalid/materially contested without a selected branch, or if the packet contains forbidden asset content.

### O3 eligible

`goal_committed_current AND capability_model_committed_current AND asset_version_fixed AND evidence_stage_known AND (coverage_map_missing OR coverage_map_stale OR asset_or_relevant_evidence_changed)`

O3 is ineligible before O2, on a contaminated/stale CapabilityModel, or when material branches are silently combined.

### O4 eligible

`coverage_map_committed_current AND overall_o4_readiness IN {intervention-ready, block-only} AND (change_decision_missing OR change_decision_stale)`

O4 is ineligible when impact readiness is `not-ready`, when a target branch is unresolved and decisions differ, or when new unprocessed evidence is supplied.

## 4. Deterministic selection algorithm

```text
S0 Validate every supplied state object against P2.
S1 Verify exact ID/revision/branch/hash references and producer/write authority.
S2 Apply invalidation rules before eligibility.
S3 Evaluate O1–O4 eligibility and non-selection predicates.
S4 If the user explicitly requests an operator, reject it when ineligible and
   continue only if requested_result permits prerequisite resolution.
S5 If exactly one operator is eligible, select it.
S6 If multiple operators are eligible, choose the owner of the earliest stale or
   missing prerequisite in this dependency order:
       GoalContract -> CapabilityModel -> CoverageMap -> ChangeDecision.
   This is dependency repair, not a mandatory lifecycle ritual.
S7 If none is eligible:
   a. if a current ChangeDecision exists, return terminal;
   b. if CoverageMap is block-only and no ChangeDecision exists, O4 is eligible;
   c. if the requested operation is outside O1–O4 and sufficient assessment state
      exists, select O4 to emit stop-unowned-operation;
   d. otherwise return selector failure with exact missing/invalid state.
S8 Build the P3 ExecutionPacket using only permitted fields and ledger entries.
S9 Validate operator output, apply append-only ledger delta, and record transition.
```

## 5. Multiple-eligible ownership resolution

Multiple operators can appear eligible after several upstream changes arrive together. Ownership resolves by the first invalid dependency, not by preference or claimed seniority.

Example: a new material constraint arrives while a stale CoverageMap and ChangeDecision also exist. O1 runs first because requiredness may change; O3/O4 remain rejected until downstream state is regenerated.

A downstream operator may never repair an upstream field. An O3 output containing an action selection is rejected with `MCP-E430`; an O4 output changing coverage is rejected with `MCP-E530`.

## 6. Rejected-selection behavior

The selector never silently normalizes an illegal request. It returns:

- requested operator;
- failed predicate;
- P2/P3 error code;
- minimal legal prerequisite or terminal block;
- no partially created state object.

### Required hard rejections

| Attempt | Rejection |
|---|---|
| O3 without committed/current O2 output | `MCP-E400_O3_BEFORE_O2` |
| O4 without current CoverageMap | `MCP-E500_O4_WITHOUT_CURRENT_COVERAGE` |
| O4 intervention when O3 is block-only/not-ready | `MCP-E510_O4_WITHOUT_IMPACT_KNOWLEDGE` |
| O2 packet contains asset decomposition/labels | `MCP-E220_INDEPENDENCE_CONTAMINATION` |
| Non-owner writes another state object | `MCP-E020_ILLEGAL_WRITE_AUTHORITY` |
| Silent branch union | `MCP-E230_SILENT_MODEL_UNION` or `MCP-E610_UNRESOLVED_BRANCH` |

## 7. Stale-parent and invalidation protocol

| Change | Objects invalidated or revalidated |
|---|---|
| Goal outcome, requiredness, or material constraint revision | CM, CV, CD become stale |
| Optional/speculative wording change with no required-set effect | revalidate CM hash dependency; CM may remain current only with explicit invariance record; CV/CD follow CM result |
| CapabilityModel revision | CV and CD stale |
| Asset version/hash change | CV and CD stale |
| Same-scope new evidence | CV revalidation required; CD stale if material conclusion/stage may change |
| Higher-stage evidence | only eligible CV claims and dependent CD are reassessed; no automatic goal/capability rewrite |
| CoverageMap revision | CD stale |
| New conflict branch | dependent state becomes branch-specific/contested; universal CD blocked unless invariant |
| Change implementation | outside scope; create a new asset version and return to O3 |

Staleness is represented by `meta.freshness=stale` and exact parent mismatch. A stale object is retained for audit but cannot be consumed as current.

## 8. Evidence-ledger invalidation

The ledger itself is append-only and does not become stale as history. Claims and state objects can become stale when:

- a new contradictory entry applies to their scope;
- a source is superseded;
- a new asset version changes applicability;
- a higher-stage entry permits or refutes promotion.

The selector computes impacted object refs from each entry's scope and `claim_refs`. It never deletes prior evidence.

## 9. Branch and conflict handling

1. Materially different GoalContracts or CapabilityModels receive separate `branch_id` values.
2. Each downstream object references one branch or records explicit branch comparison.
3. No automatic union, averaging, or "best of both" merge is permitted.
4. The owner operator may produce a new resolved branch only with all parent refs and `resolution_basis`.
5. O3 assesses model branches separately.
6. O4 may issue a branch-independent decision only when the same decision and boundary are valid under every live branch.
7. Otherwise O4 returns `blocked-by-material-disagreement`.

## 10. Legal loops

- O1 rerun after changed goal/constraint evidence or owned ambiguity resolution.
- O2 rerun after a GoalContract revision, contamination reset, or explicit model adjudication.
- O3 rerun after CapabilityModel/asset/evidence revision.
- O4 rerun after CoverageMap revision or new eligible evidence.

No operator may loop solely to improve prose, fill optional fields, or manufacture work after a valid terminal decision. A committed ChangeDecision requires a named revisit trigger or changed parent.

## 11. Zero-eligible and unowned operations

If the requested work is implementation, testing, target-architecture generation, platform packaging, migration, deployment, or another job outside O1–O4:

- when assessment state is incomplete, resolve only the prerequisite assessment work requested by `continue-to-terminal`;
- when assessment state is sufficient, O4 emits `stop-unowned-operation` with `next_consumer_contract`;
- the selector does not create a new operator, invoke AB1–AB9 for the operator path, or pretend the work was performed.

## 12. Compact execution

Compact execution may run O1–O4 within one model response only as four separately validated transforms. The selector must still record four selection/transition events, exact object revisions, and rejected candidates. Co-serialization does not legalize skipping O2 or letting O4 reanalyze O3.

## 13. Selector conformance examples

### Reject O3 before O2

```text
State: GC committed; CM absent; user requests coverage.
Eligibility: O2=true, O3=false(MCP-E400), O4=false.
Result: select O2; record rejected O3.
```

### Reject O4 without impact knowledge

```text
State: CV current; overall_o4_readiness=not-ready.
Eligibility: O4=false(MCP-E510).
Result: selector failure or O3 rerun if its internal analysis is incomplete.
```

### Permit O4 block-only

```text
State: CV current; impact_job_required=true; overall_o4_readiness=block-only.
Eligibility: O4=true for blocked-by-insufficient-impact-knowledge only.
Result: O4 cannot select local/addition/restructure.
```
