# 02 — Agent Builder PM Framework: Component Registry

**Version:** 1.0 · **Status:** Active · **Authority:** legal tokens, compatibility, schema validation, action boundaries, N+1, default routes (Manifest §3)

This registry is the single source of truth for **what is legal**. Every other artifact references these tables and must not redefine them. Tables are written to be machine-checkable: any invocation string can be validated against §6.

---

## 1. Modes (the closed `{mode}` vocabulary)

| Mode | Default lens (§2) | Notes |
|---|---|---|
| `.holistic` | `.architecture` | whole-asset critique |
| `.component` | `.architecture` | single named component |
| `.subcomponent` | `.behavior` | behavioral-driver analysis |
| `.delta` | `.architecture` | recent-change review |
| `.targeted` | `.behavior` | one identified concern |
| `.blind` | `.output` | no priors given to evaluator |
| `.independent` | `.architecture` | second-agent derivation |
| `.adversarial` | `.behavior` | failure-seeking |
| `.regression` | `.verification` | behavior-preservation after change |
| `.verification` | `.verification` | implementation confirmation |
| `.goal-completeness` | `.architecture` | AB4-primary; executes `04` |

Defaults are **registry defaults**, calibratable; they are not part of the locked schema. (Lens-optionality determinism is a tracked limitation — Manifest §8 risk #3.)

## 2. Lenses (the closed optional `{lens}` vocabulary)

`.intent` · `.architecture` · `.boundary` · `.source` · `.resource` · `.runtime` · `.safety` · `.behavior` · `.output` · `.efficiency` · `.maintainability` · `.deployment` · `.verification` · `.generalization`

Lens is optional in the schema; if omitted, the mode default (§1) applies; if present, it must be one of the above.

## 3. Evidence stages (the closed, **mandatory** `{evidence}` vocabulary)

| Stage | Supports a claim of |
|---|---|
| `.design-time` | architectural plausibility, textual completeness |
| `.simulated` | behavior under controlled test prompts/fixtures |
| `.live-runtime` | observed execution in the active environment |
| `.post-implementation` | verification after a specific change |
| `.production-observed` | repeated real-world behavior |

A claim may never exceed its stated stage (`03` evidence rule).

## 4. Actions (the closed, **mandatory** `{action}` vocabulary)

`.assess-only` · `.recommend` · `.patch` · `.augment` · `.rewrite` · `.implement` · `.retest` · `.package` · `.gate`

| Action | Use when |
|---|---|
| `.assess-only` | evaluation requested, no generative flag active |
| `.recommend` | target state wanted, no artifact modification |
| `.patch` | local defect, unnamed components stay stable |
| `.augment` | base sound, missing capability integrable within N+1 (§8) |
| `.rewrite` | base materially defective, ~≥40% misplaced/duplicated/ineffective, or N+2 cascade (§8) |
| `.implement` | apply the authorized target architecture |
| `.retest` | re-evaluate implementation/runtime behavior |
| `.package` | convert outputs into a portable execution/handoff packet |
| `.gate` | produce a readiness decision |

## 5. Flag compatibility

| Flag | Legal actions | Illegal actions |
|---|---|---|
| `+open-architecture` | `.recommend`, `.augment`, `.rewrite`, `.implement` | `.assess-only`, `.patch`, `.retest`, `.package`, `.gate` |

`+open-architecture` relaxes the solution-space constraint: treat the current asset as one candidate, not the boundary. It never authorizes speculative expansion — every required proposal still traces to a Tier 1–2 goal (`04` §10). An unconstrained ideal with no path to value (`.assess-only`) is an error, not a deliverable: **reject before executing.**

---

## 6. Schema-validation logic (machine-checkable)

Input: a candidate invocation string. Validate in order; on any FAIL, reject with the listed reason.

```
V1  HOST      token0 matches /^AB[1-9]$/                      else FAIL "bad/again host (no AB0, AB10+, leading zero)"
V2  MODE      a token ∈ Modes(§1) is present after host       else FAIL "missing/unknown mode"
V3  LENS      if a lens token present, it ∈ Lenses(§2)        else FAIL "unknown lens"
V4  EVIDENCE  exactly one token ∈ Evidence(§3) present        else FAIL "missing/ambiguous evidence stage"
V5  ACTION    exactly one token ∈ Actions(§4) present, and
              it is positioned after the evidence token       else FAIL "missing/misordered action"
V6  SCOPE     non-empty free text exists between mode/lens
              and the evidence token                          else FAIL "empty scope phrase"
V7  FLAG      if ' +open-architecture' suffix present,
              ACTION ∈ {.recommend,.augment,.rewrite,.implement} else FAIL "illegal flag/action pair"
V8  HOSTFIT   if MODE == .goal-completeness and HOST != AB4,
              WARN "goal-completeness is AB4-primary; running as consumer" (not a FAIL)
PASS -> dispatch (01 §6)
```

Defaults (`01` §4) are applied **before** V2/V4/V5 only at shorthand/button entry; a fully-typed string is validated as-is.

### Worked validations

| Invocation | Result |
|---|---|
| `AB4.goal-completeness.architecture.is my eval harness complete for blind grading.design-time.recommend` | PASS |
| `AB4.goal-completeness.what are we missing.design-time.recommend +open-architecture` | PASS (lens defaulted to `.architecture`) |
| `AB4.holistic.this architecture.design-time.assess-only +open-architecture` | FAIL V7 (orphan ideal) |
| `AB10.holistic.x.design-time.assess-only` | FAIL V1 |
| `AB1.augment.add the missing gate.design-time` | FAIL V5 (no action) → note: `.augment` is in scope text here, not the action slot; action is absent |
| `AB4.goal-completeness.add missing pieces.design-time.augment +open-architecture` | PASS |

---

## 7. Default routes (registry-owned)

| Operator intent | Resolved invocation |
|---|---|
| "assess this architecture" | `AB4.holistic.architecture.design-time.assess-only` |
| "is this complete for my goal?" | `AB4.goal-completeness.<asset vs goals>.design-time.recommend` |
| "what are we missing?" | `AB4.goal-completeness.<latent gaps>.design-time.recommend +open-architecture` |
| "add the missing pieces" | `AB4.goal-completeness.<asset + required components>.design-time.augment +open-architecture` |
| "test the new architecture" | `AB2.adversarial.<goal-completeness routing>.<simulated|live-runtime>.retest` |
| "diagnose why it failed" | `AB6.targeted.<failure>.live-runtime.recommend` |

Pre-deployment, the "test" route uses `.simulated`; `.live-runtime` requires an actual running environment (`08`).

---

## 8. Action-boundary table & N+1 Dependency Radius (single source of truth)

| Action | Structural reach | Preservation guarantee | Route when |
|---|---|---|---|
| `.patch` | named components only | all unnamed components byte-stable | defect is local and identified |
| `.augment` | adds + integrates new components; may revise interfaces of **first-degree** touched components | verified strengths preserved; dependencies/interfaces updated; newly-exposed redundancy merged | base sound but missing a capability |
| `.rewrite` | whole asset | none | base materially defective; ~≥40% misplaced/duplicated/ineffective; or required N+2 cascade |

**N+1 Dependency Radius (`.augment`):**
- the new/materially-revised component is **N**;
- interfaces of directly-connected **first-degree** neighbors may be revised;
- **second-degree (N+2) or broader** cascading revision is **not** augmentation;
- when coherent integration requires N+2 propagation, route to `.rewrite`.

**Anti-laundering rule:** do not hide a `.rewrite` inside a sequence of nominal `.augment`s. The ~40% indicator is a routing heuristic, not a mechanical count — structural centrality and dependency impact may outweigh raw component count. This resolves v2.0 §8 risk #3 (the previously under-specified augment propagation boundary). This N+1 definition is referenced verbatim by `03`, `04`, and `05`; it is defined **only here.**

---

## 9. Explicit rejection behavior

On any V-rule FAIL, the agent rejects the invocation, names the failing rule and reason, and offers the minimal correction. It does **not** silently normalize an illegal invocation into a legal one (e.g., it does not drop `+open-architecture` to make an `.assess-only` legal — it surfaces the conflict and lets the operator choose). Recoverable shorthand omissions are not rejections; they are resolved by defaults (`01` §4).
