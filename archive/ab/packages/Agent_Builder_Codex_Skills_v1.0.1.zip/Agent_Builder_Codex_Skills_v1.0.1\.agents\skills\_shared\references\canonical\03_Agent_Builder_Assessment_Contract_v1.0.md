# 03 — Agent Builder PM Framework: Assessment Contract

**Version:** 1.0 · **Status:** Active · **Authority:** cross-AB assessment behavior, required I/O, evidence/fix-layer/stop rules (Manifest §3)

This is the smallest standalone contract that applies to **every** AB1–AB9 assessment, regardless of mode. It owns the shared behavior. It does **not** reproduce procedure-specific steps (those live in `04`) or per-AB roles (those live in `05`). Legal tokens, action boundaries, and N+1 are referenced from `02`, not redefined here.

---

## 1. Required inputs

Every assessment must identify, infer, or explicitly mark as unavailable:

- asset / system under review;
- objective;
- lifecycle stage;
- material constraints;
- mode;
- lens(es);
- **evidence stage (mandatory)**;
- **action (mandatory)**.

Missing detail does not automatically require clarification. Proceed on bounded assumptions, stated in one line, **unless** an unresolved assumption would materially change the architecture or authorize a hard-to-reverse action — then ask one focused question.

## 2. Required output functions

Preserve the informational function; exact headings, tables, and detail vary with the target.

1. Headline verdict / grade — **first line** (except the mode exception, §11).
2. Material findings.
3. Failure mode or value mechanism.
4. Severity + confidence.
5. Correct fix location.
6. Recommended action (from `02` §4).
7. Verification requirement.
8. Stop condition / terminal decision.

## 3. Behavioral-utility rule

Evaluate behavioral utility, not rhetorical sophistication. Do not reward length, polish, novelty, or apparent completeness unless they improve expected results. A section label is not a capability: distinguish **nominal** coverage from **effective** coverage.

## 4. Evidence-stage rule

The evidence stage is a required output position and a **claim ceiling**. A design-time conclusion may never be phrased as validated runtime behavior. State conclusions at the supplied stage (`02` §3) and defer any higher claim to the test that would earn it.

## 5. Correct-fix-layer rule

Place the remedy where the failure originates — core instruction, procedure/registry, resource/source map, schema/deterministic logic, runtime/tool integration, eval harness, interface/output compiler, or deployment/governance. **A gap discovered during core review does not automatically belong in core.** Do not change core when the issue belongs in a resource, schema, runtime, test, or output compiler.

## 6. Smallest-sufficient-change rule

Route by the smallest sufficient structural reach using the `02` §8 action-boundary table and N+1 radius: `.patch` for a local defect, `.augment` (bounded by N+1) when the base is sound but missing a capability, `.rewrite` only when the base is materially defective or integration forces an N+2 cascade. Do not rewrite unaffected components when patch or augment suffices, and do not hide a rewrite inside nominal augments. Preserve intentional safety-reinforcing redundancy.

## 7. Severity & confidence handling

State severity (consequence if unaddressed) and confidence (diagnostic certainty) separately. Confidence may be qualitative; do not fabricate numeric precision. Do not treat one ambiguous failure as systemic architectural failure.

## 8. Verification requirement

After any implementation, verify the artifact and rerun the material regressions plus non-negotiable gates. Name the verification owed before it is performed when assessing at a stage below the claim being requested.

## 9. Stop condition

Stop when expected marginal improvement is below complexity, instability, or regression risk. Iteration for its own sake is a failure mode.

## 10. "No material change needed"

A valid terminal outcome for any assessment. Return it when every required goal has adequate support at the assessed evidence stage and remaining issues are cosmetic, low-value, speculative, or below the action threshold. State the marginal-value reasoning. Optional enhancements may be listed but must not be presented as defects or required next steps.

## 11. Mode-specific exception mechanism

The universal rules above hold for all modes **except** where a mode declares an explicit exception. Exceptions are enumerated here so the universal contract is never weakened silently for other modes.

### 11.1 Registered exception — Material `.goal-completeness` output-order

For `AB4.goal-completeness` on the **Material** path only, **output-order independence overrides the §2 headline-first convention.** The procedure (`04` §7) requires the independent capability model to appear **before** any existing asset component is named. A short procedural path declaration may appear first, but the substantive headline verdict appears only after the independent capability model is complete and sealed.

This exception is scoped to the Material `.goal-completeness` path. The **Trivial** `.goal-completeness` path and all other modes retain headline-first (§2).

### 11.2 Adding an exception

A new mode exception is legal only if it is registered in this section and references the owning procedure. No mode may quietly suspend a universal rule outside this section.

---

## 12. Conformance checklist (apply before returning any assessment)

- Evidence stage stated and not exceeded.
- Fix placed at the originating layer, not defaulted to core.
- Action reach is the smallest sufficient (per `02` §8).
- Severity and confidence stated separately, no false precision.
- "No material change needed" was genuinely available.
- Stopped when marginal value fell below cost/risk.
- If Material `.goal-completeness`: independence order honored (§11.1).
