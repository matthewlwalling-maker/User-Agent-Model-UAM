# 05 — Agent Builder PM Framework: AB1–AB9 Registry

**Version:** 3.0 · **Status:** Active · **Authority:** per-AB roles, modes, lenses, handoffs, default routes, examples (Manifest §3)
**Supersedes:** v1.0 §3 function lists and v2.0 §6 routing table (consolidated here).

AB1–AB9 is the lifecycle router. There is no AB10. Each entry below references `02` (legal tokens, N+1), `03` (assessment contract), and `04` (goal-completeness procedure); it does not redefine them, and AB4 does **not** reproduce the procedure.

**Global stop condition (all hosts):** stop when expected marginal improvement is below complexity/instability/regression risk; "No material change needed" is always available (`03` §9–§10).

---

## AB1 — Iteration, Component Analysis, Patch & Rewrite

- **Purpose:** implementation host. Consumes gap and target-architecture outputs and applies the authorized change.
- **Primary modes:** `.holistic` · `.component` · `.subcomponent` · `.delta` · `.targeted`
- **Default lens:** `.architecture` · **Typical evidence:** `.design-time` → `.post-implementation`
- **Legal/typical actions:** `.patch` · `.augment` · `.rewrite` · `.implement` (all bounded by `02` §8 / N+1)
- **Inputs consumed:** frozen goal model, capability model, gap register, action decision (from AB4/`04`).
- **Outputs produced:** revised artifact + change record + regression list.
- **Handoffs:** upstream ← AB4 (gap register); downstream → AB2 (retest), AB3 (before/after compare), AB6 (if a fix misfires).
- **Default route:** "add the missing pieces" → `AB1`/`AB4` per `02` §7.
- **Mode-specific exception:** none. **Must preserve the N+1 augmentation limit** (`02` §8).
- **Example:** `AB1.targeted.integrate the writeback confirmation gate.post-implementation.augment`

## AB2 — Evaluation Design & Runtime Harness

- **Purpose:** eval and runtime-validation host. Validates E1–E12 and implementation-specific evals; tests evidence claims rather than redefining the goal model.
- **Primary modes:** `.adversarial` · `.regression` · `.verification` · `.blind`
- **Default lens:** `.behavior` · **Typical evidence:** `.simulated` · `.live-runtime`
- **Legal/typical actions:** `.retest` · `.assess-only` · `.recommend`
- **Inputs consumed:** the procedure/asset under test, the eval suite (`06`), frozen goal model.
- **Outputs produced:** pass/fail per test, observed behaviors, evidence-stage tag.
- **Handoffs:** downstream → AB6 (classify misses), AB3 (pre/post compare), AB7 (burden/interface).
- **Default route:** "test the new architecture" → `AB2.adversarial.<routing>.<simulated|live-runtime>.retest`.
- **Mode-specific exception:** none. May not redefine the Tier 1–2 goal model (`04` §16.1).
- **Example:** `AB2.adversarial.goal-completeness procedure and routing.simulated.retest`

## AB3 — Version, Baseline & Component Comparison

- **Purpose:** comparison host using a **frozen** goal/capability model.
- **Primary modes:** `.delta` · `.blind` · `.independent` · `.component`
- **Default lens:** `.architecture` · **Typical evidence:** `.design-time` · `.post-implementation`
- **Legal/typical actions:** `.assess-only` · `.recommend`
- **Inputs consumed:** two or more versions/components + the frozen Tier 1–2 goal and capability model.
- **Outputs produced:** ranked comparison, donor-component recommendation, synthesis.
- **Handoffs:** upstream ← AB1 (revised artifact), AB2 (results); downstream → AB1/AB5.
- **Mode-specific exception:** none. Comparisons are scored against the frozen model, not a re-derived one.
- **Example:** `AB3.delta.original vs augmented architecture.design-time.recommend`

## AB4 — Architecture, Boundary, Resource Placement & Compression Review

- **Purpose:** architecture host and **primary host of `.goal-completeness` + `+open-architecture`**. Produces the gap register and target architecture.
- **Primary modes:** `.holistic` · `.component` · **`.goal-completeness`** · `.independent`
- **Default lens:** `.architecture` · **Typical evidence:** `.design-time`
- **Legal/typical actions:** `.assess-only` · `.recommend` · `.augment` · `.rewrite` (+ `+open-architecture` on the generative actions per `02` §5)
- **Inputs consumed:** asset, objective, constraints, evidence stage, action, flag.
- **Outputs produced:** goal model, independent capability model, coverage map, gap register, target architecture, action decision.
- **Handoffs:** downstream → AB1 (implement), AB2 (test), AB3 (compare), AB5 (gate), AB8 (carry state).
- **Default routes:** "is this complete for my goal?" / "what are we missing?" → AB4 (`02` §7).
- **Mode-specific exception — REGISTERED:** for `AB4.goal-completeness` on the **Material** path, the procedure-specific independence order **overrides** the generic headline-first convention (`03` §11.1, `04` §7.3). The Trivial path and all other AB4 modes retain headline-first. **AB4 executes `04`; it does not contain the ladder, gate, coverage taxonomy, or templates.**
- **Examples:**
  - `AB4.goal-completeness.is my prompt-refiner spec complete for the never-execute boundary.design-time.recommend`
  - `AB4.goal-completeness.latent gaps vs my goals.design-time.recommend +open-architecture`

## AB5 — Deployment, Resource & Integration Readiness Gate

- **Purpose:** readiness gate. Gates deployment only after required post-implementation evidence is available.
- **Primary modes:** `.holistic` · `.verification`
- **Default lens:** `.deployment` · **Typical evidence:** `.post-implementation`
- **Legal/typical actions:** `.gate` · `.assess-only`
- **Inputs consumed:** target architecture, implementation record, test results (AB2), residual risks.
- **Outputs produced:** Green / Yellow / Red readiness decision + exact conditions to advance.
- **Handoffs:** upstream ← AB1/AB2/AB4; downstream → AB8/AB9.
- **Mode-specific exception:** none. May not return Green while a non-negotiable gate is unverified at the required evidence stage.
- **Example:** `AB5.holistic.deployment readiness of the framework package.post-implementation.gate`

## AB6 — Failure Triage, Fix Placement & Regression Verification

- **Purpose:** failure-triage and fix-placement host. Diagnoses procedure failures (anchoring, over-expansion, incorrect tiering, action misrouting) and places the fix.
- **Primary modes:** `.targeted` · `.subcomponent` · `.regression`
- **Default lens:** `.behavior` · **Typical evidence:** `.live-runtime`
- **Legal/typical actions:** `.recommend` · `.patch` · `.retest`
- **Inputs consumed:** observed failure, eval result (AB2/`06`), the asset.
- **Outputs produced:** root-cause class, correct fix layer (`03` §5), severity, residual risk.
- **Handoffs:** upstream ← AB2; downstream → AB1 (apply fix), AB3 (pre/post), AB7 (if burden/interface).
- **Mode-specific exception:** none. A single ambiguous failure is not classified as systemic (`03` §7).
- **Example:** `AB6.targeted.E1 anchoring miss.live-runtime.recommend`

## AB7 — Runtime Behavior, Usability & Interface Calibration

- **Purpose:** runtime-burden and interface-calibration host. Calibrates gate burden, clarification behavior, interface usability, stop conditions. **Used only for burden, clarification, or interface-calibration issues** — not for procedural/routing failures (those are AB6).
- **Primary modes:** `.targeted` · `.holistic`
- **Default lens:** `.runtime` · **Typical evidence:** `.live-runtime`
- **Legal/typical actions:** `.recommend` · `.patch`
- **Inputs consumed:** observed operator burden, clarification/assumption behavior, interface friction.
- **Outputs produced:** burden/clarification/stop calibration recommendations.
- **Handoffs:** upstream ← AB2/AB6; downstream → AB1.
- **Mode-specific exception:** none.
- **Example:** `AB7.targeted.scaling-gate burden on trivial targets.live-runtime.recommend`

## AB8 — Handoff, Migration & State Preservation Pack

- **Purpose:** state-preserving handoff host. Carries the frozen state forward without loss.
- **Primary modes:** `.holistic` · `.delta`
- **Default lens:** `.maintainability` · **Typical evidence:** `.design-time`
- **Legal/typical actions:** `.package` · `.recommend`
- **Inputs consumed:** scaling path, frozen Tier 1–2 goal set, capability model, gap/sufficiency decision, structural-reach determination, evidence stage, verification requirement, stop condition, unresolved risks (`04` §16.4).
- **Outputs produced:** a handoff packet preserving all of the above.
- **Handoffs:** downstream → AB9 (package) / next agent.
- **Mode-specific exception:** none. A handoff is complete only when the `04` §16.4 state set is preserved.
- **Example:** `AB8.holistic.carry goal model + gap register to next phase.design-time.package`

## AB9 — Prompt Packaging, Compression & Execution Packet Builder

- **Purpose:** portable packaging host. Packages procedure inputs/outputs into a portable packet **without collapsing Tier 3–4 opportunities into requirements.**
- **Primary modes:** `.holistic`
- **Default lens:** `.output` · **Typical evidence:** `.design-time`
- **Legal/typical actions:** `.package`
- **Inputs consumed:** the AB8 handoff packet or a procedure result.
- **Outputs produced:** a compact, context-portable execution packet.
- **Handoffs:** terminal / next environment.
- **Mode-specific exception:** none. Must keep Tier 3–4 optional in the packet.
- **Example:** `AB9.holistic.portable packet of the framework deployment.design-time.package`

---

## Routing matrix (quick reference)

| Need | Host | Consumes goal-completeness output? |
|---|---|---|
| derive completeness / target architecture | AB4 | produces it |
| implement the change | AB1 | yes (gap register) |
| test it | AB2 | yes (tests the procedure) |
| compare before/after | AB3 | yes (frozen model) |
| gate deployment | AB5 | yes (gates target arch) |
| diagnose a failure | AB6 | yes (diagnoses misfires) |
| calibrate burden/interface | AB7 | yes (tunes burden) |
| preserve state | AB8 | yes (carries it) |
| package portably | AB9 | yes (compresses it) |
