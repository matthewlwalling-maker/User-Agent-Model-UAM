# Capture Protocol v0.3

This package inherits `Context Resources/Runtime/OMR_Evidence_Capture_Protocol_v0.1.md`.

## Package-Local Application

Every v0.3 row must produce a row archive containing:

- `selector_records/`
- `rejected_selection_logs/`
- `execution_packets/`
- `operator_input_packets/`
- `state_snapshots/`
- `ledger_projections/`
- `forbidden_input_records/`
- `raw_prompts/`
- `raw_outputs/`
- `scoring_inputs/`
- `row_manifest.json`

The row manifest must cite all artifact hashes and must state whether each required artifact is present, missing, invalid, stale, superseded, or not applicable.

## Required Selector Artifacts

For every attempted transition, capture selector input refs, eligibility rule, selected operator, accepted/rejected outcome, rejection code if any, and selector record hash.

## Required Packet Artifacts

For every operator or legacy-equivalent step, capture the exact ExecutionPacket manifest and exact input packet body. The O2 packet body must be preserved even if the O2 output is invalid.

## Required State Artifacts

Capture every version of each governed state object. Do not overwrite invalid, stale, superseded, contested, or rejected objects.

## Required Ledger Projection Artifacts

When a subset ledger projection is used, capture stable ledger ID, ledger revision, projection digest, included entries, omitted count, append-delta rule, and the rule forbidding inference from omitted entries.

## Failure Rule

If required artifacts are missing, mark the row `evidence-fail` for the relevant evidence dimension even when the behavioral output is correct.
