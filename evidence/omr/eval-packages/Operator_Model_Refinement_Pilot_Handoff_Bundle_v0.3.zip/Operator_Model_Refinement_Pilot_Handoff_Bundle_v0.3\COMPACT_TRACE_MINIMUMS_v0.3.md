# Compact Trace Minimums v0.3

Compact variants are valid only when their output remains reconstructable without conversation history.

## Minimum Recoverable Fields

- run row ID;
- operator or legacy-equivalent step;
- state object refs and hashes;
- requiredness class and basis;
- obligation refs;
- capability refs;
- bidirectional obligation/capability trace;
- evidence ceiling;
- ledger projection digest;
- branch/conflict state;
- coverage or gap refs when applicable;
- impact readiness and reach basis when applicable;
- terminal decision;
- stop basis;
- limitations.

## Failure Rule

A compact row fails trace completeness when the evaluator cannot reconstruct the governed decision from captured artifacts, even if the final behavior appears correct.

## Burden Calibration

Compactness is scored separately from trace completeness. Lower burden cannot compensate for missing reconstruction fields.
