# Changelog v0.2 to v0.3

## Summary

v0.3 is a capture-protocol correction package. It does not change OMR architecture, old evidence, or behavioral criteria.

## Defects Closed by Design

- Added permanent project-level evidence-capture inheritance.
- Required exact selector transition records and rejected-selection logs.
- Required exact ExecutionPacket manifests and operator input packets.
- Required O2 packet contents, O2 packet hash, and forbidden-input records.
- Required reconstructable snapshots for `GoalContract`, `CapabilityModel`, `EvidenceLedger`, `CoverageMap`, and `ChangeDecision`.
- Required invalid, stale, superseded, contested, and rejected objects to remain auditable.
- Replaced ambiguous `separate-context` credit with actual context labeling and isolation proof.
- Required `parent-thread-single-context`, `packet-boundary`, and true `separate-context` results to be stratified.
- Added compact trace reconstruction minimums.
- Split scorecard dimensions for behavior, trace, state/packet completeness, isolation, evidence ceiling, burden, terminal decision, confidence, and limitations.
- Clarified executor terminal decisions are raw outputs, not evaluator pass/fail labels.
- Added case-specific scoring notes for C03, C05, C07, and C08.
- Added validation gates that fail missing evidence even when behavior looks correct.

## v0.2 Evidence Handling

v0.2 remains archived as flawed screening evidence. Its rows, outputs, and limitations are not relabeled, repaired, rescored, or pooled into v0.3 results.
