# State and Packet Requirements v0.3

This file applies the permanent capture protocol to the five OMR state objects and execution packets.

## State Snapshot Envelope

Every state snapshot must include:

- object ID;
- object kind;
- schema version;
- revision;
- status;
- freshness;
- branch ID;
- parent refs;
- producer;
- evidence refs;
- conflict refs;
- projection;
- content hash;
- created-at timestamp when available.

## Required State Objects

- `GoalContract`
- `CapabilityModel`
- `EvidenceLedger`
- `CoverageMap`
- `ChangeDecision`

No sixth architectural state object is introduced.

## Parent Ref Rules

Every downstream state must cite exact parent refs. A child state with missing, mismatched, stale, or inferred parent refs fails state completeness.

## O2 Trace Rules

O2 must preserve:

- exact GoalContract input snapshot;
- exact packet-boundary or separate-context label;
- exact O2 packet hash;
- forbidden input list;
- forbidden input inspection result;
- capability list;
- obligation-to-capability map;
- capability-to-obligation map;
- required, optional, and speculative basis;
- derivation boundary.

Narrative-only O2 traces fail validation.

## ExecutionPacket Manifest Fields

Each manifest must include run ID, row ID, case ID, variant ID, replicate ID, source profile, actual context condition, context ID, operator, selector record ID, input refs, packet hash, permitted reads, forbidden reads, ledger projection digest, expected output schema, and evidence stage.
