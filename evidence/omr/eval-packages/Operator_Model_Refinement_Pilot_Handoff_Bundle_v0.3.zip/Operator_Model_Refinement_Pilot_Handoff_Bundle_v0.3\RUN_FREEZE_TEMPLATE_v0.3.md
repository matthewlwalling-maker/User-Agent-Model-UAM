# Run Freeze Template v0.3

Complete this file before running v0.3.

## Run Identity

- run_id:
- freeze_timestamp:
- executor:
- evaluator:
- evidence_stage:

## Source Hashes

- `AGENTS.md`:
- `Context Resources/Runtime/OMR_Evidence_Capture_Protocol_v0.1.md`:
- `Context Resources/Runtime/OMR_Operator_Prototype_Runtime_v0.2.md`:
- `Context Resources/Runtime/P2_State_Schemas_v0.1.json`:
- `Context Resources/Runtime/P5_Executor_View_v0.1.yaml`:
- `Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.2.zip`:
- `Project State/Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.3.zip`:

## Context Plan

- context creation method:
- separate-context context IDs:
- packet-boundary context IDs:
- parent-thread-single-context exclusions:
- isolation proof location:

## Artifact Roots

- row archive root:
- selector records root:
- execution packets root:
- state snapshots root:
- ledger projections root:
- raw outputs root:
- scorecards root:

## Prohibitions

- Do not use v0.2 rows as v0.3 results.
- Do not score executor terminal decisions as pass/fail labels.
- Do not claim separate-context without proof.
- Do not run scoring in the same context as raw execution when blind or independent scoring is claimed.
