# Separate Context Protocol v0.3

## Valid Labels

- `separate-context`: the execution context has no prior asset exposure and has an auditable context ID or equivalent isolation proof.
- `packet-boundary`: the packet restricts inputs, but the broader execution context may have seen the asset or prior materials.
- `parent-thread-single-context`: execution occurred in the parent thread or same conversation and is not cognitively isolated.

## True Separate-Context Procedure

1. Create a fresh execution context that has not seen the asset, old outputs, evaluator notes, or package-internal scoring.
2. Record context ID, creation timestamp, initiating packet hash, and asset-exposure declaration.
3. Provide only the frozen ExecutionPacket and permitted references.
4. Record forbidden-input inspection before execution.
5. Capture raw output and state artifacts in the row archive.
6. Record any contamination or unavailable isolation as a limitation.

## Fallback Rule

If true isolation cannot be executed, the row must be labeled `parent-thread-single-context` or `packet-boundary`, not `separate-context`.

## Stratification Rule

Results from `separate-context`, `packet-boundary`, and `parent-thread-single-context` must be reported separately. They must not be pooled for isolation claims.
