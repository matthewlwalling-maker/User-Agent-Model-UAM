# Operator Model Refinement Pilot Handoff Bundle v0.3

Status: corrected evidence-collection package
Task class: test-package-design
Evidence ceiling: design-time package revision; not rerun evidence

## Purpose

This package corrects the v0.2 evidence-capture design defects without rerunning the pilot, evaluating v0.2 again, or modifying sealed v0.2 evidence.

The package inherits the permanent standard in:

`Context Resources/Runtime/OMR_Evidence_Capture_Protocol_v0.1.md`

Package-local files define the v0.3 freeze, row matrix, scoring fields, and validation gates needed by a future run executor.

## Required Inputs for a Future Run Executor

- `AGENTS.md`
- `Context Resources/Runtime/OMR_Evidence_Capture_Protocol_v0.1.md`
- `Context Resources/Runtime/OMR_Operator_Prototype_Runtime_v0.2.md`
- `Context Resources/Runtime/P2_State_Schemas_v0.1.json`
- `Context Resources/Runtime/P5_Executor_View_v0.1.yaml`
- `Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.2.zip`
- `Project State/OMR_Lateral_Eval_Input_Package_2026-06-19.zip`
- `Project State/OMR_Upstream_Eval_Handoff_2026-06-19.zip`
- `Project State/OMR_Raw_Execution_2026-06-19/`
- `Project State/OMR_Raw_Execution_2026-06-19/OMR_context_and_limitations.md`
- `Project State/folder-cleanup-record_2026-06-19.md`

## Non-Goals

- Do not rerun v0.2.
- Do not relabel or repair old evidence.
- Do not pool v0.2 and v0.3 results.
- Do not change OMR architecture.
- Do not create easier tests to make OMR pass.

## Files

- `README_v0.3.md`
- `CHANGELOG_v0.2_to_v0.3.md`
- `CAPTURE_PROTOCOL_v0.3.md`
- `STATE_PACKET_REQUIREMENTS_v0.3.md`
- `SEPARATE_CONTEXT_PROTOCOL_v0.3.md`
- `COMPACT_TRACE_MINIMUMS_v0.3.md`
- `VALIDATION_GATES_v0.3.md`
- `EVALUATOR_SCORECARD_v0.3.csv`
- `RUN_MATRIX_v0.3.csv`
- `DECISION_THRESHOLDS_v0.3.md`
- `RUN_FREEZE_TEMPLATE_v0.3.md`
- `PACKAGE_MANIFEST_v0.3.csv`

## Execution Boundary

The next valid operation is a fresh v0.3 run freeze and execution using this package. Any executor must preserve v0.2 as flawed screening evidence and record v0.3 results separately.
