# Decision Thresholds v0.3

v0.3 distinguishes behavior pass from evidence pass.

## Row-Level Thresholds

- `behavior-pass`: behavior correctness is `pass`.
- `evidence-pass`: trace completeness, state/packet completeness, isolation validity where applicable, and evidence ceiling compliance are all `pass`.
- `behavior-pass-evidence-fail`: behavior correctness is `pass`, but any evidence dimension fails.
- `not-scorable`: required raw output or required evaluator context is absent.

## Package-Level Thresholds

No package may advance an architecture claim unless:

- all rows required for the claim have evidence-pass;
- isolation-dependent claims use only true separate-context rows with proof;
- compactness claims use rows that pass compact reconstruction minimums;
- v0.2 results are reported separately from v0.3 results.

## Yellow/Green Boundary

A package can remain behaviorally promising but Yellow/inconclusive when evidence capture fails. Green requires both behavior and evidence support at the claimed evidence stage.
