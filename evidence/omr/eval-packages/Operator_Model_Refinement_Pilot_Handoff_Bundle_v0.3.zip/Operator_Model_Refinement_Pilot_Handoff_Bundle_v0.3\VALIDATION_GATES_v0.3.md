# Validation Gates v0.3

Validation must be performed before any v0.3 results are accepted for evaluation.

## Package Gates

- PASS only if the permanent protocol path and hash are recorded.
- PASS only if all required v0.3 package files are present.
- FAIL if v0.2 evidence is relabeled, repaired, or pooled into v0.3 results.
- FAIL if package scoring collapses behavior correctness and evidence completeness into one score.

## Row Gates

- FAIL if required selector records are missing.
- FAIL if required rejected-selection logs are missing when a rejection occurs.
- FAIL if ExecutionPacket manifests or input packet bodies are missing.
- FAIL if O2 packet contents, O2 packet hash, or forbidden-input records are missing.
- FAIL if required state snapshots are missing or cannot be reconstructed.
- FAIL if parent refs are missing or mismatched.
- FAIL if invalid, stale, superseded, contested, or rejected objects are overwritten.
- FAIL if `separate-context` is claimed without isolation proof.
- FAIL if compact traces omit required reconstruction fields.
- FAIL if executor raw decisions are treated as pass/fail scores.

## Evidence Ceiling Gate

No row may claim a higher evidence stage than the artifacts support. Package creation alone remains design-time.

## Terminal Validation Status

Allowed statuses:

- `validation-pass`
- `behavior-pass-evidence-fail`
- `behavior-fail-evidence-pass`
- `validation-fail`
- `blocked-unavailable-isolation`
- `not-run`
