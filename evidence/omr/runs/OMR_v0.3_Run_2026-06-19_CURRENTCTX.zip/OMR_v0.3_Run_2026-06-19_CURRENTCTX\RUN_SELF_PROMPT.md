You are Codex executing the OMR v0.3 evidence-collection run as a downstream executor.

role_class: downstream-execution
assignee_runtime: Codex

Use Project State/Operator_Model_Refinement_Pilot_Handoff_Bundle_v0.3 as the frozen package. Preserve v0.2 evidence as closed flawed screening evidence. Do not relabel, repair, rerun, or pool v0.2 rows.

Execution limits for this run:
- This current context window is not a true separate execution context.
- Do not claim blind, independent, live-runtime, production-observed, or true separate-context evidence.
- Rows requiring true separate-context must be captured as blocked-unavailable-isolation unless an auditable fresh context ID and proof exist.
- Packet-boundary rows may be executed as simulated executor-only outputs in the current context.
- Executor terminal decisions are raw outputs, not evaluator pass/fail scores.

For each v0.3 row, create a row archive containing selector records, rejected-selection logs, ExecutionPacket manifests, operator input packets, state snapshots, ledger projections, forbidden-input records, raw prompts, raw outputs, scoring inputs, and row_manifest.json. Validate package and row gates without scoring architecture superiority.