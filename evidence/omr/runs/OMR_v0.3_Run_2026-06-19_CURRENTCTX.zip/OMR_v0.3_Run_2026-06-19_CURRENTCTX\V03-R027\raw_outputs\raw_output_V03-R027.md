# Raw Executor Output V03-R027

Case: OMR-C07 V0
Actual context: packet-boundary
Evidence stage: design-time simulated executor-only

Terminal decision raw: verification-required

Trace: OB-main -> CAP-trace -> CoverageMap -> ChangeDecision. State snapshots, packet manifest, ledger projection, forbidden-input record, and selector record are preserved in this row archive.

Limitations: not blind, not independent, not live-runtime, not production-observed. Executor terminal decision is not a pass/fail score. C07: record whether selector reran upstream or reused stale state.