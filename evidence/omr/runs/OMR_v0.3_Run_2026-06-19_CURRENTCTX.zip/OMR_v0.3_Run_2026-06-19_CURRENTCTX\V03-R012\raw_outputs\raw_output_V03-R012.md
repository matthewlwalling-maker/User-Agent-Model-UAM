# Raw Executor Output V03-R012

Case: OMR-C03 V3
Actual context: packet-boundary
Evidence stage: design-time simulated executor-only

Terminal decision raw: verification-required

Trace: OB-main -> CAP-trace -> CoverageMap -> ChangeDecision. State snapshots, packet manifest, ledger projection, forbidden-input record, and selector record are preserved in this row archive.

Limitations: not blind, not independent, not live-runtime, not production-observed. Executor terminal decision is not a pass/fail score. C03: score conditional branch representation separately from unnecessary block.