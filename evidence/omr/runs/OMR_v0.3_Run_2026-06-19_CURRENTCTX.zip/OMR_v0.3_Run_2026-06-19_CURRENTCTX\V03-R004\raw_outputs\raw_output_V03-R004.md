# Raw Executor Output V03-R004

Case: OMR-C01 V1
Intended context: separate-context
Actual context: parent-thread-single-context
Status: blocked-unavailable-isolation

No operator output was generated because v0.3 requires auditable true separate-context proof for this row and the current context window cannot provide it. This row is retained as a rejected/blocked evidence record, not a failed behavioral output and not isolation credit.